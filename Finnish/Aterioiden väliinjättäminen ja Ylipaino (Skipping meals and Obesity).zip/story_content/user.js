function ExecuteScript(strId)
{
  switch (strId)
  {
      case "64ImLeDzer2":
        Script1();
        break;
      case "6SJepsVrOls":
        Script2();
        break;
      case "5Vp3uZWmzJU":
        Script3();
        break;
      case "68PLHSnTFgO":
        Script4();
        break;
      case "5g9EHOAmpo1":
        Script5();
        break;
      case "5erOhz3Odla":
        Script6();
        break;
      case "5r8KxU6jaJ7":
        Script7();
        break;
      case "6G69g15OP4s":
        Script8();
        break;
      case "6hJR9qLPhcB":
        Script9();
        break;
      case "63YCvQSsOaJ":
        Script10();
        break;
      case "6GM7wgam1jo":
        Script11();
        break;
      case "638bCmFHsiL":
        Script12();
        break;
      case "5luCfksVAYs":
        Script13();
        break;
      case "6mUDfb5raEw":
        Script14();
        break;
      case "6AEUPxx4Jze":
        Script15();
        break;
      case "6eoVds5X38X":
        Script16();
        break;
      case "5z05ak7cdmO":
        Script17();
        break;
      case "69a7Y6p2tBL":
        Script18();
        break;
      case "63Gw4whQB6W":
        Script19();
        break;
      case "5qLAaWVnXNW":
        Script20();
        break;
      case "6Lli7Hck62R":
        Script21();
        break;
      case "5fCEfVpox8L":
        Script22();
        break;
      case "5t1Fn1ybIUk":
        Script23();
        break;
      case "5e0FHLTI1gl":
        Script24();
        break;
      case "5uMuDqY9Sb3":
        Script25();
        break;
      case "6hGImFbTOH0":
        Script26();
        break;
      case "6ktJYvuBl8D":
        Script27();
        break;
      case "6ON9zZiSGd9":
        Script28();
        break;
      case "5WFDWyNFDPZ":
        Script29();
        break;
      case "5VxkgZvTpvw":
        Script30();
        break;
      case "5fUUJSifgDn":
        Script31();
        break;
      case "5ardKeTfkso":
        Script32();
        break;
      case "62Lp97iL9HV":
        Script33();
        break;
      case "6GBnXYE5exq":
        Script34();
        break;
      case "6kO099qs7yX":
        Script35();
        break;
      case "6kbjknjrzZ9":
        Script36();
        break;
      case "5wkGXlu9bUi":
        Script37();
        break;
      case "6o3rrCqO4rq":
        Script38();
        break;
      case "5V2rWX0nyZ4":
        Script39();
        break;
      case "5pNr5B8ZytV":
        Script40();
        break;
      case "5xbbYfJiFpf":
        Script41();
        break;
      case "614g8ttEDg7":
        Script42();
        break;
      case "6Ddb7r7YHjo":
        Script43();
        break;
      case "6LFR7B0Cdz7":
        Script44();
        break;
      case "5xAZMXIhQOV":
        Script45();
        break;
      case "63D9Qxt7PeA":
        Script46();
        break;
      case "689VmUrqI5Q":
        Script47();
        break;
      case "5ieQUwyRiZF":
        Script48();
        break;
      case "6MylQrIrm0n":
        Script49();
        break;
      case "5fdXeFpgdvo":
        Script50();
        break;
      case "6Kv5628sAvO":
        Script51();
        break;
      case "6UzbMIYNU7s":
        Script52();
        break;
      case "67RcpsT6JQU":
        Script53();
        break;
      case "64wZqUT6ZeB":
        Script54();
        break;
      case "5wSW06kyiP3":
        Script55();
        break;
      case "5j4z1wrHh5I":
        Script56();
        break;
      case "6nITnd6C1DV":
        Script57();
        break;
      case "5xfsW1h0z4m":
        Script58();
        break;
      case "5hudTUaPGh5":
        Script59();
        break;
      case "6Bmtgs3zl2F":
        Script60();
        break;
      case "5cxoLTqAOMZ":
        Script61();
        break;
      case "68QzudfnHZ6":
        Script62();
        break;
      case "6MP65YoGrZp":
        Script63();
        break;
      case "5lygvoHiJkF":
        Script64();
        break;
      case "6Znq1BFUiOq":
        Script65();
        break;
      case "62FuixMbLTn":
        Script66();
        break;
      case "681caVTqLA4":
        Script67();
        break;
      case "6camZsSQpHP":
        Script68();
        break;
      case "5vwHsw6bZ74":
        Script69();
        break;
      case "60LL32wunnu":
        Script70();
        break;
      case "6Qo6g5HHemZ":
        Script71();
        break;
      case "6T0GEuGjqis":
        Script72();
        break;
      case "5snODZ0qHEt":
        Script73();
        break;
      case "66P8mFCKi9L":
        Script74();
        break;
      case "5Wb3JMNuisO":
        Script75();
        break;
      case "5v6QVY5btXO":
        Script76();
        break;
      case "6rVCrg4VYSy":
        Script77();
        break;
      case "6lH212NSBTX":
        Script78();
        break;
      case "5ijx0A1ovnp":
        Script79();
        break;
      case "65ilocL9wgr":
        Script80();
        break;
      case "6Xrruvyffy5":
        Script81();
        break;
      case "6ACALPgSxfl":
        Script82();
        break;
      case "5tSFU0rIGFN":
        Script83();
        break;
      case "5crMpXmvOPB":
        Script84();
        break;
      case "5ph5KSoP9Aj":
        Script85();
        break;
      case "5Xgiidhdx3c":
        Script86();
        break;
      case "6HzdeSKG8Zh":
        Script87();
        break;
      case "6HZR0jCmTRF":
        Script88();
        break;
      case "6L4pkLE6bLh":
        Script89();
        break;
      case "5caObYvhGYn":
        Script90();
        break;
      case "5uD5HnElqqk":
        Script91();
        break;
      case "61UpFHiOg7P":
        Script92();
        break;
      case "6AdtyY45zQi":
        Script93();
        break;
      case "68iNHW92LrU":
        Script94();
        break;
      case "6Qzb0XyfMo8":
        Script95();
        break;
      case "5WqMbYEfvzM":
        Script96();
        break;
      case "5iYondHN9EY":
        Script97();
        break;
      case "6lkHoBi2eNr":
        Script98();
        break;
      case "6YFlprcIRT8":
        Script99();
        break;
      case "5cFWNYxS1EZ":
        Script100();
        break;
  }
}

function Script1()
{
  
/*
 *
 *   ACHIEVEMENTS
 *
 */

/*global GetPlayer:false */
var player = GetPlayer();
(function() {
	'use strict';
	window.achievements = {
		achievements: [
			{
				name: "First Question",
				desc: "You have successfully answered first question correctly.",
				advance: function()
				{
					this.completed = true;
				}
			},
			{
				name: "Three in a row",
				desc: "You have successfully answered three questions correctly in a row.",
				rowCounter: 0,
				advance: function()
				{
					var rowCounter = player.GetVar('ach3Question');
					console.log("in a row: "+rowCounter);
					if (rowCounter  == 3)
						this.completed = true;
				}
			},
			{
				name: "Hypothesis",
				desc: "You have successfully answered all hypothesis questions without any wrong answer.",
				rowCounter: 0,
				advance: function()
				{
					var isHypothesis = player.GetVar('achHypothesis');
					console.log(isHypothesis);
					if (isHypothesis  == 1)
						this.completed = true;
				}
			},
			{
				name: "All",
				desc: "You have successfully answered all of the questions correct.",
				rowCounter: 0,
				advance: function()
				{
					var isAll = player.GetVar('achAll');
					console.log(isAll);
					if (isAll  == 1)
						this.completed = true;
				}
			},
			{
				name: "",
				desc: "",
				rowCounter: 0,
				advance: function()
				{
					//In each case it will earn something
					this.completed = true;
				}
			},

		],
		completedThisRound: [],

		init: function()
		{
			for (var i = 0; i < this.achievements.length; ++i) {
				this.achievements[i].id = i;
			}
		},
		// public
		advanceAchievement: function(achid)
		{
			var ach = this.achievements[achid];
			if (!ach)
				return;
			if (ach.completed)
				return;
			ach.advance();
			if (!ach.completed)
				return;
			this.completedThisRound.push(ach);
		},
		checkForAchievements: function()
		{
			return this.completedThisRound.length > 0;
		},
		resetAchievementVars: function()
		{
			player.SetVar('achievementActive', 0);
			player.SetVar('achievementName', '');
			player.SetVar('achievementDesc', '');
			player.SetVar('achivementId', -1);
		},
		setupAchievementVars: function()
		{
			var ach = this.completedThisRound.shift();
			player.SetVar('achievementActive', 1);
			player.SetVar('achievementName', ach.name);
			player.SetVar('achievementDesc', ach.desc);
			player.SetVar('achivementId', ach.id);
			player.SetVar('achievementUnlocked' + ach.id, 1);
		},
		// public
		doEverythingAtOnce: function()
		{
			this.resetAchievementVars();
			if (this.checkForAchievements())
				this.setupAchievementVars();

		}
	};
	window.achievements.init();
})();

/*
 *
 *  END OF ACHIEVEMENTS 
 *
 */

}

function Script2()
{
  var eyesshut = 100, eyesopen = 10000, inblink = false;
var player = GetPlayer();
var isPopUp = player.GetVar("isPopUp");
function blink(){
  inblink = !inblink;
 if (isPopUp == 1) {
 setTimeout(blink, 100);
}
  else if (inblink) {
    player.SetVar('blinkState', 'hide');
    setTimeout(blink, eyesshut + Math.random() * 100);
  } else {
    player.SetVar('blinkState', 'show');
    setTimeout(blink, eyesopen + Math.random() * 1000);
  }
}

blink(); 

window.summary = {question: [], answer: [], correct: []}; 
}

function Script3()
{
  var player = GetPlayer();
player.SetVar("answerM1", "");
player.SetVar("answerM2", "");
player.SetVar("answerM3", "");
player.SetVar("answerM4", "");
player.SetVar("answerM5", "");
player.SetVar("answerM6", "");
}

function Script4()
{
   window.summary.question.push('Formulate the null-hypothesis by selecting the correct sentence parts - Part1');
  window.summary.answer.push('On yhteyttä');
  window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('6', 'On yhteyttä', false, '', 'Null-hypothesis Part 1 ', 1, 0, 'Scene2_Slide6_1');
}

function Script5()
{
  player = GetPlayer();
answer1 = player.GetVar("answerM4");
answer2 = player.GetVar("answerM3");

 window.summary.question.push('Formulate the null-hypothesis by selecting the correct sentence parts - Part2');
  window.summary.answer.push(answer1 + answer2);
  window.summary.correct.push('Incorrect');

var answersum = answer1 + answer2;

lmsAPI.RecordFillInInteraction('7', answersum, false, '', 'Null-hypothesis Part 2 ', 1, 0, 'Scene2_Slide6_2');
}

function Script6()
{
  player = GetPlayer();
answer1 = player.GetVar("answerM5");
answer2 = player.GetVar("answerM6");

 window.summary.question.push('Formulate the null-hypothesis by selecting the correct sentence parts - Part3');
  window.summary.answer.push(answer1 + answer2);
  window.summary.correct.push('Incorrect');

var answersum = answer1 + answer2;

lmsAPI.RecordFillInInteraction('8', answersum, false, '', 'Null-hypothesis Part 3 ', 1, 0, 'Scene2_Slide6_3');
}

function Script7()
{
    window.summary.question.push('Formulate the null-hypothesis by selecting the correct sentence parts - Part1');
  window.summary.answer.push('Ei ole yhteyttä');
  window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('6', 'Ei ole yhteyttä', true, '', 'Null-hypothesis Part 1 ', 1, 0, 'Scene2_Slide6_1');
}

function Script8()
{
    window.summary.question.push('Formulate the null-hypothesis by selecting the correct sentence parts - Part2');
  window.summary.answer.push('aterioiden väliin jättämisen välillä');
  window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('7', 'aterioiden väliin jättämisen välillä', true, '', 'Null-hypothesis Part 2 ', 1, 0, 'Scene2_Slide6_2');
}

function Script9()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script10()
{
    window.summary.question.push('Formulate the null-hypothesis by selecting the correct sentence parts - Part3');
  window.summary.answer.push('painon luokituksessa');
  window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('8', 'painon luokituksessa', true, '', 'Null-hypothesis Part 3 ', 1, 0, 'Scene2_Slide6_3');
}

function Script11()
{
  var player = GetPlayer();
var score = player.GetVar('score');
var rank;
window.clearTimeout(timeVar);

//Score
if( score >= 1500 )
 rank = "A";
else if( score >= 1400 )
 rank = "B";
else if( score >= 1300 )
 rank = "C";
else if( score >= 1200 )
 rank = "D";
else 
 rank = "E";

player.SetVar('rank', rank);

//Time
function zeroPad(num, places) {
  var zero = places - num.toString().length + 1;
  return Array(+(zero > 0 && zero)).join("0") + num;
}

var time = player.GetVar('time');

var minutes = Math.floor(time / 60);
var seconds = time - minutes * 60;

minutes  = zeroPad(minutes, 2);
seconds  = zeroPad(seconds, 2);

var NewTime = minutes+":"+seconds;
player.SetVar('timeLast', NewTime );

player.SetVar("answerM1", "");
player.SetVar("answerM2", "");
player.SetVar("answerM3", "");
player.SetVar("answerM4", "");
player.SetVar("answerM5", "");
player.SetVar("answerM6", "");

lmsAPI.RecordFillInInteraction('14', score, true, '', 'Score ', 1, 0, 'Scene2_Slide8');
lmsAPI.RecordFillInInteraction('15', NewTime, true, '', 'Playing Time ', 1, 0, 'Scene2_Slide8');

lmsAPI.SetPassed();
player = GetPlayer();
var correct = player.GetVar("correctcounter");
var question = player.GetVar("questioncounter");

var score = ( correct / question ) * 100;
score =  Math.round( Number(score));
player.SetVar("calculatedscore", score);
player.SetVar("calculatedcorrect",correct);
player.SetVar("calculatedquestion",question);

lmsAPI.SetScore(score,100,0);

lmsAPI.RecordFillInInteraction('16', playerName, true, '', 'Player Name ', 1, 0, 'Scene2_Slide8');

lmsAPI.RecordFillInInteraction('17', rank, true, '', 'Rank ', 1, 0, 'Scene2_Slide8');

}

function Script12()
{
  var answersum = "";

if ( player.GetVar('answerM1') !== "")
   answersum +=  player.GetVar('answerM1') + ", ";
if ( player.GetVar('answerM2') !== "")
   answersum +=  player.GetVar('answerM2') + ", ";
if ( player.GetVar('answerM3') !== "")
   answersum +=  player.GetVar('answerM3') + ", ";
if ( player.GetVar('answerM4') !== "")
   answersum +=  player.GetVar('answerM4') + ", ";

lmsAPI.RecordFillInInteraction('18', answersum, true, '', 'Achievements ', 1, 0, 'Scene2_Slide8');
}

function Script13()
{
  var player = GetPlayer();
var formHTML = "<style>table {border-collapse:collapse;margin-top:20px;color:#373737} table, tr, td {padding: 10px;}tr:nth-child(even) {background:#E3F3EF; }tr:nth-child(odd) {background:#C7F1E6; }tr.header{background:#008A6E;color:white;font-weight:bold; }.logo { margin-bottom:10px;} .name {text-transform:uppercase;font-size:24px;font-weight:bold;color:#008A6E;}.label {font-weight:bold;}.logo span {font-size:27px; font-weight: bold; text-decoration:underline; color:#373737 } .logo img {float:right;}</style>";

var answersum = "";

if ( player.GetVar('answerM1') !== "")
   answersum +=  player.GetVar('answerM1') + ", ";
if ( player.GetVar('answerM2') !== "")
   answersum +=  player.GetVar('answerM2') + ", ";
if ( player.GetVar('answerM3') !== "")
   answersum +=  player.GetVar('answerM3') + ", ";
if ( player.GetVar('answerM4') !== "")
   answersum +=  player.GetVar('answerM4') + ", ";

formHTML += "<div class='logo'><span>Skipping Meals and Obesity</span><img src='http://www.playgen.com/chermug/chermug_logo.jpg'></div>";
formHTML += "<span class='name'>" +  player.GetVar('playerName')+ "</span><br/>";
formHTML += "<span class='label'>Score:</span> " + player.GetVar('score') + "<br/>";
formHTML += "<span class='label'>Rank:</span> " + player.GetVar('rank') + "<br/>";
formHTML += "<span class='label'>Time:</span> " + player.GetVar('timeLast') + "<br/>";
formHTML += "<span class='label'>Achievements:</span> " + answersum + "<br/>";

formHTML += "<table><tr class='header'><td>ID</td><td>Question</td><td>Answered</td><td>Correct/Incorrect</td></tr>";

var length = window.summary.question.length;
var question = null;
var answer = null;
var correct = null;

for (var i = 0; i < length; i++) {
question = window.summary.question[i];
answer = window.summary.answer[i];
correct = window.summary.correct[i];
id = i + 1;

formHTML += "<tr><td>" + id + "</td><td>" + question + "</td><td>" + answer + "</td><td>" + correct + "</td></tr>";

}

formHTML += "</table>";

formHTML += "<script>window.print();</script>";

var preview = window.open("about:blank");
preview.document.open();
preview.document.write(formHTML);
preview.document.close();
preview.print();
}

function Script14()
{
  var seconds=0;
timeVar = setTimeout(startTime,1000);

 
function startTime(){
seconds=seconds+1;
var player = GetPlayer();
player.SetVar("time",seconds);
timeVar = setTimeout(startTime,1000);
}
 
}

function Script15()
{
  var player = GetPlayer();
var answer1 = player.GetVar("answerM1");
var answer2 = player.GetVar("answerM2");
var answer3 = player.GetVar("answerM3");
var answer4 = player.GetVar("answerM4");
var answer5 = player.GetVar("answerM5");
var answer6 = player.GetVar("answerM6");
var answer7 = player.GetVar("answerM7");
var answer8 = player.GetVar("answerM8");

var answersum = "";

if ( answer1 !== "")
   answersum += answer1 + ", ";
if ( answer2 !== "")
   answersum += answer2 + ", ";
if ( answer3 !== "")
   answersum += answer3 + ", ";
if ( answer4 !== "")
   answersum += answer4 + ", ";
if ( answer5 !== "")
   answersum += answer5 + ", ";
if ( answer6 !== "")
   answersum += answer6;
if ( answer7 !== "")
   answersum += answer7 + ", ";
if ( answer8 !== "")
   answersum += answer8;


 window.summary.question.push('Mitkä ovat tämän tutkimuksen muuttujat?');
  window.summary.answer.push(answersum);
  window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('1', answersum, false, '', 'Mitkä ovat tämän tutkimuksen muuttujat?', 1, 0, 'Scene2_Slide9_1');
}

function Script16()
{
  window.achievements.advanceAchievement(0);
window.achievements.doEverythingAtOnce();
}

function Script17()
{
  var player = GetPlayer();
var answer1 = player.GetVar("answerM1");
var answer2 = player.GetVar("answerM2");
var answer3 = player.GetVar("answerM3");
var answer4 = player.GetVar("answerM4");
var answer5 = player.GetVar("answerM5");
var answer6 = player.GetVar("answerM6");
var answer7 = player.GetVar("answerM7");
var answer8 = player.GetVar("answerM8");

var answersum = "";

if ( answer1 !== "")
   answersum += answer1 + ", ";
if ( answer2 !== "")
   answersum += answer2 + ", ";
if ( answer3 !== "")
   answersum += answer3 + ", ";
if ( answer4 !== "")
   answersum += answer4 + ", ";
if ( answer5 !== "")
   answersum += answer5 + ", ";
if ( answer6 !== "")
   answersum += answer6;
if ( answer7 !== "")
   answersum += answer7 + ", ";
if ( answer8 !== "")
   answersum += answer8;


 window.summary.question.push('Mitkä ovat tämän tutkimuksen muuttujat?');
  window.summary.answer.push(answersum);
  window.summary.correct.push('Correct');


lmsAPI.RecordFillInInteraction('1', answersum, true, '', 'Mitkä ovat tämän tutkimuksen muuttujat?', 1, 0, 'Scene2_Slide9_1');
}

function Script18()
{
  var player = GetPlayer();
player.SetVar("answerM1", "");
player.SetVar("answerM2", "");
player.SetVar("answerM3", "");
player.SetVar("answerM4", "");
player.SetVar("answerM5", "");
player.SetVar("answerM6", "");
}

function Script19()
{
  var player = GetPlayer();
var answer1 = player.GetVar("answerM1");
var answer2 = player.GetVar("answerM2");
var answer3 = player.GetVar("answerM3");
var answer4 = player.GetVar("answerM4");
var answer5 = player.GetVar("answerM5");
var answer6 = player.GetVar("answerM6");
var answer7 = player.GetVar("answerM7");
var answer8 = player.GetVar("answerM8");

var answersum = "";

if ( answer1 !== "")
   answersum += answer1 + ", ";
if ( answer2 !== "")
   answersum += answer2 + ", ";
if ( answer3 !== "")
   answersum += answer3 + ", ";
if ( answer4 !== "")
   answersum += answer4 + ", ";
if ( answer5 !== "")
   answersum += answer5 + ", ";
if ( answer6 !== "")
   answersum += answer6;
if ( answer7 !== "")
   answersum += answer7 + ", ";
if ( answer8 !== "")
   answersum += answer8;


 window.summary.question.push('Mitkä ovat muuttujien  aterioiden väliinjättäminen  ja paino tasot?');
  window.summary.answer.push(answersum);
  window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('2', answersum, true, '', 'Mitkä ovat muuttujien  aterioiden väliinjättäminen  ja paino tasot?', 1, 0, 'Scene2_Slide9_2');
}

function Script20()
{
  var player = GetPlayer();
var answer1 = player.GetVar("answerM1");
var answer2 = player.GetVar("answerM2");
var answer3 = player.GetVar("answerM3");
var answer4 = player.GetVar("answerM4");
var answer5 = player.GetVar("answerM5");
var answer6 = player.GetVar("answerM6");
var answer7 = player.GetVar("answerM7");
var answer8 = player.GetVar("answerM8");

var answersum = "";

if ( answer1 !== "")
   answersum += answer1 + ", ";
if ( answer2 !== "")
   answersum += answer2 + ", ";
if ( answer3 !== "")
   answersum += answer3 + ", ";
if ( answer4 !== "")
   answersum += answer4 + ", ";
if ( answer5 !== "")
   answersum += answer5 + ", ";
if ( answer6 !== "")
   answersum += answer6;
if ( answer7 !== "")
   answersum += answer7 + ", ";
if ( answer8 !== "")
   answersum += answer8;


 window.summary.question.push('Mitkä ovat muuttujien  aterioiden väliinjättäminen  ja paino tasot?');
  window.summary.answer.push(answersum);
  window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('2', answersum, false, '', 'Mitkä ovat muuttujien  aterioiden väliinjättäminen  ja paino tasot?', 1, 0, 'Scene2_Slide9_2');
}

function Script21()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script22()
{
  var player = GetPlayer();  
var answer = player.GetVar('answer');
window.summary.question.push('Millä asteikolla tässä tutkimuksessa ylipainoa mitataan?');
window.summary.answer.push(answer);
window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('4', answer, true, '', 'Millä asteikolla tässä tutkimuksessa ylipainoa mitataan? ', 1, 0, 'Scene2_Slide10_1');
}

function Script23()
{
  var player = GetPlayer();  
var answer = player.GetVar('answer');
window.summary.question.push('Millä asteikolla tässä tutkimuksessa ylipainoa mitataan?');
window.summary.answer.push(answer);
window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('4', answer, false, '', 'Millä asteikolla tässä tutkimuksessa ylipainoa mitataan? ', 1, 0, 'Scene2_Slide10_1');
}

function Script24()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script25()
{
    window.summary.question.push('Mitä tässä tutkimuksessa halutaan selvittää?');
  window.summary.answer.push('yhteyttä muuttujien välillä');
  window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('5', 'yhteyttä muuttujien välillä', true, '', 'Mitä tässä tutkimuksessa halutaan selvittää? ', 1, 0, 'Scene2_Slide10_2');
}

function Script26()
{
    window.summary.question.push('Mitä tässä tutkimuksessa halutaan selvittää?');
  window.summary.answer.push('eroja ryhmien välillä');
  window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('5', 'eroja ryhmien välillä', false, '', 'Mitä tässä tutkimuksessa halutaan selvittää? ', 1, 0, 'Scene2_Slide10_2');
}

function Script27()
{
  
/*
 *
 * HANGMAN GAME
 *
 */

/*global GetPlayer:false */
var player = GetPlayer();
(function() {
	'use strict';
	window.hangman = {
		//Use capital letters
		questions: ["JARJESTYSASTEIKKO"],
		activeQuestion: -1,
		question: '',
		chars: [],
		foundChars: {},
		foundLetters: 0,
		alphabet: ["A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z", "Ex"],
		init: function()
		{
			//console.log("init");

		},
		/*
		 * Functions to be called from Storyline
		 */
		// Setup question and the word into letters
		setupQuestions: function(questionnumber)
		{
			this.foundLetters = 0;
			this.activeQuestion = questionnumber;
			this.question = this.questions[this.activeQuestion-1];
			this.chars = this.question.split('');
			this.foundChars = {};
			for (var i = this.alphabet.length - 1; i >= 0; i--)
				player.SetVar("hmChange"+ this.alphabet[i], 0);


		},
		// Check if any letter or the answer is found
		letterPressed: function(letter)
		{
			if (this.foundChars[letter])
				return;
			player.SetVar("hmChangeSet", 0);
			var found = 0;
			for (var i = this.chars.length - 1; i >= 0; i--) {
				var pos = i+1;
				if(this.chars[i] == letter) {
					player.SetVar("hml"  + pos, letter);
					found = 1;
					this.foundLetters++;
					this.foundChars[letter] = true;
					if (this.foundLetters >= this.chars.length) {
						player.SetVar("hmAnswerFound", 1);
					}	
				}
			}
			if( found != 1) {
				//cant put ! in the stroyline var
				if (letter == "!")
					letter = "Ex";

				var isPressed = player.GetVar("hmChange"+letter);
				if( isPressed == 0) {
				var tleft = player.GetVar("hmtleft");
				tleft = tleft -1;
				player.SetVar("hmtleft", tleft);
				player.SetVar("hmChange"+ letter, 1);
				}
			}
		 

			return;
		}
	};
	window.hangman.init();
})();

/*
 *
 * END OF HANGMAN GAME
 *
 */


}

function Script28()
{
  var seconds=3000;
// display();
var blinkTimer = setTimeout(display,400);
var flag = 0;
 
function display(){
	seconds=seconds-1;
	var player = GetPlayer();
	var tleft = player.GetVar("hmtleft");
	player.SetVar("hmtimer",seconds);
	if( tleft != 9) {
		if(flag == 0) {
			player.SetVar("hmBlink","hide");
			flag = 1;
		}
		else {
		player.SetVar("hmBlink","show");
		flag = 0;
		}
		var blinkTimer = setTimeout(display,400);
	}
	else 
	player.SetVar("hmBlink","show");
}
 
}

function Script29()
{
  window.hangman.setupQuestions(1);
}

function Script30()
{
  window.hangman.letterPressed("B");
}

function Script31()
{
  window.hangman.letterPressed("C");
}

function Script32()
{
  window.hangman.letterPressed("D");
}

function Script33()
{
  window.hangman.letterPressed("E");
}

function Script34()
{
  window.hangman.letterPressed("F");
}

function Script35()
{
  window.hangman.letterPressed("G");
}

function Script36()
{
  window.hangman.letterPressed("H");
}

function Script37()
{
  window.hangman.letterPressed("I");
}

function Script38()
{
  window.hangman.letterPressed("J");
}

function Script39()
{
  window.hangman.letterPressed("K");
}

function Script40()
{
  window.hangman.letterPressed("L");
}

function Script41()
{
  window.hangman.letterPressed("M");
}

function Script42()
{
  window.hangman.letterPressed("N");
}

function Script43()
{
  window.hangman.letterPressed("O");
}

function Script44()
{
  window.hangman.letterPressed("P");
}

function Script45()
{
  window.hangman.letterPressed("Q");
}

function Script46()
{
  window.hangman.letterPressed("R");
}

function Script47()
{
  window.hangman.letterPressed("S");
}

function Script48()
{
  window.hangman.letterPressed("T");
}

function Script49()
{
  window.hangman.letterPressed("U");
}

function Script50()
{
  window.hangman.letterPressed("V");
}

function Script51()
{
  window.hangman.letterPressed("W");
}

function Script52()
{
  window.hangman.letterPressed("X");
}

function Script53()
{
  window.hangman.letterPressed("Y");
}

function Script54()
{
  window.hangman.letterPressed("Z");
}

function Script55()
{
  window.hangman.letterPressed("!");
}

function Script56()
{
  window.hangman.letterPressed("A");
}

function Script57()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script58()
{
    window.summary.question.push('In this study what level of measurement is appropriate for skipping meals? ');
  window.summary.answer.push('Ordinal');
  window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('3', 'Ordinal', true, '', 'In this study what level of measurement is appropriate for skipping meals?', 1, 0, 'Scene2_Slide11');
}

function Script59()
{
    window.summary.question.push('In this study what level of measurement is appropriate for skipping meals? ');
  window.summary.answer.push('');
  window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('3', '', false, '', 'In this study what level of measurement is appropriate for skipping meals?', 1, 0, 'Scene2_Slide11');
}

function Script60()
{
  var seconds=4;
//setTimeout(display,1000);
display();
 
function display(){
seconds=seconds-1;
var player = GetPlayer();
player.SetVar("hmcready",seconds);
var cready = player.GetVar("hmcready");
if ( cready == 0) {
player.SetVar("hmcready", "Go!");
setTimeout(display,1000);
}
else if ( cready == -1) {
player.SetVar("hmcready", "next");
}
else {
setTimeout(display,1000);
}
}
}

function Script61()
{
  var player = GetPlayer();
var name= player.GetVar('achievementName');
var desc = player.GetVar('achievementDesc');

console.log("name:" + name);
console.log("description" + desc);
}

function Script62()
{
  window.hangman.setupQuestions(1);
var seconds=4;
//setTimeout(display,1000);
display();
 
function display(){
seconds=seconds-1;
var player = GetPlayer();
player.SetVar("hmcready",seconds);
var cready = player.GetVar("hmcready");
if ( cready == 0) {
player.SetVar("hmcready", "Go!");
setTimeout(display,1000);
}
else if ( cready == -1) {
player.SetVar("hmcready", "next");
setTimeout(display,1000);
}
else {
setTimeout(display,1000);
}
}
}

function Script63()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script64()
{
    window.summary.question.push('Kumpi alla olevista aineistoista on oikea testaamaan aineistoasi?');
  window.summary.answer.push('Aineisto 2');
  window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('9', 'Aineisto 2', true, '', 'Kumpi alla olevista aineistoista on oikea testaamaan aineistoasi? ', 1, 0, 'Scene2_Slide12');
}

function Script65()
{
    window.summary.question.push('Kumpi alla olevista aineistoista on oikea testaamaan aineistoasi?');
  window.summary.answer.push('Aineisto1 ');
  window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('9', 'Aineisto1 ', false, '', 'Kumpi alla olevista aineistoista on oikea testaamaan aineistoasi? ', 1, 0, 'Scene2_Slide12');
}

function Script66()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script67()
{
  player = GetPlayer();  
var answer = player.GetVar('answer');

window.summary.question.push('Missä muodossa esittäisit yhteenvedon aineistoista?');
window.summary.answer.push(answer);
window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('10', answer, true, '', 'Missä muodossa esittäisit yhteenvedon aineistoista? ', 1, 0, 'Scene2_Slide13');
}

function Script68()
{
  player = GetPlayer();  
var answer = player.GetVar('answer');

window.summary.question.push('Missä muodossa esittäisit yhteenvedon aineistoista?');
window.summary.answer.push(answer);
window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('10', answer, false, '', 'Missä muodossa esittäisit yhteenvedon aineistoista? ', 1, 0, 'Scene2_Slide13');
}

function Script69()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script70()
{
  window.summary.question.push('Mitä testausmenetelmää käyttäisit?');
window.summary.answer.push('Khiin neliön arvo');
window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('14', 'Khiin neliön arvo', true, '', 'Mitä testausmenetelmää käyttäisit? ', 1, 0, 'Scene2_Slide14_1');
}

function Script71()
{
  window.summary.question.push('Mitä testausmenetelmää käyttäisit?');
window.summary.answer.push('t arvo');
window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('14', 't arvo', false, '', 'Mitä testausmenetelmää käyttäisit? ', 1, 0, 'Scene2_Slide14_1');
}

function Script72()
{
  window.summary.question.push('Mitä testausmenetelmää käyttäisit?');
window.summary.answer.push('Pearsons r');
window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('14', 'Pearsons r', false, '', 'Mitä testausmenetelmää käyttäisit? ', 1, 0, 'Scene2_Slide14_1');
}

function Script73()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}

var time = player.GetVar('time');
//Bronze Gold Silver
if( time <= 15000 && time > 1200 ) {
player.SetVar("achQuestionBronze",1);
}
if( time>= 10000 &&  time <= 12000) {
player.SetVar("achQuestionBronze",0);
player.SetVar("achQuestionSilver",1);
}
if( time < 10000 ) {
player.SetVar("achQuestionSilver",0);
player.SetVar("achQuestionGold",1);
}
}

function Script74()
{
  window.achievements.advanceAchievement(3);
window.achievements.doEverythingAtOnce();

window.achievements.advanceAchievement(4);
window.achievements.doEverythingAtOnce();




}

function Script75()
{
  window.summary.question.push('Khiin neliön kriittinen arvo 3*2 kontingenssitaulukossa .05 merkitsevyystasolla kaksisuuntaisessa testissä on 5.99. Onko tämä khiin neliön arvo merkitsevä?');
window.summary.answer.push('Kyllä');
window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('15', 'Kyllä', true, '', 'Khiin neliön kriittinen arvo 3*2 kontingenssitaulukossa .05 merkitsevyystasolla kaksisuuntaisessa testissä on 5.99. Onko tämä khiin neliön arvo merkitsevä? ', 1, 0, 'Scene2_Slide14_2');
}

function Script76()
{
  var player = GetPlayer();
var time = player.GetVar('time');
//Bronze Gold Silver
if( time <= 15000 && time > 1200 ) {
player.SetVar("achQuestionBronze",1);
}
if( time>= 10000 &&  time <= 12000) {
player.SetVar("achQuestionBronze",0);
player.SetVar("achQuestionSilver",1);
}
if( time < 10000 ) {
player.SetVar("achQuestionSilver",0);
player.SetVar("achQuestionGold",1);
}

window.achievements.advanceAchievement(4);
window.achievements.doEverythingAtOnce();
}

function Script77()
{
  window.summary.question.push('Khiin neliön kriittinen arvo 3*2 kontingenssitaulukossa .05 merkitsevyystasolla kaksisuuntaisessa testissä on 5.99. Onko tämä khiin neliön arvo merkitsevä?');
window.summary.answer.push('Ei');
window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('15', 'Ei', false, '', 'Khiin neliön kriittinen arvo 3*2 kontingenssitaulukossa .05 merkitsevyystasolla kaksisuuntaisessa testissä on 5.99. Onko tämä khiin neliön arvo merkitsevä? ', 1, 0, 'Scene2_Slide14_2');
}

function Script78()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script79()
{
  window.summary.question.push('Kumpi taulukko näyttää havaitut frekvenssit? A vai B');
window.summary.answer.push('A');
window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('12', 'A', true, '', 'Kumpi taulukko näyttää havaitut frekvenssit? A vai B', 1, 0, 'Scene2_Slide15_1');
}

function Script80()
{
  window.summary.question.push('Kumpi taulukko näyttää havaitut frekvenssit? A vai B');
window.summary.answer.push('B');
window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('12', 'B', false, '', 'Kumpi taulukko näyttää havaitut frekvenssit? A vai B', 1, 0, 'Scene2_Slide15_1');
}

function Script81()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}
}

function Script82()
{
  window.summary.question.push('Kumpi taulukko näyttää odotetut frekvenssit? A vai B');
window.summary.answer.push('B');
window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('13', 'B', true, '', 'Kumpi taulukko näyttää odotetut frekvenssit? A vai B', 1, 0, 'Scene2_Slide15_2');
}

function Script83()
{
  window.summary.question.push('Kumpi taulukko näyttää odotetut frekvenssit? A vai B');
window.summary.answer.push('A');
window.summary.correct.push('Incorrect');


lmsAPI.RecordFillInInteraction('13', 'B', false, '', 'Kumpi taulukko näyttää odotetut frekvenssit? A vai B', 1, 0, 'Scene2_Slide15_2');
}

function Script84()
{
  
/*
 *
 * TIC-TAC-TOE GAME
 *
 */

/*global GetPlayer:false */
var player = GetPlayer();
(function() {
	'use strict';
	var state = {
		READY: 0,
		RIGHT: 1,
		WRONG: 2
	};
	var validValues = [
		// Rows
		1  | 2   | 4,
		8  | 16  | 32,
		64 | 128 | 256,
		// Columns
		1  | 8   | 64,
		2  | 16  | 128,
		4  | 32  | 256,
		// Diagonals
		1 | 16 | 256,
		4 | 16 | 64
	];
	window.ttt = {
		questions: [
			{
				text: "Kaikenkaikkiaan ylipainoisia tyttöjä oli enemmän kuin normaalipainoisia.",
				wrong: "Incorrect.",
				answer: false
			},
			{
				text: "Kaikenkaikkiaan tyttöjä, jotka jättivät ruokailun välistä, oli enemmän kuin tyttöjä, jotka eivät jättäneet.",
				wrong: "Incorrect.",
				answer: true
			},
			{
				text: "Kaikenkaikkiaan yleisin tyttöjen antama vastaus oli, että se joskus jättivät aterian välistä.",
				wrong: "Incorrect.",
				answer: true
			},
			{
				text: "Normaalipainoisia tyttöjä, jotka jättivät aterian välistä, oli enemmän kuin ylipainoisia tyttöjä, jotka jättivät aterian välistä.",
				wrong: "Incorrect.",
				answer: false
			},
			{
				text: "Normaalipainoisten tyttöjen vähiten antama  vastaus oli etteivät he jätä aterioita välistä.",
				wrong: "Incorrect.",
				answer: false
			},
			{
				text: "Normaalipainoisia tyttöjä, jotka eivät jättäneet aterioita välistä, oli enemmän kuin ylipainoisia, jotka eivät jättäneet aterioita väliin.",
				wrong: "Incorrect.",
				answer: true
			},
			{
				text: "Ylipainoisten tyttöjen yleisin vastaus oli että he joskus jättävät aterian välistä.",
				wrong: "Incorrect.",
				answer: false
			},
			{
				text: "Ylipainoisia tyttöjä jotka eivät koskaan jättäneet aterioita väliin, oli enemmän  kuin normaalipainoisia, jotka eivät koskaan jättäneet aterioita väliin.",
				wrong: "Incorrect.",
				answer: false
			},
			{
				text: "Normaalipainoisten tyttöjen vähiten antama vastaus oli, että he jättivät aterioita väliin.",
				wrong: "Incorrect.",
				answer: true
			}
		],
		activeQuestion: -1,
		totalValue: 0,
		init: function()
		{
			if (this.questions.length !== 9) {
				alert("Question count missmatch! Got " + this.questions.length + " expected 9");
				return;
			}
			var value = 1;
			// Setup the Qs with redundant info

var length = this.questions.length,
element = null;
for (var i = 0; i < length; i++) {
element = this.questions[i];
element .id = i;
element .value = value;
element .state = state.READY;
value *= 2;
}
		},
		updateQState: function(question, state)
		{
			question.state = state;
			player.SetVar('tttQuestionState' + question.id, state);
		},
		/*
		 * Functions to be called from Storyline
		 */
		// Resets all the question vars to ready
		setupQuestions: function()
		{
			this.activeQuestion = null;
			this.totalValue = 0;
			player.SetVar('tttQuestionText', '');
			player.SetVar('tttSlideSolved', 0);
var length = this.questions.length,
element = null;
for (var i = 0; i < length; i++) {
element = this.questions[i];
this.updateQState(element , state.READY);
}

		},
		// For when the user picks a question
		chooseQuestion: function(quid)
		{
			var question = this.questions[quid];
			if (question.state !== state.READY)
				return;
			this.activeQuestion = question;
			player.SetVar('tttQuestionText', question.text);
		},
		// Check if the answer is correctus
		checkAnswer: function(choice)
		{
			// Get what we're talkin about
			var question = this.activeQuestion;
			// Hide the question window
var questionText = player.GetVar('tttQuestionText');
			player.SetVar('tttQuestionText', '');
			// Reset the wrong var so we can trigger it if necessary
			player.SetVar('tttQuestionWrong', '');
			// Determine failure
			var choice_ = (choice == 'true') ? true : false;
			// If you pass you're wrong and stupid
			if (choice === 'pass' || choice_ !== question.answer) {
				this.updateQState(question, state.WRONG);
				// Pop up the "no u stupid" box
				player.SetVar('tttQuestionWrong', question.wrong);

window.summary.question.push(questionText);
window.summary.answer.push(choice_);
window.summary.correct.push('Incorrect');

				return;
			}
			// success!
window.summary.question.push(questionText);
window.summary.answer.push(question.answer);
window.summary.correct.push('Correct');
			this.updateQState(question, state.RIGHT);
			this.totalValue |= question.value;
			// Check if we've won
var length = validValues.length,
value = null;
for (var i = 0; i < length; i++) {
value = validValues[i];
if  ( (this.totalValue & value) === value )
player.SetVar('tttSlideSolved', 1);
}
		}
	};
	window.ttt.init();
})();

/*
 *
 * END OF TIC-TAC-TOE GAME
 *
 */


}

function Script85()
{
  window.ttt.setupQuestions();
}

function Script86()
{
  window.ttt.setupQuestions();
}

function Script87()
{
  window.ttt.chooseQuestion(0);
}

function Script88()
{
  window.ttt.chooseQuestion(1);
}

function Script89()
{
  window.ttt.chooseQuestion(2);
}

function Script90()
{
  window.ttt.chooseQuestion(3);
}

function Script91()
{
  window.ttt.chooseQuestion(4);
}

function Script92()
{
  window.ttt.chooseQuestion(5);
}

function Script93()
{
  window.ttt.chooseQuestion(6);
}

function Script94()
{
  window.ttt.chooseQuestion(7);
}

function Script95()
{
  window.ttt.chooseQuestion(8);
}

function Script96()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


lmsAPI.RecordFillInInteraction('11', 'Completed', true, '', 'Microscope Game ', 1, 0, 'Scene2_Slide15');



}

function Script97()
{
  lmsAPI.RecordFillInInteraction('11', '', false, '', 'Microscope Game ', 1, 0, 'Scene2_Slide15');
}

function Script98()
{
  var eyesshut = 100, eyesopen = 10000, inblink = false;
var player = GetPlayer();
function blink(){
  inblink = !inblink;
  if (inblink) {
    player.SetVar('blinkState', 'hide');
    setTimeout(blink, eyesshut + Math.random() * 40);
  } else {
    player.SetVar('blinkState', 'show');
    setTimeout(blink, eyesopen + Math.random() * 500);
  }
}

blink(); 
}

function Script99()
{
  window.ttt.checkAnswer('true');
}

function Script100()
{
  window.ttt.checkAnswer('false');
}

