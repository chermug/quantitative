function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6SCwfdlUCjX":
        Script1();
        break;
      case "5ZwwVZYSsmT":
        Script2();
        break;
      case "5WFSQK3aBob":
        Script3();
        break;
      case "6hmlF4obvgC":
        Script4();
        break;
      case "6buYagFiB3P":
        Script5();
        break;
      case "5rtv0HwQbF1":
        Script6();
        break;
      case "6OFp13qEoyt":
        Script7();
        break;
      case "6kehg57Rx0v":
        Script8();
        break;
      case "62Ka9d873vQ":
        Script9();
        break;
      case "5ictRPwTiPm":
        Script10();
        break;
      case "5gAzohIKLC9":
        Script11();
        break;
      case "5k8w1Ayn771":
        Script12();
        break;
      case "64bXNH2ePft":
        Script13();
        break;
      case "5UpyISgn066":
        Script14();
        break;
      case "6eKC3jPElZY":
        Script15();
        break;
      case "5VU62c3woN2":
        Script16();
        break;
      case "5cirzcwAYEJ":
        Script17();
        break;
      case "5t4rGhectPh":
        Script18();
        break;
      case "6W6Hiw2fXo3":
        Script19();
        break;
      case "6JZyP7orFZZ":
        Script20();
        break;
      case "6OGRg44HiFM":
        Script21();
        break;
      case "5aUxF4HgK9M":
        Script22();
        break;
      case "6hlaIDzHhfJ":
        Script23();
        break;
      case "5dPSM39OqZn":
        Script24();
        break;
      case "6NOYHrhVubC":
        Script25();
        break;
      case "6027upODORO":
        Script26();
        break;
      case "6OenwV6usXE":
        Script27();
        break;
      case "5grtgW6viUV":
        Script28();
        break;
      case "6kOMwxcKrQd":
        Script29();
        break;
      case "6877436m86a":
        Script30();
        break;
      case "6YRoMYEV6Ug":
        Script31();
        break;
      case "6dLisNeNUgf":
        Script32();
        break;
      case "5WzrTdqFYJc":
        Script33();
        break;
      case "6kIaLuD8tJe":
        Script34();
        break;
      case "5jKCsnpzfil":
        Script35();
        break;
      case "5eS90WbAoFx":
        Script36();
        break;
      case "5jl56qQeDjy":
        Script37();
        break;
      case "6AcNgLPpF0j":
        Script38();
        break;
      case "6ietAUSGdLK":
        Script39();
        break;
      case "6CvHxzXvWaf":
        Script40();
        break;
      case "6le3mijSXfN":
        Script41();
        break;
      case "5vmgRjU4D2w":
        Script42();
        break;
      case "6XBSI9Ftz1c":
        Script43();
        break;
      case "5eF77LC0jgi":
        Script44();
        break;
      case "6JnIkSmrEoW":
        Script45();
        break;
      case "5qDtbGHiNmb":
        Script46();
        break;
      case "68mwj46JpI2":
        Script47();
        break;
      case "5x9jsUfgi7W":
        Script48();
        break;
      case "6FhHStGrg56":
        Script49();
        break;
      case "6GygwJcH22e":
        Script50();
        break;
      case "5vX9vgpPKf8":
        Script51();
        break;
      case "6lhi36IWTdu":
        Script52();
        break;
      case "5WFowFfddkF":
        Script53();
        break;
      case "6iFBtxqZNnR":
        Script54();
        break;
      case "6dRLcDUu65s":
        Script55();
        break;
      case "6HdY15OIcTB":
        Script56();
        break;
      case "69qtJqmyUvo":
        Script57();
        break;
      case "6bjRWdPfOpb":
        Script58();
        break;
      case "6DqbGDLSltq":
        Script59();
        break;
      case "6YujFr2Ddcg":
        Script60();
        break;
      case "6hfeRiRHve8":
        Script61();
        break;
      case "5bWfmuY2Ftc":
        Script62();
        break;
      case "5VnkK59c78f":
        Script63();
        break;
      case "63Y6tGWlGdL":
        Script64();
        break;
      case "5pFsyOdEMvd":
        Script65();
        break;
      case "6nvX5QyEfRq":
        Script66();
        break;
      case "6c6oSq6OL7T":
        Script67();
        break;
      case "66eQR87ox4j":
        Script68();
        break;
      case "5xAE36cdewn":
        Script69();
        break;
      case "6IMfZjuYFae":
        Script70();
        break;
      case "61UVj3QX4cx":
        Script71();
        break;
      case "6qNd9gYkawy":
        Script72();
        break;
      case "6ZlJwqadgPv":
        Script73();
        break;
      case "5ohMb7ck6fr":
        Script74();
        break;
      case "5YRXRoWLb6J":
        Script75();
        break;
      case "6DfR4oAmkLB":
        Script76();
        break;
      case "65cnPTKMBSh":
        Script77();
        break;
      case "5nPg3AUj9b2":
        Script78();
        break;
      case "5d1hlclFPyc":
        Script79();
        break;
      case "5nZ5cn6ymWf":
        Script80();
        break;
      case "6puMbFJ2hpy":
        Script81();
        break;
      case "6feFcyoV7ur":
        Script82();
        break;
      case "6qIJUWkjn6h":
        Script83();
        break;
      case "65NmqamHwAu":
        Script84();
        break;
      case "6HVqzwAqDoa":
        Script85();
        break;
      case "62GhDOaycjL":
        Script86();
        break;
      case "6HMV9rxbhHE":
        Script87();
        break;
      case "6eIQkJUfQTo":
        Script88();
        break;
      case "6V8huvf0ffU":
        Script89();
        break;
      case "5xv5bQJg0qG":
        Script90();
        break;
      case "5gZjWTwwFsM":
        Script91();
        break;
      case "6NH1AG70YPz":
        Script92();
        break;
      case "6lgRAGVs5F2":
        Script93();
        break;
      case "6dC40jyhtpQ":
        Script94();
        break;
      case "5ZSZGwKwDcA":
        Script95();
        break;
      case "66Gv5vNhvDl":
        Script96();
        break;
      case "5l6S1fyUQ2h":
        Script97();
        break;
      case "5XKzydydBwk":
        Script98();
        break;
      case "5yLg2DnuClM":
        Script99();
        break;
  }
}

function Script1()
{
  
/*
 *
 *   ACHIEVEMENTS
 *
 */

/*global GetPlayer:false */
var player = GetPlayer();
(function() {
	'use strict';
	window.achievements = {
		achievements: [
			{
				name: "First Question",
				desc: "You have successfully answered first question correctly.",
				advance: function()
				{
					this.completed = true;
				}
			},
			{
				name: "Three in a row",
				desc: "You have successfully answered three questions correctly in a row.",
				rowCounter: 0,
				advance: function()
				{
					var rowCounter = player.GetVar('ach3Question');
					console.log("in a row: "+rowCounter);
					if (rowCounter  == 3)
						this.completed = true;
				}
			},
			{
				name: "Hypothesis",
				desc: "You have successfully answered all hypothesis questions without any wrong answer.",
				rowCounter: 0,
				advance: function()
				{
					var isHypothesis = player.GetVar('achHypothesis');
					console.log(isHypothesis);
					if (isHypothesis  == 1)
						this.completed = true;
				}
			},
			{
				name: "All",
				desc: "You have successfully answered all of the questions correct.",
				rowCounter: 0,
				advance: function()
				{
					var isAll = player.GetVar('achAll');
					console.log(isAll);
					if (isAll  == 1)
						this.completed = true;
				}
			},
			{
				name: "",
				desc: "",
				rowCounter: 0,
				advance: function()
				{
					//In each case it will earn something
					this.completed = true;
				}
			},

		],
		completedThisRound: [],

		init: function()
		{
			for (var i = 0; i < this.achievements.length; ++i) {
				this.achievements[i].id = i;
			}
		},
		// public
		advanceAchievement: function(achid)
		{
			var ach = this.achievements[achid];
			if (!ach)
				return;
			if (ach.completed)
				return;
			ach.advance();
			if (!ach.completed)
				return;
			this.completedThisRound.push(ach);
		},
		checkForAchievements: function()
		{
			return this.completedThisRound.length > 0;
		},
		resetAchievementVars: function()
		{
			player.SetVar('achievementActive', 0);
			player.SetVar('achievementName', '');
			player.SetVar('achievementDesc', '');
			player.SetVar('achivementId', -1);
		},
		setupAchievementVars: function()
		{
			var ach = this.completedThisRound.shift();
			player.SetVar('achievementActive', 1);
			player.SetVar('achievementName', ach.name);
			player.SetVar('achievementDesc', ach.desc);
			player.SetVar('achivementId', ach.id);
			player.SetVar('achievementUnlocked' + ach.id, 1);
		},
		// public
		doEverythingAtOnce: function()
		{
			this.resetAchievementVars();
			if (this.checkForAchievements())
				this.setupAchievementVars();

		}
	};
	window.achievements.init();
})();

/*
 *
 *  END OF ACHIEVEMENTS 
 *
 */

}

function Script2()
{
  var eyesshut = 100, eyesopen = 10000, inblink = false;
var player = GetPlayer();
var isPopUp = player.GetVar("isPopUp");
function blink(){
  inblink = !inblink;
 if (isPopUp == 1) {
 setTimeout(blink, 100);
}
  else if (inblink) {
    player.SetVar('blinkState', 'hide');
    setTimeout(blink, eyesshut + Math.random() * 100);
  } else {
    player.SetVar('blinkState', 'show');
    setTimeout(blink, eyesopen + Math.random() * 1000);
  }
}

blink(); 

window.summary = {question: [], answer: [], correct: []}; 
}

function Script3()
{
  var player = GetPlayer();
player.SetVar("answerM1", "");
player.SetVar("answerM2", "");
player.SetVar("answerM3", "");
player.SetVar("answerM4", "");
player.SetVar("answerM5", "");
player.SetVar("answerM6", "");
}

function Script4()
{
   window.summary.question.push('Formulate the null-hypothesis by selecting the correct sentence parts - Part1');
  window.summary.answer.push('On eroa');
  window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('6', 'On eroa', false, '', 'Null-hypothesis Part 1 ', 1, 0, 'Scene2_Slide6_1');
}

function Script5()
{
  var player = GetPlayer();
var answer1 = player.GetVar("answerM4");
var answer2 = player.GetVar("answerM3");

 window.summary.question.push('Formulate the null-hypothesis by selecting the correct sentence parts - Part2');
  window.summary.answer.push(answer1 + answer2);
  window.summary.correct.push('Incorrect');

var answersum = answer1 + answer2;

lmsAPI.RecordFillInInteraction('7', answersum, false, '', 'Null-hypothesis Part 2 ', 1, 0, 'Scene2_Slide6_2');
}

function Script6()
{
  var player = GetPlayer();
var answer1 = player.GetVar("answerM5");
var answer2 = player.GetVar("answerM6");

 window.summary.question.push('Formulate the null-hypothesis by selecting the correct sentence parts - Part3');
  window.summary.answer.push(answer1 + answer2);
  window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('8', answersum, false, '', 'Null-hypothesis Part 3 ', 1, 0, 'Scene2_Slide6_3');
}

function Script7()
{
    window.summary.question.push('Formulate the null-hypothesis by selecting the correct sentence parts - Part1');
  window.summary.answer.push('Mitään yhteyttä ei ole');
  window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('6', 'Mitään yhteyttä ei ole', true, '', 'Null-hypothesis Part 2 ', 1, 0, 'Scene2_Slide6_1');
}

function Script8()
{
    window.summary.question.push('Formulate the null-hypothesis by selecting the correct sentence parts - Part2');
  window.summary.answer.push('median käytön määrän välillä');
  window.summary.correct.push('Correct');


lmsAPI.RecordFillInInteraction('7', 'median käytön määrän välillä', true, '', 'Null-hypothesis Part 2 ', 1, 0, 'Scene2_Slide6_2');
}

function Script9()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script10()
{
    window.summary.question.push('Formulate the null-hypothesis by selecting the correct sentence parts - Part3');
  window.summary.answer.push('ja ylipainon määrän välillä');
  window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('8', 'ja ylipainon määrän välillä', true, '', 'Null-hypothesis Part 3 ', 1, 0, 'Scene2_Slide6_3');
}

function Script11()
{
  var player = GetPlayer();
var score = player.GetVar('score');
var rank;
window.clearTimeout(timeVar);

//Score
if( score >= 1500 )
 rank = "A";
else if( score >= 1400 )
 rank = "B";
else if( score >= 1300 )
 rank = "C";
else if( score >= 1200 )
 rank = "D";
else 
 rank = "E";

player.SetVar('rank', rank);

//Time
function zeroPad(num, places) {
  var zero = places - num.toString().length + 1;
  return Array(+(zero > 0 && zero)).join("0") + num;
}

var time = player.GetVar('time');

var minutes = Math.floor(time / 60);
var seconds = time - minutes * 60;

minutes  = zeroPad(minutes, 2);
seconds  = zeroPad(seconds, 2);

var NewTime = minutes+":"+seconds;
player.SetVar('timeLast', NewTime );

player.SetVar("answerM1", "");
player.SetVar("answerM2", "");
player.SetVar("answerM3", "");
player.SetVar("answerM4", "");
player.SetVar("answerM5", "");
player.SetVar("answerM6", "");

lmsAPI.RecordFillInInteraction('14', score, true, '', 'Score ', 1, 0, 'Scene2_Slide8');
lmsAPI.RecordFillInInteraction('15', NewTime, true, '', 'Playing Time ', 1, 0, 'Scene2_Slide8');

lmsAPI.SetPassed();
player = GetPlayer();
var correct = player.GetVar("correctcounter");
var question = player.GetVar("questioncounter");

var score = ( correct / question ) * 100;
score =  Math.round( Number(score));
player.SetVar("calculatedscore", score);
player.SetVar("calculatedcorrect",correct);
player.SetVar("calculatedquestion",question);

lmsAPI.SetScore(score,100,0);

lmsAPI.RecordFillInInteraction('16', playerName, true, '', 'Player Name ', 1, 0, 'Scene2_Slide8');

lmsAPI.RecordFillInInteraction('17', rank, true, '', 'Rank ', 1, 0, 'Scene2_Slide8');


}

function Script12()
{
  var answersum = "";

if ( player.GetVar('answerM1') !== "")
   answersum +=  player.GetVar('answerM1') + ", ";
if ( player.GetVar('answerM2') !== "")
   answersum +=  player.GetVar('answerM2') + ", ";
if ( player.GetVar('answerM3') !== "")
   answersum +=  player.GetVar('answerM3') + ", ";
if ( player.GetVar('answerM4') !== "")
   answersum +=  player.GetVar('answerM4') + ", ";

lmsAPI.RecordFillInInteraction('18', answersum, true, '', 'Achievements ', 1, 0, 'Scene2_Slide8');
}

function Script13()
{
  var player = GetPlayer();
var formHTML = "<style>table {border-collapse:collapse;margin-top:20px;color:#373737} table, tr, td {padding: 10px;}tr:nth-child(even) {background:#E3F3EF; }tr:nth-child(odd) {background:#C7F1E6; }tr.header{background:#008A6E;color:white;font-weight:bold; }.logo { margin-bottom:10px;} .name {text-transform:uppercase;font-size:24px;font-weight:bold;color:#008A6E;}.label {font-weight:bold;}.logo span {font-size:27px; font-weight: bold; text-decoration:underline; color:#373737 } .logo img {float:right;}</style>";

var answersum = "";

if ( player.GetVar('answerM1') !== "")
   answersum +=  player.GetVar('answerM1') + ", ";
if ( player.GetVar('answerM2') !== "")
   answersum +=  player.GetVar('answerM2') + ", ";
if ( player.GetVar('answerM3') !== "")
   answersum +=  player.GetVar('answerM3') + ", ";
if ( player.GetVar('answerM4') !== "")
   answersum +=  player.GetVar('answerM4') + ", ";

formHTML += "<div class='logo'><span>Media Consumption and Obesity</span><img src='http://www.playgen.com/chermug/chermug_logo.jpg'></div>";
formHTML += "<span class='name'>" +  player.GetVar('playerName')+ "</span><br/>";
formHTML += "<span class='label'>Score:</span> " + player.GetVar('score') + "<br/>";
formHTML += "<span class='label'>Rank:</span> " + player.GetVar('rank') + "<br/>";
formHTML += "<span class='label'>Time:</span> " + player.GetVar('timeLast') + "<br/>";
formHTML += "<span class='label'>Achievements:</span> " + answersum + "<br/>";

formHTML += "<table><tr class='header'><td>ID</td><td>Question</td><td>Answered</td><td>Correct/Incorrect</td></tr>";

var length = window.summary.question.length;
var question = null;
var answer = null;
var correct = null;

for (var i = 0; i < length; i++) {
question = window.summary.question[i];
answer = window.summary.answer[i];
correct = window.summary.correct[i];
id = i + 1;

formHTML += "<tr><td>" + id + "</td><td>" + question + "</td><td>" + answer + "</td><td>" + correct + "</td></tr>";

}

formHTML += "</table>";

formHTML += "<script>window.print();</script>";

var preview = window.open("about:blank");
preview.document.open();
preview.document.write(formHTML);
preview.document.close();
preview.print();
}

function Script14()
{
  var seconds=0;
timeVar = setTimeout(startTime,1000);

 
function startTime(){
seconds=seconds+1;
var player = GetPlayer();
player.SetVar("time",seconds);
timeVar = setTimeout(startTime,1000);
}
 
}

function Script15()
{
  var player = GetPlayer();
var answer1 = player.GetVar("answerM1");
var answer2 = player.GetVar("answerM2");
var answer3 = player.GetVar("answerM3");
var answer4 = player.GetVar("answerM4");
var answer5 = player.GetVar("answerM5");
var answer6 = player.GetVar("answerM6");
var answer7 = player.GetVar("answerM7");
var answer8 = player.GetVar("answerM8");

var answersum = "";

if ( answer1 !== "")
   answersum += answer1 + ", ";
if ( answer2 !== "")
   answersum += answer2 + ", ";
if ( answer3 !== "")
   answersum += answer3 + ", ";
if ( answer4 !== "")
   answersum += answer4 + ", ";
if ( answer5 !== "")
   answersum += answer5 + ", ";
if ( answer6 !== "")
   answersum += answer6;
if ( answer7 !== "")
   answersum += answer7 + ", ";
if ( answer8 !== "")
   answersum += answer8;


 window.summary.question.push('Mitkä ovat tutkimuksen päämuuttujat?');
  window.summary.answer.push(answersum);
  window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('1', answersum, false, '', 'Mitkä ovat tutkimuksen päämuuttujat? ', 1, 0, 'Scene2_Slide9_1');
}

function Script16()
{
  window.achievements.advanceAchievement(0);
window.achievements.doEverythingAtOnce();
}

function Script17()
{
  var player = GetPlayer();
var answer1 = player.GetVar("answerM1");
var answer2 = player.GetVar("answerM2");
var answer3 = player.GetVar("answerM3");
var answer4 = player.GetVar("answerM4");
var answer5 = player.GetVar("answerM5");
var answer6 = player.GetVar("answerM6");
var answer7 = player.GetVar("answerM7");
var answer8 = player.GetVar("answerM8");

var answersum = "";

if ( answer1 !== "")
   answersum += answer1 + ", ";
if ( answer2 !== "")
   answersum += answer2 + ", ";
if ( answer3 !== "")
   answersum += answer3 + ", ";
if ( answer4 !== "")
   answersum += answer4 + ", ";
if ( answer5 !== "")
   answersum += answer5 + ", ";
if ( answer6 !== "")
   answersum += answer6;
if ( answer7 !== "")
   answersum += answer7 + ", ";
if ( answer8 !== "")
   answersum += answer8;


 window.summary.question.push('Mitkä ovat tutkimuksen päämuuttujat?');
  window.summary.answer.push(answersum);
  window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('1', answersum, true, '', 'Mitkä ovat tutkimuksen päämuuttujat? ', 1, 0, 'Scene2_Slide9_1');
}

function Script18()
{
  var player = GetPlayer();
player.SetVar("answerM1", "");
player.SetVar("answerM2", "");
player.SetVar("answerM3", "");
player.SetVar("answerM4", "");
player.SetVar("answerM5", "");
player.SetVar("answerM6", "");
player.SetVar("answerM7", "");
player.SetVar("answerM8", "");
}

function Script19()
{
  var player = GetPlayer();
var answer1 = player.GetVar("answerM1");
var answer2 = player.GetVar("answerM2");
var answer3 = player.GetVar("answerM3");
var answer4 = player.GetVar("answerM4");
var answer5 = player.GetVar("answerM5");
var answer6 = player.GetVar("answerM6");
var answer7 = player.GetVar("answerM7");
var answer8 = player.GetVar("answerM8");

var answersum = "";

if ( answer1 !== "")
   answersum += answer1 + ", ";
if ( answer2 !== "")
   answersum += answer2 + ", ";
if ( answer3 !== "")
   answersum += answer3 + ", ";
if ( answer4 !== "")
   answersum += answer4 + ", ";
if ( answer5 !== "")
   answersum += answer5 + ", ";
if ( answer6 !== "")
   answersum += answer6;
if ( answer7 !== "")
   answersum += answer7 + ", ";
if ( answer8 !== "")
   answersum += answer8;


 window.summary.question.push('Mitkä ovat muuttujien median käyttö ja ylipainon määrä arvot tässä tutkimuksessa?');
  window.summary.answer.push(answersum);
  window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('2', answersum, true, '', 'Mitkä ovat muuttujien median käyttö ja ylipainon määrä arvot tässä tutkimuksessa?', 1, 0, 'Scene2_Slide9_2');
}

function Script20()
{
  var player = GetPlayer();
var answer1 = player.GetVar("answerM1");
var answer2 = player.GetVar("answerM2");
var answer3 = player.GetVar("answerM3");
var answer4 = player.GetVar("answerM4");
var answer5 = player.GetVar("answerM5");
var answer6 = player.GetVar("answerM6");
var answer7 = player.GetVar("answerM7");
var answer8 = player.GetVar("answerM8");

var answersum = "";

if ( answer1 !== "")
   answersum += answer1 + ", ";
if ( answer2 !== "")
   answersum += answer2 + ", ";
if ( answer3 !== "")
   answersum += answer3 + ", ";
if ( answer4 !== "")
   answersum += answer4 + ", ";
if ( answer5 !== "")
   answersum += answer5 + ", ";
if ( answer6 !== "")
   answersum += answer6;
if ( answer7 !== "")
   answersum += answer7 + ", ";
if ( answer8 !== "")
   answersum += answer8;


 window.summary.question.push('Mitkä ovat muuttujien median käyttö ja ylipainon määrä arvot tässä tutkimuksessa?');
  window.summary.answer.push(answersum);
  window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('2', answersum, false, '', 'Mitkä ovat muuttujien median käyttö ja ylipainon määrä arvot tässä tutkimuksessa?', 1, 0, 'Scene2_Slide9_2');
}

function Script21()
{
  
/*
 *
 * HANGMAN GAME
 *
 */

/*global GetPlayer:false */
var player = GetPlayer();
(function() {
	'use strict';
	window.hangman = {
		//Use capital letters
		questions: ["LUOKITTEKUASTEIKKO"],
		activeQuestion: -1,
		question: '',
		chars: [],
		foundChars: {},
		foundLetters: 0,
		alphabet: ["A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z", "Ex"],
		init: function()
		{
			//console.log("init");

		},
		/*
		 * Functions to be called from Storyline
		 */
		// Setup question and the word into letters
		setupQuestions: function(questionnumber)
		{
			this.foundLetters = 0;
			this.activeQuestion = questionnumber;
			this.question = this.questions[this.activeQuestion-1];
			this.chars = this.question.split('');
			this.foundChars = {};
			for (var i = this.alphabet.length - 1; i >= 0; i--)
				player.SetVar("hmChange"+ this.alphabet[i], 0);


		},
		// Check if any letter or the answer is found
		letterPressed: function(letter)
		{
			if (this.foundChars[letter])
				return;
			player.SetVar("hmChangeSet", 0);
			var found = 0;
			for (var i = this.chars.length - 1; i >= 0; i--) {
				var pos = i+1;
				if(this.chars[i] == letter) {
					player.SetVar("hml"  + pos, letter);
					found = 1;
					this.foundLetters++;
					this.foundChars[letter] = true;
					if (this.foundLetters >= this.chars.length) {
						player.SetVar("hmAnswerFound", 1);
					}	
				}
			}
			if( found != 1) {
				//cant put ! in the stroyline var
				if (letter == "!")
					letter = "Ex";

				var isPressed = player.GetVar("hmChange"+letter);
				if( isPressed == 0) {
				var tleft = player.GetVar("hmtleft");
				tleft = tleft -1;
				player.SetVar("hmtleft", tleft);
				player.SetVar("hmChange"+ letter, 1);
				}
			}
		 

			return;
		}
	};
	window.hangman.init();
})();

/*
 *
 * END OF HANGMAN GAME
 *
 */


}

function Script22()
{
  var seconds=3000;
// display();
var blinkTimer = setTimeout(display,400);
var flag = 0;
 
function display(){
	seconds=seconds-1;
	var player = GetPlayer();
	var tleft = player.GetVar("hmtleft");
	player.SetVar("hmtimer",seconds);
	if( tleft != 9) {
		if(flag == 0) {
			player.SetVar("hmBlink","hide");
			flag = 1;
		}
		else {
		player.SetVar("hmBlink","show");
		flag = 0;
		}
		var blinkTimer = setTimeout(display,400);
	}
	else 
	player.SetVar("hmBlink","show");
}
 
}

function Script23()
{
  window.hangman.setupQuestions(1);
}

function Script24()
{
  window.hangman.letterPressed("B");
}

function Script25()
{
  window.hangman.letterPressed("C");
}

function Script26()
{
  window.hangman.letterPressed("D");
}

function Script27()
{
  window.hangman.letterPressed("E");
}

function Script28()
{
  window.hangman.letterPressed("F");
}

function Script29()
{
  window.hangman.letterPressed("G");
}

function Script30()
{
  window.hangman.letterPressed("H");
}

function Script31()
{
  window.hangman.letterPressed("I");
}

function Script32()
{
  window.hangman.letterPressed("J");
}

function Script33()
{
  window.hangman.letterPressed("K");
}

function Script34()
{
  window.hangman.letterPressed("L");
}

function Script35()
{
  window.hangman.letterPressed("M");
}

function Script36()
{
  window.hangman.letterPressed("N");
}

function Script37()
{
  window.hangman.letterPressed("O");
}

function Script38()
{
  window.hangman.letterPressed("P");
}

function Script39()
{
  window.hangman.letterPressed("Q");
}

function Script40()
{
  window.hangman.letterPressed("R");
}

function Script41()
{
  window.hangman.letterPressed("S");
}

function Script42()
{
  window.hangman.letterPressed("T");
}

function Script43()
{
  window.hangman.letterPressed("U");
}

function Script44()
{
  window.hangman.letterPressed("V");
}

function Script45()
{
  window.hangman.letterPressed("W");
}

function Script46()
{
  window.hangman.letterPressed("X");
}

function Script47()
{
  window.hangman.letterPressed("Y");
}

function Script48()
{
  window.hangman.letterPressed("Z");
}

function Script49()
{
  window.hangman.letterPressed("!");
}

function Script50()
{
  window.hangman.letterPressed("A");
}

function Script51()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script52()
{
    window.summary.question.push('Mikä luokitteluasteikko sopii median käytön mittaamiseen?');
  window.summary.answer.push('LUOKITTEKUASTEIKKO');
  window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('3', 'Nominal', true, '', 'Mikä luokitteluasteikko sopii median käytön mittaamiseen?', 1, 0, 'Scene2_Slide10');
}

function Script53()
{
    window.summary.question.push('Mikä luokitteluasteikko sopii median käytön mittaamiseen?');
  window.summary.answer.push('');
  window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('3', '', false, '', 'Mikä luokitteluasteikko sopii median käytön mittaamiseen?', 1, 0, 'Scene2_Slide10');
}

function Script54()
{
  var seconds=4;
//setTimeout(display,1000);
display();
 
function display(){
seconds=seconds-1;
var player = GetPlayer();
player.SetVar("hmcready",seconds);
var cready = player.GetVar("hmcready");
if ( cready == 0) {
player.SetVar("hmcready", "Go!");
setTimeout(display,1000);
}
else if ( cready == -1) {
player.SetVar("hmcready", "next");
}
else {
setTimeout(display,1000);
}
}
}

function Script55()
{
  var player = GetPlayer();
var name= player.GetVar('achievementName');
var desc = player.GetVar('achievementDesc');

console.log("name:" + name);
console.log("description" + desc);
}

function Script56()
{
  window.hangman.setupQuestions(1);
var seconds=4;
//setTimeout(display,1000);
display();
 
function display(){
seconds=seconds-1;
var player = GetPlayer();
player.SetVar("hmcready",seconds);
var cready = player.GetVar("hmcready");
if ( cready == 0) {
player.SetVar("hmcready", "Go!");
setTimeout(display,1000);
}
else if ( cready == -1) {
player.SetVar("hmcready", "next");
setTimeout(display,1000);
}
else {
setTimeout(display,1000);
}
}
}

function Script57()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script58()
{
  var player = GetPlayer();  
var answer = player.GetVar('answer');
window.summary.question.push('Mikä asteikko tässä tutkimuksessa sopii ylipainon määrän tarkasteluun?');
window.summary.answer.push(answer);
window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('4', answer, true, '', 'Mikä asteikko tässä tutkimuksessa sopii ylipainon määrän tarkasteluun? ', 1, 0, 'Scene2_Slide11_1');
}

function Script59()
{
  var player = GetPlayer();  
var answer = player.GetVar('answer');
window.summary.question.push('Mikä asteikko tässä tutkimuksessa sopii ylipainon määrän tarkasteluun? ');
window.summary.answer.push(answer);
window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('4', answer, false, '', 'Mikä asteikko tässä tutkimuksessa sopii ylipainon määrän tarkasteluun? ', 1, 0, 'Scene2_Slide11_1');
}

function Script60()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script61()
{
    window.summary.question.push('Minkä tyyppinen tutkimus on kyseessä?');
  window.summary.answer.push('muuttujien välinen yhteys');
  window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('5', 'muuttujien välinen yhteys', true, '', 'Minkä tyyppinen tutkimus on kyseessä? ', 1, 0, 'Scene2_Slide11_2');
}

function Script62()
{
    window.summary.question.push('Minkä tyyppinen tutkimus on kyseessä?');
  window.summary.answer.push('ryhmien väliset erot');
  window.summary.correct.push('Incorrect');


lmsAPI.RecordFillInInteraction('5', 'ryhmien väliset erot', false, '', 'Minkä tyyppinen tutkimus on kyseessä? ', 1, 0, 'Scene2_Slide11_2');
}

function Script63()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script64()
{
    window.summary.question.push('Kumpi alla olevista havaintoaineistoista sopii testaamiseen?');
  window.summary.answer.push('Dataset1');
  window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('9', 'Dataset1', true, '', 'Kumpi alla olevista havaintoaineistoista sopii testaamiseen? ', 1, 0, 'Scene2_Slide12');
}

function Script65()
{
    window.summary.question.push('Kumpi alla olevista havaintoaineistoista sopii testaamiseen?');
  window.summary.answer.push('Dataset2');
  window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('9', 'Dataset2', false, '', 'Kumpi alla olevista havaintoaineistoista sopii testaamiseen? ', 1, 0, 'Scene2_Slide12');
}

function Script66()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script67()
{
  var player = GetPlayer();  
var answer = player.GetVar('answer');

window.summary.question.push('Mitä graafista esitystapaa käyttäisit aineiston esittämiseen?');
window.summary.answer.push(answer);
window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('10', answer, true, '', 'Mitä graafista esitystapaa käyttäisit aineiston esittämiseen? ', 1, 0, 'Scene2_Slide13');

}

function Script68()
{
  var player = GetPlayer();  
var answer = player.GetVar('answer');

window.summary.question.push('Mitä graafista esitystapaa käyttäisit aineiston esittämiseen?');
window.summary.answer.push(answer);
window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('10', answer, false, '', 'Mitä graafista esitystapaa käyttäisit aineiston esittämiseen? ', 1, 0, 'Scene2_Slide13');
}

function Script69()
{
  player = GetPlayer();  
var answer = player.GetVar('answer');

window.summary.question.push('Mitä graafista esitystapaa käyttäisit aineiston esittämiseen?');
window.summary.answer.push(answer);
window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('10', answer, false, '', 'Mitä graafista esitystapaa käyttäisit aineiston esittämiseen? ', 1, 0, 'Scene2_Slide13');
}

function Script70()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script71()
{
  window.summary.question.push('Mitä testimuuttujaa haluat käyttää?');
window.summary.answer.push('Khiin neliön arvo');
window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('12', 'Khiin neliön arvo', true, '', 'Mitä testimuuttujaa haluat käyttää? ', 1, 0, 'Scene2_Slide14');
}

function Script72()
{
  window.summary.question.push('Mitä testimuuttujaa haluat käyttää?');
window.summary.answer.push('Spearmans rho');
window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('12', 'Spearmans rho', false, '', 'Mitä testimuuttujaa haluat käyttää? ', 1, 0, 'Scene2_Slide14');
}

function Script73()
{
  window.summary.question.push('Mitä testimuuttujaa haluat käyttää?');
window.summary.answer.push('t-value');
window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('12', 't-value', false, '', 'Mitä testimuuttujaa haluat käyttää? ', 1, 0, 'Scene2_Slide14');
}

function Script74()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}
}

function Script75()
{
  window.summary.question.push('Which test statistic would you like to see?');
window.summary.answer.push('Chi squared value');
window.summary.correct.push('Correct');
}

function Script76()
{
  var player = GetPlayer();  
var ne = player.GetVar('NumericEntry');
var ne1 = player.GetVar('NumericEntry1');

window.summary.question.push('Mikä oli Khiin neliön arvo? ');
window.summary.answer.push(ne+','+ne1);
window.summary.correct.push('Correct');

var answer = ne+','+ne1;

lmsAPI.RecordFillInInteraction('13', answer, true, '', 'Mikä oli Khiin neliön arvo? ', 1, 0, 'Scene2_Slide14_2');
}

function Script77()
{
  var player = GetPlayer();  
var ne = player.GetVar('NumericEntry');
var ne1 = player.GetVar('NumericEntry1');

window.summary.question.push('Mikä oli Khiin neliön arvo? ');
window.summary.answer.push(ne+','+ne1);
window.summary.correct.push('Incorrect');

var answer = ne+','+ne1;

lmsAPI.RecordFillInInteraction('13', answer, false, '', 'Mikä oli Khiin neliön arvo? ', 1, 0, 'Scene2_Slide14_2');
}

function Script78()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}

var time = player.GetVar('time');
//Bronze Gold Silver
if( time <= 15000 && time > 1200 ) {
player.SetVar("achQuestionBronze",1);
}
if( time>= 10000 &&  time <= 12000) {
player.SetVar("achQuestionBronze",0);
player.SetVar("achQuestionSilver",1);
}
if( time < 10000 ) {
player.SetVar("achQuestionSilver",0);
player.SetVar("achQuestionGold",1);
}
}

function Script79()
{
  window.achievements.advanceAchievement(3);
window.achievements.doEverythingAtOnce();

window.achievements.advanceAchievement(4);
window.achievements.doEverythingAtOnce();




}

function Script80()
{
  window.summary.question.push('Tässä tapauksessa khiin neliön arvo = 30.295,p<0.000 Onko se merkitsevä? ');
window.summary.answer.push('Kyllä');
window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('14', 'Kyllä', true, '', 'Tässä tapauksessa khiin neliön arvo = 30.295,p<0.000 Onko se merkitsevä?  ', 1, 0, 'Scene2_Slide14_3');
}

function Script81()
{
  var player = GetPlayer();
var time = player.GetVar('time');
//Bronze Gold Silver
if( time <= 15000 && time > 1200 ) {
player.SetVar("achQuestionBronze",1);
}
if( time>= 10000 &&  time <= 12000) {
player.SetVar("achQuestionBronze",0);
player.SetVar("achQuestionSilver",1);
}
if( time < 10000 ) {
player.SetVar("achQuestionSilver",0);
player.SetVar("achQuestionGold",1);
}

window.achievements.advanceAchievement(4);
window.achievements.doEverythingAtOnce();
}

function Script82()
{
  window.summary.question.push('Tässä tapauksessa khiin neliön arvo = 30.295,p<0.000 Onko se merkitsevä?');
window.summary.answer.push('Ei');
window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('14', 'Ei', false, '', 'Tässä tapauksessa khiin neliön arvo = 30.295,p<0.000 Onko se merkitsevä?  ', 1, 0, 'Scene2_Slide14_3');
}

function Script83()
{
  
/*
 *
 * TIC-TAC-TOE GAME
 *
 */

/*global GetPlayer:false */
var player = GetPlayer();
(function() {
	'use strict';
	var state = {
		READY: 0,
		RIGHT: 1,
		WRONG: 2
	};
	var validValues = [
                               // Rows
		1  | 2   | 4,
		8  | 16  | 32,
		64 | 128 | 256,
		// Columns
		1  | 8   | 64,
		2  | 16  | 128,
		4  | 32  | 256,
		// Diagonals
		1 | 16 | 256,
		4 | 16 | 64
	];
	window.ttt = {
		questions: [
			{
				text: "Lapsista suurempi osa oli ylipainoisia kuin ei-ylipainoisia.",
				wrong: "Incorrect.",
				answer: true
			},
			{
				text: "Ylipainoisista suurempi osa kulutti mediaa paljon, pienempi osa vähän.",
				wrong: "Incorrect.",
				answer: true
			},
			{
				text: "Niistä, jotka eivät olleet ylipainoisia, suurempi osa kulutti mediaa paljon, pienempi osa vähän.",
				wrong: "Incorrect.",
				answer: false
			},
			{
				text: "Yleisesti ottaen suurempi osa lapsista kulutti mediaa vähän.",
				wrong: "Incorrect.",
				answer: false
			},
			{
				text: "Suurempi osa lapsista oli normaalipainoisia, pienempi osa ylipainoisia.",
				wrong: "Incorrect.",
				answer: false
			},
			{
				text: "Ylipainoisista vähemistö kulutti mediaa paljon, enemmistö vähän.",
				wrong: "Incorrect.",
				answer: false
			},
			{
				text: "Ei-ylipainoisista suurempi osa kulutti mediaa vähän, vähemmistö paljon. ",
				wrong: "Incorrect.",
				answer: true
			},
			{
				text: "Vähiten usein esiintyvä kategoria oli ei-ylipainoiset, jotka kuluttavat mediaa vähän.",
				wrong: "Incorrect.",
				answer: false
			},
			{
				text: "Useimmin esiintyvä kategoria oli ylipainoiset, jotka kuluttavat paljon mediaa.",
				wrong: "Incorrect.",
				answer: true
			}
		],
		activeQuestion: -1,
		totalValue: 0,
		init: function()
		{
			if (this.questions.length !== 9) {
				alert("Question count missmatch! Got " + this.questions.length + " expected 9");
				return;
			}
			var value = 1;
			// Setup the Qs with redundant info

var length = this.questions.length,
element = null;
for (var i = 0; i < length; i++) {
element = this.questions[i];
element .id = i;
element .value = value;
element .state = state.READY;
value *= 2;
}
		},
		updateQState: function(question, state)
		{
			question.state = state;
			player.SetVar('tttQuestionState' + question.id, state);
		},
		/*
		 * Functions to be called from Storyline
		 */
		// Resets all the question vars to ready
		setupQuestions: function()
		{
			this.activeQuestion = null;
			this.totalValue = 0;
			player.SetVar('tttQuestionText', '');
			player.SetVar('tttSlideSolved', 0);
var length = this.questions.length,
element = null;
for (var i = 0; i < length; i++) {
element = this.questions[i];
this.updateQState(element , state.READY);
}

		},
		// For when the user picks a question
		chooseQuestion: function(quid)
		{
			var question = this.questions[quid];
			if (question.state !== state.READY)
				return;
			this.activeQuestion = question;
			player.SetVar('tttQuestionText', question.text);
		},
		// Check if the answer is correctus
		checkAnswer: function(choice)
		{
			// Get what we're talkin about
			var question = this.activeQuestion;
			// Hide the question window
var questionText = player.GetVar('tttQuestionText');
			player.SetVar('tttQuestionText', '');
			// Reset the wrong var so we can trigger it if necessary
			player.SetVar('tttQuestionWrong', '');
			// Determine failure
			var choice_ = (choice == 'true') ? true : false;
			// If you pass you're wrong and stupid
			if (choice === 'pass' || choice_ !== question.answer) {
				this.updateQState(question, state.WRONG);
				// Pop up the "no u stupid" box
				player.SetVar('tttQuestionWrong', question.wrong);

window.summary.question.push(questionText);
window.summary.answer.push(choice_);
window.summary.correct.push('Incorrect');

				return;
			}
			// success!
window.summary.question.push(questionText);
window.summary.answer.push(question.answer);
window.summary.correct.push('Correct');
			this.updateQState(question, state.RIGHT);
			this.totalValue |= question.value;
			// Check if we've won
var length = validValues.length,
value = null;
for (var i = 0; i < length; i++) {
value = validValues[i];
if  ( (this.totalValue & value) === value )
player.SetVar('tttSlideSolved', 1);
}
		}
	};
	window.ttt.init();
})();

/*
 *
 * END OF TIC-TAC-TOE GAME
 *
 */


}

function Script84()
{
  window.ttt.setupQuestions();
}

function Script85()
{
  window.ttt.setupQuestions();
}

function Script86()
{
  window.ttt.chooseQuestion(0);
}

function Script87()
{
  window.ttt.chooseQuestion(1);
}

function Script88()
{
  window.ttt.chooseQuestion(2);
}

function Script89()
{
  window.ttt.chooseQuestion(3);
}

function Script90()
{
  window.ttt.chooseQuestion(4);
}

function Script91()
{
  window.ttt.chooseQuestion(5);
}

function Script92()
{
  window.ttt.chooseQuestion(6);
}

function Script93()
{
  window.ttt.chooseQuestion(7);
}

function Script94()
{
  window.ttt.chooseQuestion(8);
}

function Script95()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


lmsAPI.RecordFillInInteraction('11', 'Completed', true, '', 'Microscope Game ', 1, 0, 'Scene2_Slide15');


}

function Script96()
{
  lmsAPI.RecordFillInInteraction('11', '', false, '', 'Microscope Game ', 1, 0, 'Scene2_Slide15');
}

function Script97()
{
  var eyesshut = 100, eyesopen = 10000, inblink = false;
var player = GetPlayer();
function blink(){
  inblink = !inblink;
  if (inblink) {
    player.SetVar('blinkState', 'hide');
    setTimeout(blink, eyesshut + Math.random() * 40);
  } else {
    player.SetVar('blinkState', 'show');
    setTimeout(blink, eyesopen + Math.random() * 500);
  }
}

blink(); 
}

function Script98()
{
  window.ttt.checkAnswer('true');
}

function Script99()
{
  window.ttt.checkAnswer('false');
}

