function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6ku8nuU5nU0":
        Script1();
        break;
      case "5x6Kw6LJHEp":
        Script2();
        break;
      case "6RgoETTL7fS":
        Script3();
        break;
      case "6mQ4cavHVSx":
        Script4();
        break;
      case "5iJsHXxT8a2":
        Script5();
        break;
      case "6rMdJsMXhyB":
        Script6();
        break;
      case "6VdyvxxQPXz":
        Script7();
        break;
      case "6a15PdE4lXo":
        Script8();
        break;
      case "5uYqiHay7Rl":
        Script9();
        break;
      case "5fFO60oGcJu":
        Script10();
        break;
      case "5xxx8zXdeXp":
        Script11();
        break;
      case "5d7HNV4XTbb":
        Script12();
        break;
      case "5xGCn7X4MEt":
        Script13();
        break;
      case "6PGjOYuTube":
        Script14();
        break;
      case "5qqgLCAavA7":
        Script15();
        break;
      case "6AtH2h21Xwj":
        Script16();
        break;
      case "5nKj8BzxVGz":
        Script17();
        break;
      case "6LKuySrxENs":
        Script18();
        break;
      case "6l2JlAbirox":
        Script19();
        break;
      case "5x7Oi1kwgwC":
        Script20();
        break;
      case "6FPgWz9UVQk":
        Script21();
        break;
      case "60f8eNxQcdQ":
        Script22();
        break;
      case "6Imbm0FibGi":
        Script23();
        break;
      case "5mRli7YMyX4":
        Script24();
        break;
      case "6R35XSZhnz5":
        Script25();
        break;
      case "5tiGQOfKrGI":
        Script26();
        break;
      case "5vdoBBgCkYY":
        Script27();
        break;
      case "5j9yUASnek7":
        Script28();
        break;
      case "6VZ5VIq9zCl":
        Script29();
        break;
      case "6DjFSwqsQm7":
        Script30();
        break;
      case "6Zkl3ezfMfd":
        Script31();
        break;
      case "5xVq2xnvDUy":
        Script32();
        break;
      case "6CQ3mIPgbiD":
        Script33();
        break;
      case "5gEimWfGmVc":
        Script34();
        break;
      case "6NSGkOH6rcY":
        Script35();
        break;
      case "6fg0GDDlV43":
        Script36();
        break;
      case "6A8ljC4OzHG":
        Script37();
        break;
      case "5zGl87m7wrl":
        Script38();
        break;
      case "6fae6aZeFyf":
        Script39();
        break;
      case "5cTCaumRDhB":
        Script40();
        break;
      case "5mskjslFdu0":
        Script41();
        break;
      case "6hI1PrOdACe":
        Script42();
        break;
      case "6Eo0AjDXFOC":
        Script43();
        break;
      case "6qQDGSrlWN7":
        Script44();
        break;
      case "6QWJPBFA8uS":
        Script45();
        break;
      case "5rTr5Hz1YTX":
        Script46();
        break;
      case "67vWH40APQt":
        Script47();
        break;
      case "5bJ5sQYKBm1":
        Script48();
        break;
      case "5WD5e5YU3Il":
        Script49();
        break;
      case "6cTRFuAxydR":
        Script50();
        break;
      case "6YuQIpFoKT3":
        Script51();
        break;
      case "6ZRaJeIAdSw":
        Script52();
        break;
      case "6d2g1ZUGgTb":
        Script53();
        break;
      case "5ta6oD4wRRC":
        Script54();
        break;
      case "6iVMMhxAu8E":
        Script55();
        break;
      case "66e9otnjKRx":
        Script56();
        break;
      case "6faQ3sikHNz":
        Script57();
        break;
      case "6XGDwfljOXR":
        Script58();
        break;
      case "6673XdQRDji":
        Script59();
        break;
      case "5iNQWON2gLB":
        Script60();
        break;
      case "5yx73s503c7":
        Script61();
        break;
      case "6nU9GRFRXqW":
        Script62();
        break;
      case "65M4E35E1OP":
        Script63();
        break;
      case "6SxxgJYFLmn":
        Script64();
        break;
      case "6bPhwF12JM3":
        Script65();
        break;
      case "6foZe6Vvxzi":
        Script66();
        break;
      case "5Xj1UBlvjpF":
        Script67();
        break;
      case "6Ik8VPlm1Ni":
        Script68();
        break;
      case "61OkDI8rurX":
        Script69();
        break;
      case "6JGF6CCCeoy":
        Script70();
        break;
      case "6cDVawVNIUj":
        Script71();
        break;
      case "6hAF3lZtmq8":
        Script72();
        break;
      case "6JY964MeWAj":
        Script73();
        break;
      case "6Ptrppndn1t":
        Script74();
        break;
      case "6UjeVIelSBP":
        Script75();
        break;
      case "6pYvFysaA0I":
        Script76();
        break;
      case "62qOWYJLb2C":
        Script77();
        break;
      case "6BNfANYO0F8":
        Script78();
        break;
      case "6aqsbMjGCbo":
        Script79();
        break;
      case "5ttAjpUDByo":
        Script80();
        break;
      case "5q2MANN2bpo":
        Script81();
        break;
      case "5glCUfktxFn":
        Script82();
        break;
      case "6TDMIJ02yyD":
        Script83();
        break;
      case "6lOZPRnlnIf":
        Script84();
        break;
      case "5z9mqrO68jw":
        Script85();
        break;
      case "6jMVgufOnwg":
        Script86();
        break;
      case "5WNCnHf0shN":
        Script87();
        break;
      case "6YLwlQxjINx":
        Script88();
        break;
      case "6BzqLXnGmRd":
        Script89();
        break;
      case "5eBxKTQGxpw":
        Script90();
        break;
      case "5k41hYMReEd":
        Script91();
        break;
      case "6qUOPjK8ZIA":
        Script92();
        break;
      case "61YlOhktaIj":
        Script93();
        break;
      case "6J11ua15NMs":
        Script94();
        break;
      case "6NFpCjFo8TP":
        Script95();
        break;
      case "6cTu3fR9CSr":
        Script96();
        break;
      case "5lVAnhbOTsX":
        Script97();
        break;
  }
}

function Script1()
{
  
/*
 *
 *   ACHIEVEMENTS
 *
 */

/*global GetPlayer:false */
var player = GetPlayer();
(function() {
	'use strict';
	window.achievements = {
		achievements: [
			{
				name: "First Question",
				desc: "You have successfully answered first question correctly.",
				advance: function()
				{
					this.completed = true;
				}
			},
			{
				name: "Three in a row",
				desc: "You have successfully answered three questions correctly in a row.",
				rowCounter: 0,
				advance: function()
				{
					var rowCounter = player.GetVar('ach3Question');
					console.log("in a row: "+rowCounter);
					if (rowCounter  == 3)
						this.completed = true;
				}
			},
			{
				name: "Hypothesis",
				desc: "You have successfully answered all hypothesis questions without any wrong answer.",
				rowCounter: 0,
				advance: function()
				{
					var isHypothesis = player.GetVar('achHypothesis');
					console.log(isHypothesis);
					if (isHypothesis  == 1)
						this.completed = true;
				}
			},
			{
				name: "All",
				desc: "You have successfully answered all of the questions correct.",
				rowCounter: 0,
				advance: function()
				{
					var isAll = player.GetVar('achAll');
					console.log(isAll);
					if (isAll  == 1)
						this.completed = true;
				}
			},
			{
				name: "",
				desc: "",
				rowCounter: 0,
				advance: function()
				{
					//In each case it will earn something
					this.completed = true;
				}
			}

		],
		completedThisRound: [],

		init: function()
		{
			for (var i = 0; i < this.achievements.length; ++i) {
				this.achievements[i].id = i;
			}
		},
		// public
		advanceAchievement: function(achid)
		{
			var ach = this.achievements[achid];
			if (!ach)
				return;
			if (ach.completed)
				return;
			ach.advance();
			if (!ach.completed)
				return;
			this.completedThisRound.push(ach);
		},
		checkForAchievements: function()
		{
			return this.completedThisRound.length > 0;
		},
		resetAchievementVars: function()
		{
			player.SetVar('achievementActive', 0);
			player.SetVar('achievementName', '');
			player.SetVar('achievementDesc', '');
			player.SetVar('achivementId', -1);
		},
		setupAchievementVars: function()
		{
			var ach = this.completedThisRound.shift();
			player.SetVar('achievementActive', 1);
			player.SetVar('achievementName', ach.name);
			player.SetVar('achievementDesc', ach.desc);
			player.SetVar('achivementId', ach.id);
			player.SetVar('achievementUnlocked' + ach.id, 1);
		},
		// public
		doEverythingAtOnce: function()
		{
			this.resetAchievementVars();
			if (this.checkForAchievements())
				this.setupAchievementVars();

		}
	};
	window.achievements.init();
})();

/*
 *
 *  END OF ACHIEVEMENTS 
 *
 */

}

function Script2()
{
  var eyesshut = 100, eyesopen = 10000, inblink = false;
var player = GetPlayer();
var isPopUp = player.GetVar("isPopUp");
function blink(){
  inblink = !inblink;
 if (isPopUp == 1) {
 setTimeout(blink, 100);
}
  else if (inblink) {
    player.SetVar('blinkState', 'hide');
    setTimeout(blink, eyesshut + Math.random() * 100);
  } else {
    player.SetVar('blinkState', 'show');
    setTimeout(blink, eyesopen + Math.random() * 1000);
  }
}

blink(); 

window.summary = {question: [], answer: [], correct: []}; 
}

function Script3()
{
  var player = GetPlayer();
player.SetVar("answerM1", "");
player.SetVar("answerM2", "");
player.SetVar("answerM3", "");
player.SetVar("answerM4", "");
player.SetVar("answerM5", "");
player.SetVar("answerM6", "");
}

function Script4()
{
  player = GetPlayer();
answer = player.GetVar("answerM2");

 window.summary.question.push('Formulate the null-hypothesis by selecting the correct sentence parts - Part1');
  window.summary.answer.push(answer);
  window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('6', answer, false, '', 'Null-hypothesis Part 1 ', 1, 0, 'Scene2_Slide6_1');
}

function Script5()
{
  player = GetPlayer();
answer1 = player.GetVar("answerM4");
answer2 = player.GetVar("answerM3");

 window.summary.question.push('Formulate the null-hypothesis by selecting the correct sentence parts - Part2');
  window.summary.answer.push(answer1 + answer2);
  window.summary.correct.push('Incorrect');

var answersum = answer1 + answer2;

lmsAPI.RecordFillInInteraction('7', answersum, false, '', 'Null-hypothesis Part 2 ', 1, 0, 'Scene2_Slide6_2');
}

function Script6()
{
  player = GetPlayer();
answer1 = player.GetVar("answerM5");
answer2 = player.GetVar("answerM6");

 window.summary.question.push('Formulate the null-hypothesis by selecting the correct sentence parts - Part3');
  window.summary.answer.push(answer1 + answer2);
  window.summary.correct.push('Incorrect');

var answersum = answer1 + answer2;

lmsAPI.RecordFillInInteraction('8', answersum, false, '', 'Null-hypothesis Part 3 ', 1, 0, 'Scene2_Slide6_3');
}

function Script7()
{
    window.summary.question.push('Formulate the null-hypothesis by selecting the correct sentence parts - Part1');
  window.summary.answer.push('There will be no relationship');
  window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('6', 'There will be no relationship', true, '', 'Null-hypothesis Part 1 ', 1, 0, 'Scene2_Slide6_1');
}

function Script8()
{
    window.summary.question.push('Formulate the null-hypothesis by selecting the correct sentence parts - Part2');
  window.summary.answer.push('between gender');
  window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('7', 'between gender', true, '', 'Null-hypothesis Part 2 ', 1, 0, 'Scene2_Slide6_2');
}

function Script9()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script10()
{
    window.summary.question.push('Formulate the null-hypothesis by selecting the correct sentence parts - Part3');
  window.summary.answer.push('and the reward which was selected');
  window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('8', 'and the reward which was selected', true, '', 'Null-hypothesis Part 3 ', 1, 0, 'Scene2_Slide6_3');
}

function Script11()
{
  var player = GetPlayer();
var score = player.GetVar('score');
var playerName = player.GetVar('playerName');
var rank;
window.clearTimeout(timeVar);

//Score
if( score >= 1500 )
 rank = "A";
else if( score >= 1400 )
 rank = "B";
else if( score >= 1300 )
 rank = "C";
else if( score >= 1200 )
 rank = "D";
else 
 rank = "E";

player.SetVar('rank', rank);

//Time
function zeroPad(num, places) {
  var zero = places - num.toString().length + 1;
  return Array(+(zero > 0 && zero)).join("0") + num;
}

var time = player.GetVar('time');

var minutes = Math.floor(time / 60);
var seconds = time - minutes * 60;

minutes  = zeroPad(minutes, 2);
seconds  = zeroPad(seconds, 2);

var NewTime = minutes+":"+seconds;
player.SetVar('timeLast', NewTime );

player.SetVar("answerM1", "");
player.SetVar("answerM2", "");
player.SetVar("answerM3", "");
player.SetVar("answerM4", "");
player.SetVar("answerM5", "");
player.SetVar("answerM6", "");

lmsAPI.RecordFillInInteraction('14', score, true, '', 'Score ', 1, 0, 'Scene2_Slide8');
lmsAPI.RecordFillInInteraction('15', NewTime, true, '', 'Playing Time ', 1, 0, 'Scene2_Slide8');

lmsAPI.SetPassed();
player = GetPlayer();
var correct = player.GetVar("correctcounter");
var question = player.GetVar("questioncounter");

var score = ( correct / question ) * 100;
score =  Math.round( Number(score));
player.SetVar("calculatedscore", score);
player.SetVar("calculatedcorrect",correct);
player.SetVar("calculatedquestion",question);

lmsAPI.SetScore(score,100,0);

lmsAPI.RecordFillInInteraction('16', playerName, true, '', 'Player Name ', 1, 0, 'Scene2_Slide8');

lmsAPI.RecordFillInInteraction('17', Rank, true, '', 'Rank ', 1, 0, 'Scene2_Slide8');

}

function Script12()
{
  window.timelast = player.GetVar('timeLast');
window.rank = player.GetVar('rank');
window.score = player.GetVar('score');
}

function Script13()
{
  var answersum = "";

if ( player.GetVar('answerM1') !== "")
   answersum +=  player.GetVar('answerM1') + ", ";
if ( player.GetVar('answerM2') !== "")
   answersum +=  player.GetVar('answerM2') + ", ";
if ( player.GetVar('answerM3') !== "")
   answersum +=  player.GetVar('answerM3') + ", ";
if ( player.GetVar('answerM4') !== "")
   answersum +=  player.GetVar('answerM4') + ", ";

lmsAPI.RecordFillInInteraction('18', answersum, true, '', 'Achievements ', 1, 0, 'Scene2_Slide8');
}

function Script14()
{
  var player = GetPlayer();
var formHTML = "<style>table {border-collapse:collapse;margin-top:20px;color:#373737} table, tr, td {padding: 10px;}tr:nth-child(even) {background:#E3F3EF; }tr:nth-child(odd) {background:#C7F1E6; }tr.header{background:#008A6E;color:white;font-weight:bold; }.logo { margin-bottom:10px;} .name {text-transform:uppercase;font-size:24px;font-weight:bold;color:#008A6E;}.label {font-weight:bold;}.logo span {font-size:27px; font-weight: bold; text-decoration:underline; color:#373737 } .logo img {float:right;}</style>";

var answersum = "";

if ( player.GetVar('answerM1') !== "")
   answersum +=  player.GetVar('answerM1') + ", ";
if ( player.GetVar('answerM2') !== "")
   answersum +=  player.GetVar('answerM2') + ", ";
if ( player.GetVar('answerM3') !== "")
   answersum +=  player.GetVar('answerM3') + ", ";
if ( player.GetVar('answerM4') !== "")
   answersum +=  player.GetVar('answerM4') + ", ";

formHTML += "<div class='logo'><span>Gender and Reward Selected</span><img src='http://www.playgen.com/chermug/chermug_logo.jpg'></div>";
formHTML += "<span class='name'>" +  player.GetVar('playerName')+ "</span><br/>";
formHTML += "<span class='label'>Score:</span> " + player.GetVar('score') + "<br/>";
formHTML += "<span class='label'>Rank:</span> " + player.GetVar('rank') + "<br/>";
formHTML += "<span class='label'>Time:</span> " + player.GetVar('timeLast') + "<br/>";
formHTML += "<span class='label'>Achievements:</span> " + answersum + "<br/>";

formHTML += "<table><tr class='header'><td>ID</td><td>Question</td><td>Answered</td><td>Correct/Incorrect</td></tr>";

var length = window.summary.question.length;
var question = null;
var answer = null;
var correct = null;

for (var i = 0; i < length; i++) {
question = window.summary.question[i];
answer = window.summary.answer[i];
correct = window.summary.correct[i];
id = i + 1;

formHTML += "<tr><td>" + id + "</td><td>" + question + "</td><td>" + answer + "</td><td>" + correct + "</td></tr>";

}

formHTML += "</table>";

formHTML += "<script>window.print();</script>";

var preview = window.open("about:blank");
preview.document.open();
preview.document.write(formHTML);
preview.document.close();
preview.print();
}

function Script15()
{
  var seconds=0;
timeVar = setTimeout(startTime,1000);

 
function startTime(){
seconds=seconds+1;
var player = GetPlayer();
player.SetVar("time",seconds);
timeVar = setTimeout(startTime,1000);
}
 
}

function Script16()
{
  player = GetPlayer();
answer1 = player.GetVar("answerM1");
answer2 = player.GetVar("answerM2");
answer3 = player.GetVar("answerM3");
answer4 = player.GetVar("answerM4");
answer5 = player.GetVar("answerM5");
answer6 = player.GetVar("answerM6");

var answersum = "";

if ( answer1 !== "")
   answersum += answer1 + ", ";
if ( answer2 !== "")
   answersum += answer2 + ", ";
if ( answer3 !== "")
   answersum += answer3 + ", ";
if ( answer4 !== "")
   answersum += answer4 + ", ";
if ( answer5 !== "")
   answersum += answer5 + ", ";
if ( answer6 !== "")
   answersum += answer6;




 window.summary.question.push('In the study what are the main variables?');
  window.summary.answer.push(answersum);
  window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('1', answersum, false, '', 'In the study what are the main variables?', 1, 0, 'Scene2_Slide9_1');
}

function Script17()
{
  window.achievements.advanceAchievement(0);
window.achievements.doEverythingAtOnce();
}

function Script18()
{
    window.summary.question.push('In the study what are the main variables?');
  window.summary.answer.push('Gender, Reward Selected');
  window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('1', 'Gender, Reward Selected', true, '', 'In the study what are the main variables?', 1, 0, 'Scene2_Slide9_1');
}

function Script19()
{
  var player = GetPlayer();
player.SetVar("answerM1", "");
player.SetVar("answerM2", "");
player.SetVar("answerM3", "");
player.SetVar("answerM4", "");
player.SetVar("answerM5", "");
player.SetVar("answerM6", "");
}

function Script20()
{
    window.summary.question.push('In this study what are the levels of the two variables, gender and reward selected?');
  window.summary.answer.push('Male, Female, Chocolate, Crisps');
  window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('2', 'Male, Female, Chocolate, Crisps', true, '', 'In this study what are the levels of the two variables, gender and reward selected?', 1, 0, 'Scene2_Slide9_2');
}

function Script21()
{
  player = GetPlayer();
answer1 = player.GetVar("answerM1");
answer2 = player.GetVar("answerM2");
answer3 = player.GetVar("answerM3");
answer4 = player.GetVar("answerM4");
answer5 = player.GetVar("answerM5");
answer6 = player.GetVar("answerM6");

var answersum = "";

if ( answer1 !== "")
   answersum += answer1 + ", ";
if ( answer2 !== "")
   answersum += answer2 + ", ";
if ( answer3 !== "")
   answersum += answer3 + ", ";
if ( answer4 !== "")
   answersum += answer4 + ", ";
if ( answer5 !== "")
   answersum += answer5 + ", ";
if ( answer6 !== "")
   answersum += answer6;

 window.summary.question.push('In this study what are the levels of the two variables, gender and reward selected?');
  window.summary.answer.push(answersum);
  window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('2', answersum, false, '', 'In this study what are the levels of the two variables, gender and reward selected?', 1, 0, 'Scene2_Slide9_2');
}

function Script22()
{
  
/*
 *
 * HANGMAN GAME
 *
 */

/*global GetPlayer:false */
var player = GetPlayer();
(function() {
	'use strict';
	window.hangman = {
		//Use capital letters
		questions: ["NOMINAL"],
		activeQuestion: -1,
		question: '',
		chars: [],
		foundChars: {},
		foundLetters: 0,
		alphabet: ["A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z", "Ex"],
		init: function()
		{
			//console.log("init");

		},
		/*
		 * Functions to be called from Storyline
		 */
		// Setup question and the word into letters
		setupQuestions: function(questionnumber)
		{
			this.foundLetters = 0;
			this.activeQuestion = questionnumber;
			this.question = this.questions[this.activeQuestion-1];
			this.chars = this.question.split('');
			this.foundChars = {};
			for (var i = this.alphabet.length - 1; i >= 0; i--)
				player.SetVar("hmChange"+ this.alphabet[i], 0);


		},
		// Check if any letter or the answer is found
		letterPressed: function(letter)
		{
			if (this.foundChars[letter])
				return;
			player.SetVar("hmChangeSet", 0);
			var found = 0;
			for (var i = this.chars.length - 1; i >= 0; i--) {
				var pos = i+1;
				if(this.chars[i] == letter) {
					player.SetVar("hml"  + pos, letter);
					found = 1;
					this.foundLetters++;
					this.foundChars[letter] = true;
					if (this.foundLetters >= this.chars.length) {
						player.SetVar("hmAnswerFound", 1);
					}	
				}
			}
			if( found != 1) {
				//cant put ! in the stroyline var
				if (letter == "!")
					letter = "Ex";

				var isPressed = player.GetVar("hmChange"+letter);
				if( isPressed == 0) {
				var tleft = player.GetVar("hmtleft");
				tleft = tleft -1;
				player.SetVar("hmtleft", tleft);
				player.SetVar("hmChange"+ letter, 1);
				}
			}
		 

			return;
		}
	};
	window.hangman.init();
})();

/*
 *
 * END OF HANGMAN GAME
 *
 */


}

function Script23()
{
  var seconds=3000;
// display();
var blinkTimer = setTimeout(display,400);
var flag = 0;
 
function display(){
	seconds=seconds-1;
	var player = GetPlayer();
	var tleft = player.GetVar("hmtleft");
	player.SetVar("hmtimer",seconds);
	if( tleft != 9) {
		if(flag == 0) {
			player.SetVar("hmBlink","hide");
			flag = 1;
		}
		else {
		player.SetVar("hmBlink","show");
		flag = 0;
		}
		var blinkTimer = setTimeout(display,400);
	}
	else 
	player.SetVar("hmBlink","show");
}
 
}

function Script24()
{
  window.hangman.setupQuestions(1);
}

function Script25()
{
  window.hangman.letterPressed("B");
}

function Script26()
{
  window.hangman.letterPressed("C");
}

function Script27()
{
  window.hangman.letterPressed("D");
}

function Script28()
{
  window.hangman.letterPressed("E");
}

function Script29()
{
  window.hangman.letterPressed("F");
}

function Script30()
{
  window.hangman.letterPressed("G");
}

function Script31()
{
  window.hangman.letterPressed("H");
}

function Script32()
{
  window.hangman.letterPressed("I");
}

function Script33()
{
  window.hangman.letterPressed("J");
}

function Script34()
{
  window.hangman.letterPressed("K");
}

function Script35()
{
  window.hangman.letterPressed("L");
}

function Script36()
{
  window.hangman.letterPressed("M");
}

function Script37()
{
  window.hangman.letterPressed("N");
}

function Script38()
{
  window.hangman.letterPressed("O");
}

function Script39()
{
  window.hangman.letterPressed("P");
}

function Script40()
{
  window.hangman.letterPressed("Q");
}

function Script41()
{
  window.hangman.letterPressed("R");
}

function Script42()
{
  window.hangman.letterPressed("S");
}

function Script43()
{
  window.hangman.letterPressed("T");
}

function Script44()
{
  window.hangman.letterPressed("U");
}

function Script45()
{
  window.hangman.letterPressed("V");
}

function Script46()
{
  window.hangman.letterPressed("W");
}

function Script47()
{
  window.hangman.letterPressed("X");
}

function Script48()
{
  window.hangman.letterPressed("Y");
}

function Script49()
{
  window.hangman.letterPressed("Z");
}

function Script50()
{
  window.hangman.letterPressed("!");
}

function Script51()
{
  window.hangman.letterPressed("A");
}

function Script52()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script53()
{
    window.summary.question.push('In the study, what level of measurement is appropriate for the gender of dieters?');
  window.summary.answer.push('Nominal');
  window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('3', 'Nominal', true, '', 'In the study, what level of measurement is appropriate for the gender of dieters?', 1, 0, 'Scene2_Slide10');
}

function Script54()
{
    window.summary.question.push('In the study, what level of measurement is appropriate for the gender of dieters?');
  window.summary.answer.push('');
  window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('3', '', false, '', 'In the study, what level of measurement is appropriate for the gender of dieters?', 1, 0, 'Scene2_Slide10');
}

function Script55()
{
  var seconds=4;
//setTimeout(display,1000);
display();
 
function display(){
seconds=seconds-1;
var player = GetPlayer();
player.SetVar("hmcready",seconds);
var cready = player.GetVar("hmcready");
if ( cready == 0) {
player.SetVar("hmcready", "Go!");
setTimeout(display,1000);
}
else if ( cready == -1) {
player.SetVar("hmcready", "next");
}
else {
setTimeout(display,1000);
}
}
}

function Script56()
{
  var player = GetPlayer();
var name= player.GetVar('achievementName');
var desc = player.GetVar('achievementDesc');

console.log("name:" + name);
console.log("description" + desc);
}

function Script57()
{
  window.hangman.setupQuestions(1);
var seconds=4;
//setTimeout(display,1000);
display();
 
function display(){
seconds=seconds-1;
var player = GetPlayer();
player.SetVar("hmcready",seconds);
var cready = player.GetVar("hmcready");
if ( cready == 0) {
player.SetVar("hmcready", "Go!");
setTimeout(display,1000);
}
else if ( cready == -1) {
player.SetVar("hmcready", "next");
setTimeout(display,1000);
}
else {
setTimeout(display,1000);
}
}
}

function Script58()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script59()
{
    window.summary.question.push('In the study what level of measurement is appropriate for reward selected?');
  window.summary.answer.push('Nominal');
  window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('4', 'Nominal', true, '', 'In the study what level of measurement is appropriate for reward selected? ', 1, 0, 'Scene2_Slide11_1');
}

function Script60()
{
  var player = GetPlayer();  
var answer = player.GetVar('answer');
window.summary.question.push('In the study what level of measurement is appropriate for reward selected?');
window.summary.answer.push(answer);
window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('4', answer, false, '', 'In the study what level of measurement is appropriate for reward selected? ', 1, 0, 'Scene2_Slide11_1');
}

function Script61()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script62()
{
    window.summary.question.push('Which kind of design does this study suggest?');
  window.summary.answer.push('an association between variables.');
  window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('5', 'an association between variables', true, '', 'Which kind of design does this study suggest? ', 1, 0, 'Scene2_Slide11_2');
}

function Script63()
{
    window.summary.question.push('Which kind of design does this study suggest?');
  window.summary.answer.push('differences between groups');
  window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('5', 'differences between groups', false, '', 'Which kind of design does this study suggest? ', 1, 0, 'Scene2_Slide11_2');
}

function Script64()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script65()
{
    window.summary.question.push('Which raw data set below is the correct one to test your data?');
  window.summary.answer.push('Dataset1');
  window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('9', 'Dataset1', true, '', 'Which raw data set below is the correct one to test your data? ', 1, 0, 'Scene2_Slide12');
}

function Script66()
{
    window.summary.question.push('Which raw data set below is the correct one to test your data?');
  window.summary.answer.push('Dataset2');
  window.summary.correct.push('Inorrect');

lmsAPI.RecordFillInInteraction('9', 'Dataset2', false, '', 'Which raw data set below is the correct one to test your data? ', 1, 0, 'Scene2_Slide12');
}

function Script67()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script68()
{
  player = GetPlayer();  
var answer = player.GetVar('answer');

window.summary.question.push('Which data summary would you like to see the data represented in?');
window.summary.answer.push(answer);
window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('10', answer, true, '', 'Which data summary would you like to see the data represented in? ', 1, 0, 'Scene2_Slide13');

}

function Script69()
{
  player = GetPlayer();  
var answer = player.GetVar('answer');

window.summary.question.push('Which data summary would you like to see the data represented in?');
window.summary.answer.push(answer);
window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('10', answer, false, '', 'Which data summary would you like to see the data represented in? ', 1, 0, 'Scene2_Slide13');
}

function Script70()
{
  player = GetPlayer();  
var answer = player.GetVar('answer');

window.summary.question.push('Which data summary would you like to see the data represented in?');
window.summary.answer.push(answer);
window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('10', answer, false, '', 'Which data summary would you like to see the data represented in? ', 1, 0, 'Scene2_Slide13');
}

function Script71()
{
  player = GetPlayer();  
var answer = player.GetVar('answer');

window.summary.question.push('Which data summary would you like to see the data represented in?');
window.summary.answer.push(answer);
window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('10', answer, false, '', 'Which data summary would you like to see the data represented in? ', 1, 0, 'Scene2_Slide13');
}

function Script72()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script73()
{
  player = GetPlayer();  
var answer = player.GetVar('answer');

window.summary.question.push('Which test statistic would you like to see?');
window.summary.answer.push(answer);
window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('12', answer, true, '', 'Which test statistic would you like to see? ', 1, 0, 'Scene2_Slide14');
}

function Script74()
{
  player = GetPlayer();  
var answer = player.GetVar('answer');

window.summary.question.push('Which test statistic would you like to see?');
window.summary.answer.push(answer);
window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('12', answer, false, '', 'Which test statistic would you like to see? ', 1, 0, 'Scene2_Slide14');
}

function Script75()
{
  player = GetPlayer();  
var answer = player.GetVar('answer');

window.summary.question.push('Which test statistic would you like to see?');
window.summary.answer.push(answer);
window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('12', answer, false, '', 'Which test statistic would you like to see? ', 1, 0, 'Scene2_Slide14');
}

function Script76()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}

var time = player.GetVar('time');
//Bronze Gold Silver
if( time <= 15000 && time > 1200 ) {
player.SetVar("achQuestionBronze",1);
}
if( time>= 10000 &&  time <= 12000) {
player.SetVar("achQuestionBronze",0);
player.SetVar("achQuestionSilver",1);
}
if( time < 10000 ) {
player.SetVar("achQuestionSilver",0);
player.SetVar("achQuestionGold",1);
}
}

function Script77()
{
  window.achievements.advanceAchievement(3);
window.achievements.doEverythingAtOnce();

window.achievements.advanceAchievement(4);
window.achievements.doEverythingAtOnce();




}

function Script78()
{
  window.summary.question.push('The critical value of chi square for 2*2 contingency table at .05 level of significance is 3.84');
window.summary.answer.push('Yes');
window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('13', 'Yes', true, '', 'The critical value of chi square for 2*2 contingency table at .05 level of significance is 3.84 ', 1, 0, 'Scene2_Slide14_2');
}

function Script79()
{
  var player = GetPlayer();
var time = player.GetVar('time');
//Bronze Gold Silver
if( time <= 15000 && time > 1200 ) {
player.SetVar("achQuestionBronze",1);
}
if( time>= 10000 &&  time <= 12000) {
player.SetVar("achQuestionBronze",0);
player.SetVar("achQuestionSilver",1);
}
if( time < 10000 ) {
player.SetVar("achQuestionSilver",0);
player.SetVar("achQuestionGold",1);
}

window.achievements.advanceAchievement(4);
window.achievements.doEverythingAtOnce();
}

function Script80()
{
  window.summary.question.push('The critical value of chi square for 2*2 contingency table at .05 level of significance is 3.84');
window.summary.answer.push('No');
window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('13', 'No', false, '', 'The critical value of chi square for 2*2 contingency table at .05 level of significance is 3.84 ', 1, 0, 'Scene2_Slide14_2');
}

function Script81()
{
  
/*
 *
 * TIC-TAC-TOE GAME
 *
 */

/*global GetPlayer:false */
var player = GetPlayer();
(function() {
	'use strict';
	var state = {
		READY: 0,
		RIGHT: 1,
		WRONG: 2
	};
	var validValues = [
		// Rows
		1  | 2   | 4,
		8  | 16  | 32,
		64 | 128 | 256,
		// Columns
		1  | 8   | 64,
		2  | 16  | 128,
		4  | 32  | 256,
		// Diagonals
		1 | 16 | 256,
		4 | 16 | 64
	];
	window.ttt = {
		questions: [
			{
				text: "There were 200 participants altogether in this study.",
				wrong: "Incorrect.",
				answer: false
			},
			{
				text: "Half the participants were male and half were female.",
				wrong: "Incorrect.",
				answer: true
			},
			{
				text: "Altogether there were more people in the sample who chose crisps than who chose chocolate.",
				wrong: "Incorrect.",
				answer: false
			},
			{
				text: "There were more females in the sample who chose chocolate  than who chose crisps.",
				wrong: "Incorrect.",
				answer: true
			},
			{
				text: "There were more females than males in the sample who chose crisps.",
				wrong: "Incorrect.",
				answer: false
			},
			{
				text: "There were more males in the sample who chose chocolate than who chose crisps.",
				wrong: "Incorrect.",
				answer: true
			},
			{
				text: "Altogether there were more people in the sample who chose chocolate than who chose crisps.",
				wrong: "Incorrect.",
				answer: true
			},
			{
				text: "The pattern of choices was different for males and females.",
				wrong: "Incorrect.",
				answer: true
			},
			{
				text: "Half the participants chose chocolate and half chose crisps.",
				wrong: "Incorrect.",
				answer: false
			}
		],
		activeQuestion: -1,
		totalValue: 0,
		init: function()
		{
			if (this.questions.length !== 9) {
				alert("Question count missmatch! Got " + this.questions.length + " expected 9");
				return;
			}
			var value = 1;
			// Setup the Qs with redundant info

var length = this.questions.length,
element = null;
for (var i = 0; i < length; i++) {
element = this.questions[i];
element .id = i;
element .value = value;
element .state = state.READY;
value *= 2;
}
		},
		updateQState: function(question, state)
		{
			question.state = state;
			player.SetVar('tttQuestionState' + question.id, state);
		},
		/*
		 * Functions to be called from Storyline
		 */
		// Resets all the question vars to ready
		setupQuestions: function()
		{
			this.activeQuestion = null;
			this.totalValue = 0;
			player.SetVar('tttQuestionText', '');
			player.SetVar('tttSlideSolved', 0);
var length = this.questions.length,
element = null;
for (var i = 0; i < length; i++) {
element = this.questions[i];
this.updateQState(element , state.READY);
}

		},
		// For when the user picks a question
		chooseQuestion: function(quid)
		{
			var question = this.questions[quid];
			if (question.state !== state.READY)
				return;
			this.activeQuestion = question;
			player.SetVar('tttQuestionText', question.text);
		},
		// Check if the answer is correctus
		checkAnswer: function(choice)
		{
			// Get what we're talkin about
			var question = this.activeQuestion;
			// Hide the question window
var questionText = player.GetVar('tttQuestionText');
			player.SetVar('tttQuestionText', '');
			// Reset the wrong var so we can trigger it if necessary
			player.SetVar('tttQuestionWrong', '');
			// Determine failure
			var choice_ = (choice == 'true') ? true : false;
			// If you pass you're wrong and stupid
			if (choice === 'pass' || choice_ !== question.answer) {
				this.updateQState(question, state.WRONG);
				// Pop up the "no u stupid" box
				player.SetVar('tttQuestionWrong', question.wrong);

window.summary.question.push(questionText);
window.summary.answer.push(choice_);
window.summary.correct.push('Incorrect');

				return;
			}
			// success!
window.summary.question.push(questionText);
window.summary.answer.push(question.answer);
window.summary.correct.push('Correct');
			this.updateQState(question, state.RIGHT);
			this.totalValue |= question.value;
			// Check if we've won
var length = validValues.length,
value = null;
for (var i = 0; i < length; i++) {
value = validValues[i];
if  ( (this.totalValue & value) === value )
player.SetVar('tttSlideSolved', 1);
}
		}
	};
	window.ttt.init();
})();

/*
 *
 * END OF TIC-TAC-TOE GAME
 *
 */


}

function Script82()
{
  window.ttt.setupQuestions();
}

function Script83()
{
  window.ttt.setupQuestions();
}

function Script84()
{
  window.ttt.chooseQuestion(0);
}

function Script85()
{
  window.ttt.chooseQuestion(1);
}

function Script86()
{
  window.ttt.chooseQuestion(2);
}

function Script87()
{
  window.ttt.chooseQuestion(3);
}

function Script88()
{
  window.ttt.chooseQuestion(4);
}

function Script89()
{
  window.ttt.chooseQuestion(5);
}

function Script90()
{
  window.ttt.chooseQuestion(6);
}

function Script91()
{
  window.ttt.chooseQuestion(7);
}

function Script92()
{
  window.ttt.chooseQuestion(8);
}

function Script93()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}

lmsAPI.RecordFillInInteraction('11', 'Completed', true, '', 'Microscope Game ', 1, 0, 'Scene2_Slide15');




}

function Script94()
{
  lmsAPI.RecordFillInInteraction('11', '', false, '', 'Microscope Game ', 1, 0, 'Scene2_Slide15');
}

function Script95()
{
  var eyesshut = 100, eyesopen = 10000, inblink = false;
var player = GetPlayer();
function blink(){
  inblink = !inblink;
  if (inblink) {
    player.SetVar('blinkState', 'hide');
    setTimeout(blink, eyesshut + Math.random() * 40);
  } else {
    player.SetVar('blinkState', 'show');
    setTimeout(blink, eyesopen + Math.random() * 500);
  }
}

blink(); 
}

function Script96()
{
  window.ttt.checkAnswer('true');
}

function Script97()
{
  window.ttt.checkAnswer('false');
}

