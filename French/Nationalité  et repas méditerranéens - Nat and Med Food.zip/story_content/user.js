function ExecuteScript(strId)
{
  switch (strId)
  {
      case "62DAVW68M6F":
        Script1();
        break;
      case "69pEHGw8Vb6":
        Script2();
        break;
      case "6ie5tl9R7OD":
        Script3();
        break;
      case "5wbrbSyxFkP":
        Script4();
        break;
      case "631FSNLLcS9":
        Script5();
        break;
      case "5W3tE8MOmfm":
        Script6();
        break;
      case "6bD1RxuElvQ":
        Script7();
        break;
      case "6how5JivnCE":
        Script8();
        break;
      case "6VeOCLVM1yr":
        Script9();
        break;
      case "6r2R9tmypOT":
        Script10();
        break;
      case "6NX48snRfkE":
        Script11();
        break;
      case "61fXvnDKUH3":
        Script12();
        break;
      case "6rdCpwmd4Kc":
        Script13();
        break;
      case "6jaGq06enrp":
        Script14();
        break;
      case "602UE5IegZ2":
        Script15();
        break;
      case "63mnO2cbQMR":
        Script16();
        break;
      case "6OQqJsRlIOe":
        Script17();
        break;
      case "5n7aXzmlzqs":
        Script18();
        break;
      case "6IWsZHAoV9s":
        Script19();
        break;
      case "6L0vHoahbNZ":
        Script20();
        break;
      case "5dGUaUoj4IU":
        Script21();
        break;
      case "69AN9TItP0A":
        Script22();
        break;
      case "5qDyfwjTJox":
        Script23();
        break;
      case "5a6yDJ4qxXQ":
        Script24();
        break;
      case "6fKpL3A2lg8":
        Script25();
        break;
      case "69ReGK1lZS8":
        Script26();
        break;
      case "5h2TN2t9i1a":
        Script27();
        break;
      case "6OSLF7VYMVM":
        Script28();
        break;
      case "5txkYjXHPIT":
        Script29();
        break;
      case "5tpX3Y57Abn":
        Script30();
        break;
      case "61hveAkIt8p":
        Script31();
        break;
      case "6c6pN3fHRFD":
        Script32();
        break;
      case "6I696aldp4r":
        Script33();
        break;
      case "5oehxkZQTj8":
        Script34();
        break;
      case "5YUqGPxWs5g":
        Script35();
        break;
      case "6OR3HxQ0Hr7":
        Script36();
        break;
      case "5zZVO64umVe":
        Script37();
        break;
      case "5jUpGwxDEPh":
        Script38();
        break;
      case "6g1I22KMNma":
        Script39();
        break;
      case "6331hiKNqlm":
        Script40();
        break;
      case "61alffPnZrX":
        Script41();
        break;
      case "5ZVBJdSdwit":
        Script42();
        break;
      case "5nt9PQTqHjd":
        Script43();
        break;
      case "6PHObuzIOiI":
        Script44();
        break;
      case "5lMylw7zLvk":
        Script45();
        break;
      case "6RIB6Wuzsne":
        Script46();
        break;
      case "5hFlNHCaWYc":
        Script47();
        break;
      case "5qKxY5hPPCa":
        Script48();
        break;
      case "6EcINOyVL0D":
        Script49();
        break;
      case "63zyc0eeBhz":
        Script50();
        break;
      case "6EqeL1HD8F3":
        Script51();
        break;
      case "6nYXRLOus92":
        Script52();
        break;
      case "6okRi6r4M9f":
        Script53();
        break;
      case "67hOKkOKCU6":
        Script54();
        break;
      case "6cmZPhYol6a":
        Script55();
        break;
      case "5nHwYMfFWZT":
        Script56();
        break;
      case "67XVHjDGXNv":
        Script57();
        break;
      case "5UwJEQMqMAs":
        Script58();
        break;
      case "5VnAKljyJWb":
        Script59();
        break;
      case "6nGZ3dsYzGi":
        Script60();
        break;
      case "5baxqtWLXCw":
        Script61();
        break;
      case "6NFzW0RqciF":
        Script62();
        break;
      case "6TCXFQEWLw8":
        Script63();
        break;
      case "5zm6jsU5LJU":
        Script64();
        break;
      case "69XC6700utS":
        Script65();
        break;
      case "6rf6WBvSGgo":
        Script66();
        break;
      case "6TXohFRF6WI":
        Script67();
        break;
      case "6A4lYZ1tbCI":
        Script68();
        break;
      case "6MXCB80rmr4":
        Script69();
        break;
      case "5x9UwfmvSYh":
        Script70();
        break;
      case "6QBdJpAb33Y":
        Script71();
        break;
      case "64pSyVIRyvI":
        Script72();
        break;
      case "6h8KEVMDc5j":
        Script73();
        break;
      case "5g0t1dW0SiH":
        Script74();
        break;
      case "5kV9GdkLYiG":
        Script75();
        break;
      case "5t8y3LnHSsV":
        Script76();
        break;
      case "5X6BgI1VkaY":
        Script77();
        break;
      case "6p7D1LiSIJT":
        Script78();
        break;
      case "6WK2q8bj3i0":
        Script79();
        break;
      case "6BcHnDGQhOT":
        Script80();
        break;
      case "6fZdhMN25Lh":
        Script81();
        break;
      case "5pjMT1u84DQ":
        Script82();
        break;
      case "6etPvTFmN2q":
        Script83();
        break;
      case "63kBYtwaPGj":
        Script84();
        break;
      case "5idKjoPTIU1":
        Script85();
        break;
      case "6Mdyd19nw8O":
        Script86();
        break;
      case "5Zc6iz1dR92":
        Script87();
        break;
      case "6r1TEvD5hWn":
        Script88();
        break;
      case "5prgEKGlBEL":
        Script89();
        break;
      case "5m83JzrMRN3":
        Script90();
        break;
      case "6oUvXn9N4MV":
        Script91();
        break;
      case "5XA2Ytwijww":
        Script92();
        break;
      case "6JLOm0CvnL6":
        Script93();
        break;
      case "6W0vJLYq5m6":
        Script94();
        break;
      case "5f7W3YvxtRC":
        Script95();
        break;
      case "5vOqztxQJRz":
        Script96();
        break;
      case "6Ne3h7ngOb8":
        Script97();
        break;
      case "6BiKw578oeE":
        Script98();
        break;
      case "6YxLQnGgzt8":
        Script99();
        break;
      case "5q1mE26Nvn8":
        Script100();
        break;
      case "5yl2Q7PgNz1":
        Script101();
        break;
      case "5dLWuVH2Inb":
        Script102();
        break;
      case "62KNnrERkuz":
        Script103();
        break;
      case "6irF35pUYQj":
        Script104();
        break;
  }
}

function Script1()
{
  
/*
 *
 *   ACHIEVEMENTS
 *
 */

/*global GetPlayer:false */
var player = GetPlayer();
(function() {
	'use strict';
	window.achievements = {
		achievements: [
			{
				name: "First Question",
				desc: "You have successfully answered first question correctly.",
				advance: function()
				{
					this.completed = true;
				}
			},
			{
				name: "Three in a row",
				desc: "You have successfully answered three questions correctly in a row.",
				rowCounter: 0,
				advance: function()
				{
					var rowCounter = player.GetVar('ach3Question');
					if (rowCounter  == 3)
						this.completed = true;
				}
			},
			{
				name: "Hypothesis",
				desc: "You have successfully answered all hypothesis questions without any wrong answer.",
				rowCounter: 0,
				advance: function()
				{
					var isHypothesis = player.GetVar('achHypothesis');
					console.log(isHypothesis);
					if (isHypothesis  == 1)
						this.completed = true;
				}
			},
			{
				name: "All",
				desc: "You have successfully answered all of the questions correct.",
				rowCounter: 0,
				advance: function()
				{
					var isAll = player.GetVar('achAll');
					console.log(isAll);
					if (isAll  == 1)
						this.completed = true;
				}
			},
			{
				name: "",
				desc: "",
				rowCounter: 0,
				advance: function()
				{
					//In each case it will earn something
					this.completed = true;
				}
			},

		],
		completedThisRound: [],

		init: function()
		{
			for (var i = 0; i < this.achievements.length; ++i) {
				this.achievements[i].id = i;
			}
		},
		// public
		advanceAchievement: function(achid)
		{
			var ach = this.achievements[achid];
			if (!ach)
				return;
			if (ach.completed)
				return;
			ach.advance();
			if (!ach.completed)
				return;
			this.completedThisRound.push(ach);
		},
		checkForAchievements: function()
		{
			return this.completedThisRound.length > 0;
		},
		resetAchievementVars: function()
		{
			player.SetVar('achievementActive', 0);
			player.SetVar('achievementName', '');
			player.SetVar('achievementDesc', '');
			player.SetVar('achivementId', -1);
		},
		setupAchievementVars: function()
		{
			var ach = this.completedThisRound.shift();
			player.SetVar('achievementActive', 1);
			player.SetVar('achievementName', ach.name);
			player.SetVar('achievementDesc', ach.desc);
			player.SetVar('achivementId', ach.id);
			player.SetVar('achievementUnlocked' + ach.id, 1);
		},
		// public
		doEverythingAtOnce: function()
		{
			this.resetAchievementVars();
			if (this.checkForAchievements())
				this.setupAchievementVars();

		}
	};
	window.achievements.init();
})();

/*
 *
 *  END OF ACHIEVEMENTS 
 *
 */

}

function Script2()
{
  var eyesshut = 100, eyesopen = 10000, inblink = false;
var player = GetPlayer();
var isPopUp = player.GetVar("isPopUp");
function blink(){
  inblink = !inblink;
 if (isPopUp == 1) {
 setTimeout(blink, 100);
}
  else if (inblink) {
    player.SetVar('blinkState', 'hide');
    setTimeout(blink, eyesshut + Math.random() * 100);
  } else {
    player.SetVar('blinkState', 'show');
    setTimeout(blink, eyesopen + Math.random() * 1000);
  }
}

blink(); 

window.summary = {question: [], answer: [], correct: []}; 
}

function Script3()
{
  var player = GetPlayer();
player.SetVar("answerM1", "");
player.SetVar("answerM2", "");
player.SetVar("answerM3", "");
player.SetVar("answerM4", "");
player.SetVar("answerM5", "");
player.SetVar("answerM6", "");
}

function Script4()
{
   window.summary.question.push('Formulate the null-hypothesis - Part1');
  window.summary.answer.push('Il existera une différence');
  window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('7', 'Il existera une différence', false, '', 'Null-hypothesis Part 1 ', 1, 0, 'Scene2_Slide7_1');
}

function Script5()
{
  player = GetPlayer();
answer1 = player.GetVar("answerM4");
answer2 = player.GetVar("answerM3");

 window.summary.question.push('Formulate the null-hypothesis  - Part2');
  window.summary.answer.push(answer1 + answer2);
  window.summary.correct.push('Incorrect');


var answer = answer1+answer2;
lmsAPI.RecordFillInInteraction('8', answer, false, '', 'Null-hypothesis Part 2 ', 1, 0, 'Scene2_Slide7_2');
}

function Script6()
{
  player = GetPlayer();
answer1 = player.GetVar("answerM5");
answer2 = player.GetVar("answerM6");

 window.summary.question.push('Formulate the null-hypothesis  - Part3');
  window.summary.answer.push(answer1 + answer2);
  window.summary.correct.push('Incorrect');

var answer = answer1+answer2;
lmsAPI.RecordFillInInteraction('9', answer, false, '', 'Null-hypothesis Part 3 ', 1, 0, 'Scene2_Slide7_3');
}

function Script7()
{
    window.summary.question.push('Formulate the null-hypothesis - Part1');
  window.summary.answer.push('Il n existera pas une différence ');
  window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('7', 'Il n existera pas une différence ', true, '', 'Null-hypothesis Part 1 ', 1, 0, 'Scene2_Slide7_1');
}

function Script8()
{
    window.summary.question.push('Formulate the null-hypothesis  - Part2');
  window.summary.answer.push('Entre les enfants espagnols et les enfants  britanniques ');
  window.summary.correct.push('Correct');


lmsAPI.RecordFillInInteraction('8', 'Entre les enfants espagnols et les enfants  britanniques ', true, '', 'Null-hypothesis Part 2 ', 1, 0, 'Scene2_Slide7_2');
}

function Script9()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script10()
{
    window.summary.question.push('Formulate the null-hypothesis - Part3');
  window.summary.answer.push('Dans le nombre de repas méditerranéens consommés ');
  window.summary.correct.push('Correct');

var answer = 'Dans le nombre de repas méditerranéens consommés';
lmsAPI.RecordFillInInteraction('9', answer, true, '', 'Null-hypothesis Part 3 ', 1, 0, 'Scene2_Slide7_3');
}

function Script11()
{
  var player = GetPlayer();
var score = player.GetVar('score');
var rank;
window.clearTimeout(timeVar);

//Score
if( score >= 1500 )
 rank = "A";
else if( score >= 1400 )
 rank = "B";
else if( score >= 1300 )
 rank = "C";
else if( score >= 1200 )
 rank = "D";
else 
 rank = "E";

player.SetVar('rank', rank);

//Time
function zeroPad(num, places) {
  var zero = places - num.toString().length + 1;
  return Array(+(zero > 0 && zero)).join("0") + num;
}

var time = player.GetVar('time');

var minutes = Math.floor(time / 60);
var seconds = time - minutes * 60;

minutes  = zeroPad(minutes, 2);
seconds  = zeroPad(seconds, 2);

var NewTime = minutes+":"+seconds;
player.SetVar('timeLast', NewTime );


player.SetVar("answerM1", "");
player.SetVar("answerM2", "");
player.SetVar("answerM3", "");
player.SetVar("answerM4", "");
player.SetVar("answerM5", "");
player.SetVar("answerM6", "");

lmsAPI.RecordFillInInteraction('17', score, true, '', 'Score ', 1, 0, 'Scene2_Slide8');
lmsAPI.RecordFillInInteraction('18', NewTime, true, '', 'Playing Time ', 1, 0, 'Scene2_Slide8');

lmsAPI.SetPassed();
player = GetPlayer();
var correct = player.GetVar("correctcounter");
var question = player.GetVar("questioncounter");

var score = ( correct / question ) * 100;
score =  Math.round( Number(score));
player.SetVar("calculatedscore", score);
player.SetVar("calculatedcorrect",correct);
player.SetVar("calculatedquestion",question);

lmsAPI.SetScore(score,100,0);

lmsAPI.RecordFillInInteraction('19', playerName, true, '', 'Player Name ', 1, 0, 'Scene2_Slide8');

lmsAPI.RecordFillInInteraction('20', rank, true, '', 'Rank ', 1, 0, 'Scene2_Slide8');



}

function Script12()
{
  var answersum = "";

if ( player.GetVar('answerM1') !== "")
   answersum +=  player.GetVar('answerM1') + ", ";
if ( player.GetVar('answerM2') !== "")
   answersum +=  player.GetVar('answerM2') + ", ";
if ( player.GetVar('answerM3') !== "")
   answersum +=  player.GetVar('answerM3') + ", ";
if ( player.GetVar('answerM4') !== "")
   answersum +=  player.GetVar('answerM4') + ", ";

lmsAPI.RecordFillInInteraction('21', answersum, true, '', 'Achievements ', 1, 0, 'Scene2_Slide8');
}

function Script13()
{
  var player = GetPlayer();
var formHTML = "<style>table {border-collapse:collapse;margin-top:20px;color:#373737} table, tr, td {padding: 10px;}tr:nth-child(even) {background:#E3F3EF; }tr:nth-child(odd) {background:#C7F1E6; }tr.header{background:#008A6E;color:white;font-weight:bold; }.logo { margin-bottom:10px;} .name {text-transform:uppercase;font-size:24px;font-weight:bold;color:#008A6E;}.label {font-weight:bold;}.logo span {font-size:27px; font-weight: bold; text-decoration:underline; color:#373737 } .logo img {float:right;}</style>";

var answersum = "";

if ( player.GetVar('answerM1') !== "")
   answersum +=  player.GetVar('answerM1') + ", ";
if ( player.GetVar('answerM2') !== "")
   answersum +=  player.GetVar('answerM2') + ", ";
if ( player.GetVar('answerM3') !== "")
   answersum +=  player.GetVar('answerM3') + ", ";
if ( player.GetVar('answerM4') !== "")
   answersum +=  player.GetVar('answerM4') + ", ";

formHTML += "<div class='logo'><span>Nationality and Mediterranean Foods</span><img src='http://www.playgen.com/chermug/chermug_logo.jpg'></div>";
formHTML += "<span class='name'>" +  player.GetVar('playerName')+ "</span><br/>";
formHTML += "<span class='label'>Score:</span> " + player.GetVar('score') + "<br/>";
formHTML += "<span class='label'>Rank:</span> " + player.GetVar('rank') + "<br/>";
formHTML += "<span class='label'>Time:</span> " + player.GetVar('timeLast') + "<br/>";
formHTML += "<span class='label'>Achievements:</span> " + answersum + "<br/>";

formHTML += "<table><tr class='header'><td>ID</td><td>Question</td><td>Answered</td><td>Correct/Incorrect</td></tr>";

var length = window.summary.question.length;
var question = null;
var answer = null;
var correct = null;

for (var i = 0; i < length; i++) {
question = window.summary.question[i];
answer = window.summary.answer[i];
correct = window.summary.correct[i];
id = i + 1;

formHTML += "<tr><td>" + id + "</td><td>" + question + "</td><td>" + answer + "</td><td>" + correct + "</td></tr>";

}

formHTML += "</table>";

formHTML += "<script>window.print();</script>";

var preview = window.open("about:blank");
preview.document.open();
preview.document.write(formHTML);
preview.document.close();
preview.print();
}

function Script14()
{
  var seconds=0;
timeVar = setTimeout(startTime,1000);

 
function startTime(){
seconds=seconds+1;
var player = GetPlayer();
player.SetVar("time",seconds);
timeVar = setTimeout(startTime,1000);
}
 
}

function Script15()
{
  var player = GetPlayer();
var answer1 = player.GetVar("answerM1");
var answer2 = player.GetVar("answerM2");
var answer3 = player.GetVar("answerM3");
var answer4 = player.GetVar("answerM4");
var answer5 = player.GetVar("answerM5");
var answer6 = player.GetVar("answerM6");
var answer7 = player.GetVar("answerM7");

var answersum = "";

if ( answer1 !== "")
   answersum += answer1 + ", ";
if ( answer2 !== "")
   answersum += answer2 + ", ";
if ( answer3 !== "")
   answersum += answer3 + ", ";
if ( answer4 !== "")
   answersum += answer4 + ", ";
if ( answer5 !== "")
   answersum += answer5 + ", ";
if ( answer6 !== "")
   answersum += answer6;
if ( answer7 !== "")
   answersum += answer7 + ", ";


 window.summary.question.push('Quelles sont les variables de létude?');
  window.summary.answer.push(answersum);
  window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('1', answersum, false, '', 'Quelles sont les variables de létude?', 1, 0, 'Scene2_Slide9_1');
}

function Script16()
{
  window.achievements.advanceAchievement(0);
window.achievements.doEverythingAtOnce();
}

function Script17()
{
  var player = GetPlayer();
var answer1 = player.GetVar("answerM1");
var answer2 = player.GetVar("answerM2");
var answer3 = player.GetVar("answerM3");
var answer4 = player.GetVar("answerM4");
var answer5 = player.GetVar("answerM5");
var answer6 = player.GetVar("answerM6");
var answer7 = player.GetVar("answerM7");

var answersum = "";

if ( answer1 !== "")
   answersum += answer1 + ", ";
if ( answer2 !== "")
   answersum += answer2 + ", ";
if ( answer3 !== "")
   answersum += answer3 + ", ";
if ( answer4 !== "")
   answersum += answer4 + ", ";
if ( answer5 !== "")
   answersum += answer5 + ", ";
if ( answer6 !== "")
   answersum += answer6;
if ( answer7 !== "")
   answersum += answer7 + ", ";


 window.summary.question.push('Quelles sont les variables de létude?');
  window.summary.answer.push(answersum);
  window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('1', answersum, true, '', 'Quelles sont les variables de létude?', 1, 0, 'Scene2_Slide9_1');
}

function Script18()
{
  player = GetPlayer();
answer1 = player.GetVar("answerM1");
answer2 = player.GetVar("answerM2");
answer3 = player.GetVar("answerM3");
answer4 = player.GetVar("answerM4");
answer5 = player.GetVar("answerM5");
answer6 = player.GetVar("answerM6");
answer7 = player.GetVar("answerM7");

var answersum = "";

if ( answer1 !== "")
   answersum += answer1 + ", ";
if ( answer2 !== "")
   answersum += answer2 + ", ";
if ( answer3 !== "")
   answersum += answer3 + ", ";
if ( answer4 !== "")
   answersum += answer4 + ", ";
if ( answer5 !== "")
   answersum += answer5 + ", ";
if ( answer6 !== "")
   answersum += answer6;
if ( answer7 !== "")
   answersum += answer7 + ", ";


 window.summary.question.push('Quelle est la variable indépendante dans le cadre de la même étude? ');
  window.summary.answer.push(answersum);
  window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('2', answersum, true, '', 'Quelle est la variable indépendante dans le cadre de la même étude? ', 1, 0, 'Scene2_Slide9_2');
}

function Script19()
{
  player = GetPlayer();
answer1 = player.GetVar("answerM1");
answer2 = player.GetVar("answerM2");
answer3 = player.GetVar("answerM3");
answer4 = player.GetVar("answerM4");
answer5 = player.GetVar("answerM5");
answer6 = player.GetVar("answerM6");
answer7 = player.GetVar("answerM7");

var answersum = "";

if ( answer1 !== "")
   answersum += answer1 + ", ";
if ( answer2 !== "")
   answersum += answer2 + ", ";
if ( answer3 !== "")
   answersum += answer3 + ", ";
if ( answer4 !== "")
   answersum += answer4 + ", ";
if ( answer5 !== "")
   answersum += answer5 + ", ";
if ( answer6 !== "")
   answersum += answer6;
if ( answer7 !== "")
   answersum += answer7 + ", ";


 window.summary.question.push('Quelle est la variable indépendante dans le cadre de la même étude?');
  window.summary.answer.push(answersum);
  window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('2', answersum, false, '', 'Quelle est la variable indépendante dans le cadre de la même étude? ', 1, 0, 'Scene2_Slide9_2');
}

function Script20()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script21()
{
  player = GetPlayer();
answer1 = player.GetVar("answerM1");
answer2 = player.GetVar("answerM2");
answer3 = player.GetVar("answerM3");
answer4 = player.GetVar("answerM4");
answer5 = player.GetVar("answerM5");
answer6 = player.GetVar("answerM6");
answer7 = player.GetVar("answerM7");

var answersum = "";

if ( answer1 !== "")
   answersum += answer1 + ", ";
if ( answer2 !== "")
   answersum += answer2 + ", ";
if ( answer3 !== "")
   answersum += answer3 + ", ";
if ( answer4 !== "")
   answersum += answer4 + ", ";
if ( answer5 !== "")
   answersum += answer5 + ", ";
if ( answer6 !== "")
   answersum += answer6;
if ( answer7 !== "")
   answersum += answer7 + ", ";


 window.summary.question.push('Quelle est la variable indépendant dans la même étude?');
  window.summary.answer.push(answersum);
  window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('3', answersum, true, '', 'Quelle est la variable indépendant dans la même étude?  ', 1, 0, 'Scene2_Slide9_3');
}

function Script22()
{
  player = GetPlayer();
answer1 = player.GetVar("answerM1");
answer2 = player.GetVar("answerM2");
answer3 = player.GetVar("answerM3");
answer4 = player.GetVar("answerM4");
answer5 = player.GetVar("answerM5");
answer6 = player.GetVar("answerM6");
answer7 = player.GetVar("answerM7");

var answersum = "";

if ( answer1 !== "")
   answersum += answer1 + ", ";
if ( answer2 !== "")
   answersum += answer2 + ", ";
if ( answer3 !== "")
   answersum += answer3 + ", ";
if ( answer4 !== "")
   answersum += answer4 + ", ";
if ( answer5 !== "")
   answersum += answer5 + ", ";
if ( answer6 !== "")
   answersum += answer6;
if ( answer7 !== "")
   answersum += answer7 + ", ";


 window.summary.question.push('Quelle est la variable indépendant dans la même étude?');
  window.summary.answer.push(answersum);
  window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('3', answersum, false, '', 'Quelle est la variable indépendant dans la même étude?', 1, 0, 'Scene2_Slide9_3');
}

function Script23()
{
  
/*
 *
 * HANGMAN GAME
 *
 */

/*global GetPlayer:false */
var player = GetPlayer();
(function() {
	'use strict';
	window.hangman = {
		//Use capital letters
		questions: ["RATION"],
		activeQuestion: -1,
		question: '',
		chars: [],
		foundChars: {},
		foundLetters: 0,
		alphabet: ["A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z", "Ex"],
		init: function()
		{
			//console.log("init");

		},
		/*
		 * Functions to be called from Storyline
		 */
		// Setup question and the word into letters
		setupQuestions: function(questionnumber)
		{
			this.foundLetters = 0;
			this.activeQuestion = questionnumber;
			this.question = this.questions[this.activeQuestion-1];
			this.chars = this.question.split('');
			this.foundChars = {};
			for (var i = this.alphabet.length - 1; i >= 0; i--)
				player.SetVar("hmChange"+ this.alphabet[i], 0);


		},
		// Check if any letter or the answer is found
		letterPressed: function(letter)
		{
			if (this.foundChars[letter])
				return;
			player.SetVar("hmChangeSet", 0);
			var found = 0;
			for (var i = this.chars.length - 1; i >= 0; i--) {
				var pos = i+1;
				if(this.chars[i] == letter) {
					player.SetVar("hml"  + pos, letter);
					found = 1;
					this.foundLetters++;
					this.foundChars[letter] = true;
					if (this.foundLetters >= this.chars.length) {
						player.SetVar("hmAnswerFound", 1);
					}	
				}
			}
			if( found != 1) {
				//cant put ! in the stroyline var
				if (letter == "!")
					letter = "Ex";

				var isPressed = player.GetVar("hmChange"+letter);
				if( isPressed == 0) {
				var tleft = player.GetVar("hmtleft");
				tleft = tleft -1;
				player.SetVar("hmtleft", tleft);
				player.SetVar("hmChange"+ letter, 1);
				}
			}
		 

			return;
		}
	};
	window.hangman.init();
})();

/*
 *
 * END OF HANGMAN GAME
 *
 */


}

function Script24()
{
  var seconds=3000;
// display();
var blinkTimer = setTimeout(display,400);
var flag = 0;
 
function display(){
	seconds=seconds-1;
	var player = GetPlayer();
	var tleft = player.GetVar("hmtleft");
	player.SetVar("hmtimer",seconds);
	if( tleft != 9) {
		if(flag == 0) {
			player.SetVar("hmBlink","hide");
			flag = 1;
		}
		else {
		player.SetVar("hmBlink","show");
		flag = 0;
		}
		var blinkTimer = setTimeout(display,400);
	}
	else 
	player.SetVar("hmBlink","show");
}
 
}

function Script25()
{
  window.hangman.setupQuestions(1);
}

function Script26()
{
  window.hangman.letterPressed("B");
}

function Script27()
{
  window.hangman.letterPressed("C");
}

function Script28()
{
  window.hangman.letterPressed("D");
}

function Script29()
{
  window.hangman.letterPressed("E");
}

function Script30()
{
  window.hangman.letterPressed("F");
}

function Script31()
{
  window.hangman.letterPressed("G");
}

function Script32()
{
  window.hangman.letterPressed("H");
}

function Script33()
{
  window.hangman.letterPressed("I");
}

function Script34()
{
  window.hangman.letterPressed("J");
}

function Script35()
{
  window.hangman.letterPressed("K");
}

function Script36()
{
  window.hangman.letterPressed("L");
}

function Script37()
{
  window.hangman.letterPressed("M");
}

function Script38()
{
  window.hangman.letterPressed("N");
}

function Script39()
{
  window.hangman.letterPressed("O");
}

function Script40()
{
  window.hangman.letterPressed("P");
}

function Script41()
{
  window.hangman.letterPressed("Q");
}

function Script42()
{
  window.hangman.letterPressed("R");
}

function Script43()
{
  window.hangman.letterPressed("S");
}

function Script44()
{
  window.hangman.letterPressed("T");
}

function Script45()
{
  window.hangman.letterPressed("U");
}

function Script46()
{
  window.hangman.letterPressed("V");
}

function Script47()
{
  window.hangman.letterPressed("W");
}

function Script48()
{
  window.hangman.letterPressed("X");
}

function Script49()
{
  window.hangman.letterPressed("Y");
}

function Script50()
{
  window.hangman.letterPressed("Z");
}

function Script51()
{
  window.hangman.letterPressed("!");
}

function Script52()
{
  window.hangman.letterPressed("A");
}

function Script53()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script54()
{
    window.summary.question.push('Dans cette étude en base de quel niveau de mesure est quantifié la consommation de repas méditerranéens?');
  window.summary.answer.push('Ration');
  window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('4', 'Ration', true, '', 'Dans cette étude en base de quel niveau de mesure est quantifié la consommation de repas méditerranéens ? ', 1, 0, 'Scene2_Slide10');
}

function Script55()
{
    window.summary.question.push('Dans cette étude en base de quel niveau de mesure est quantifié la consommation de repas méditerranéens?');
  window.summary.answer.push('');
  window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('4', '', false, '', 'Dans cette étude en base de quel niveau de mesure est quantifié la consommation de repas méditerranéens?', 1, 0, 'Scene2_Slide10');
}

function Script56()
{
  var seconds=4;
//setTimeout(display,1000);
display();
 
function display(){
seconds=seconds-1;
var player = GetPlayer();
player.SetVar("hmcready",seconds);
var cready = player.GetVar("hmcready");
if ( cready == 0) {
player.SetVar("hmcready", "Go!");
setTimeout(display,1000);
}
else if ( cready == -1) {
player.SetVar("hmcready", "next");
}
else {
setTimeout(display,1000);
}
}
}

function Script57()
{
  window.hangman.setupQuestions(1);
var seconds=4;
//setTimeout(display,1000);
display();
 
function display(){
seconds=seconds-1;
var player = GetPlayer();
player.SetVar("hmcready",seconds);
var cready = player.GetVar("hmcready");
if ( cready == 0) {
player.SetVar("hmcready", "Go!");
setTimeout(display,1000);
}
else if ( cready == -1) {
player.SetVar("hmcready", "next");
setTimeout(display,1000);
}
else {
setTimeout(display,1000);
}
}
}

function Script58()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script59()
{
  var player = GetPlayer();  
var answer = player.GetVar('answer');
window.summary.question.push('Quel niveau de mesure est approprié pour la nationalité dans cette étude?');
window.summary.answer.push(answer);
window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('5', answer, true, '', 'Quel niveau de mesure est approprié pour la nationalité dans cette étude? ', 1, 0, 'Scene2_Slide11_1');
}

function Script60()
{
  var player = GetPlayer();  
var answer = player.GetVar('answer');
window.summary.question.push('Quel niveau de mesure est approprié pour la nationalité dans cette étude? ');
window.summary.answer.push(answer);
window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('5', answer, false, '', 'Quel niveau de mesure est approprié pour la nationalité dans cette étude? ', 1, 0, 'Scene2_Slide11_1');
}

function Script61()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script62()
{
    window.summary.question.push('Quel type de plan suggère cette étude?');
  window.summary.answer.push('Des différences entre les groupes');
  window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('6', 'Des différences entre les groupes ', true, '', 'Quel type de plan suggère cette étude? ', 1, 0, 'Scene2_Slide11_2');
}

function Script63()
{
    window.summary.question.push('Quel type de plan suggère cette étude?');
  window.summary.answer.push('Une association entre variables');
  window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('6', 'Une association entre variables ', false, '', 'Quel type de plan suggère cette étude?  ', 1, 0, 'Scene2_Slide11_2');
}

function Script64()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script65()
{
    window.summary.question.push('Quel set de donnés ci-dessus est correct pour tester tes données?');
  window.summary.answer.push('Dataset1');
  window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('10', 'Dataset1', true, '', 'Quel set de donnés ci-dessus est correct pour tester tes données? ', 1, 0, 'Scene2_Slide12');
}

function Script66()
{
    window.summary.question.push('Quel set de donnés ci-dessus est correct pour tester tes données?');
  window.summary.answer.push('Dataset2');
  window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('10', 'Dataset2', true, '', 'Quel set de donnés ci-dessus est correct pour tester tes données? ', 1, 0, 'Scene2_Slide12');
}

function Script67()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script68()
{
  player = GetPlayer();  
var answer = player.GetVar('answer');

window.summary.question.push('Quel type de représentation graphique des données souhaites-tu de voir?');
window.summary.answer.push(answer);
window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('11', answer, true, '', 'Quel type de représentation graphique des données souhaites-tu de voir?  ', 1, 0, 'Scene2_Slide13');
}

function Script69()
{
  player = GetPlayer();  
var answer = player.GetVar('answer');

window.summary.question.push('Quel type de représentation graphique des données souhaites-tu de voir? ');
window.summary.answer.push(answer);
window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('11', answer, false, '', 'Quel type de représentation graphique des données souhaites-tu de voir?  ', 1, 0, 'Scene2_Slide13');
}

function Script70()
{
  player = GetPlayer();  
var answer = player.GetVar('answer');

window.summary.question.push('Quel type de représentation graphique des données souhaites-tu de voir?');
window.summary.answer.push(answer);
window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('11', answer, false, '', 'Quel type de représentation graphique des données souhaites-tu de voir?  ', 1, 0, 'Scene2_Slide13');
}

function Script71()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script72()
{
  player = GetPlayer();  
var answer = player.GetVar('answer');

window.summary.question.push('Quel type de représentation graphique des données souhaites-tu de voir? ');
window.summary.answer.push(answer);
window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('11', answer, true, '', 'Quel type de représentation graphique des données souhaites-tu de voir?  ', 1, 0, 'Scene2_Slide13');
}

function Script73()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script74()
{
  window.summary.question.push("Pour tester l hypothèse selon laquelle");
window.summary.answer.push('Le test t pour des échantillons indépendants');
window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('13', 'Le test t pour des échantillons indépendants', true, '', 'Pour tester l hypothèse selon laquelle ', 1, 0, 'Scene2_Slide14_1');
}

function Script75()
{
  window.summary.question.push("Pour tester l hypothèse selon laquelle");
window.summary.answer.push('Chi carré');
window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('13', 'Chi carré', false, '', 'Pour tester l hypothèse selon laquelle ', 1, 0, 'Scene2_Slide14_1');
}

function Script76()
{
  window.summary.question.push('Pour tester l hypothèse selon laquelle');
window.summary.answer.push('Pearsons r');
window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('13', 'Pearsons r', false, '', 'Pour tester l hypothèse selon laquelle ', 1, 0, 'Scene2_Slide14_1');
}

function Script77()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script78()
{
  window.summary.question.push("Interprétation du tableau ");
window.summary.answer.push('Le tableau montre qu en moyenne les enfants britanniques consommes 18,83 repas méditerranées par semaine.');
window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('14', 'Le tableau montre qu en moyenne les enfants britanniques consommes 18,83 repas méditerranées par semaine.', true, '', 'Interprétation du tableau ', 1, 0, 'Scene2_Slide14_2');
}

function Script79()
{
  window.summary.question.push('Interprétation du tableau ');
window.summary.answer.push('Le tableau montre qu en moyenne les enfants britanniques consommes 2,781 repas méditerranées par semaine.');
window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('14', 'Le tableau montre qu en moyenne les enfants britanniques consommes 2,781 repas méditerranées par semaine.', false, '', 'Interprétation du tableau ', 1, 0, 'Scene2_Slide14_2');
}

function Script80()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script81()
{
  window.summary.question.push('Interpretation of table ');
window.summary.answer.push('Le tableau montre que le nombre de produits alimentaires méditerranéens consommés par les enfants espagnols est plus grand que le nombre de mêmes produits consommés par les enfants britanniques.');
window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('15', 'Le tableau montre que le nombre de produits alimentaires méditerranéens consommés par les enfants espagnols est plus grand que le nombre de mêmes produits consommés par les enfants britanniques.', true, '', 'Interpretation of table ', 1, 0, 'Scene2_Slide14_3');
}

function Script82()
{
  window.summary.question.push('Interpretation of table ');
window.summary.answer.push('Le tableau montre que le nombre de produits alimentaires méditerranéens consommés par les enfants britanniques est plus grand que le nombre de mêmes produits consommés par les enfants espagnols.');
window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('15', 'Le tableau montre que le nombre de produits alimentaires méditerranéens consommés par les enfants britanniques est plus grand que le nombre de mêmes produits consommés par les enfants espagnols.', false, '', 'Interpretation of table ', 1, 0, 'Scene2_Slide14_3');
}

function Script83()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}

var time = player.GetVar('time');
//Bronze Gold Silver
if( time <= 15000 && time > 12000 ) {
player.SetVar("achQuestionBronze",1);
}
if( time>= 10000 &&  time <= 12000) {
player.SetVar("achQuestionBronze",0);
player.SetVar("achQuestionSilver",1);
}
if( time < 10000 ) {
player.SetVar("achQuestionSilver",0);
player.SetVar("achQuestionGold",1);
}

}

function Script84()
{
  window.achievements.advanceAchievement(3);
window.achievements.doEverythingAtOnce();

window.achievements.advanceAchievement(4);
window.achievements.doEverythingAtOnce();




}

function Script85()
{
  window.summary.question.push('Interpretation of table ');
window.summary.answer.push('La valeur significative 0,005 montre qu il a existé une différence significative ');
window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('16', 'La valeur significative 0,005 montre qu il a existé une différence significative ', true, '', 'Interpretation of table ', 1, 0, 'Scene2_Slide14_4');
}

function Script86()
{
  var player = GetPlayer();
var time = player.GetVar('time');
//Bronze Gold Silver
if( time <= 15000 && time > 12000 ) {
player.SetVar("achQuestionBronze",1);
}
if( time>= 10000 &&  time <= 12000) {
player.SetVar("achQuestionBronze",0);
player.SetVar("achQuestionSilver",1);
}
if( time < 10000 ) {
player.SetVar("achQuestionSilver",0);
player.SetVar("achQuestionGold",1);
}

window.achievements.advanceAchievement(4);
window.achievements.doEverythingAtOnce();
}

function Script87()
{
  window.summary.question.push('Interpretation of table ');
window.summary.answer.push('La valeur significative 0,005 montre qu il n a pas existé une différence significative');
window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('16', 'La valeur significative 0,005 montre qu il n a pas existé une différence significative', false, '', 'Interpretation of table ', 1, 0, 'Scene2_Slide14_4');
}

function Script88()
{
  
/*
 *
 * TIC-TAC-TOE GAME
 *
 */

/*global GetPlayer:false */
var player = GetPlayer();
(function() {
	'use strict';
	var state = {
		READY: 0,
		RIGHT: 1,
		WRONG: 2
	};
	var validValues = [
		// Rows
		1  | 2   | 4,
		8  | 16  | 32,
		64 | 128 | 256,
		// Columns
		1  | 8   | 64,
		2  | 16  | 128,
		4  | 32  | 256
	];
	window.ttt = {
		questions: [
			{
				text: "Le graphique suggère que le nombre moyen de produits alimentaires méditerranéens  consommés par les enfants espagnols est plus grand que le nombre moyens de produits consommés par les enfants britanniques",
				wrong: "Faux, le graphique ne montre pas le nombre moyen de produits alimentaires méditerranéens  consommés, mais le nombre médian de produits alimentaires méditerranéens consommés.",
				answer: false
			},
			{
				text: "Le graphique suggère que le nombre moyen de produits alimentaires méditerranéens  consommés par les enfants espagnols est légèrement plus grand que le nombre moyen de produits consommés par les enfants britanniques.",
				wrong: "Vrai, le graphique suggère que le nombre médian de produits alimentaires  méditerranéens consommés par les enfants espagnols est plus grand que le nombre médian des produits consommés par les enfants britanniques.",
				answer: true
			},
			{
				text: "Le graphique montre une plus grande variabilité en ce qui concerne le nombre de produits alimentaires méditerranéens  consommés par les enfants espagnols que ceux consommés par les enfants britanniques.",
				wrong: "Faux, le graphique montre une plus grande variabilité en ce qui concerne le nombre de produits alimentaires méditerranéens  consommés par les enfants  britanniques que ceux consommés par les enfants espagnols.",
				answer: false
			},
			{
				text: "Le tableau de résultat montre qu'en moyenne les enfants britanniques consomment 2,781 produits alimentaires méditerranéens  par semaine.",
				wrong: "Faux, le tableau de résultats montre qu'en moyenne les enfants britanniques consomment 18,83 aliments méditerranéens  par semaine. 2,781 est la déviation standard.",
				answer: false
			},
			{
				text: "Le tableau de résultats  montre qu'en moyenne les enfants espagnols consomment 20,20 aliments méditerranéens  par semaine.",
				wrong: "Vrai, le tableau de résultats montre qu'en moyenne les enfants espagnols consomment 20,20 aliments méditerranéens  par semaine.",
				answer: true
			},
			{
				text: "Le tableau de résultats enregistre une consommation de produits alimentaires méditerranéens  par semaine plus grande pour les enfants espagnols par rapport aux enfants britanniques.",
				wrong: "Vrai, le tableau de résultats enregistre une consommation de produits alimentaires méditerranéens  par semaine plus grande pour les enfants espagnols (20,20), par rapport aux enfants britanniques (18,83).",
				answer: true
			},
			{
				text: "Le seuil de signification de 0,005 montre qu'il a existé une différence statistique significative de la consommation d'aliments méditerranéens par les enfants britanniques et par les enfants espagnols.",
				wrong: "Vrai, le seuil de signification 0,005 montre qu'il a existé une différence statistique significative de la consommation d'aliments méditerranéens par les enfants britanniques et par les enfants espagnols.",
				answer: true
			},
			{
				text: "Au total, selon le tableau de résultats, la consommation par semaine d'aliments méditerranéens des enfants espagnols n'est pas significativement plus grande que celle des enfants britanniques.",
				wrong: "Faux, selon le tableau de résultats, on peut conclure qu'au total les enfants espagnols consomment un nombre d'aliments méditerranéens plus grand que les enfants britanniques.",
				answer: false
			},
			{
				text: "Le seuil de signification montre qu'on peut rejeter l'hypothèse nulle.",
				wrong: "Vrai, le seuil de signification (0,005) montre qu'on peut rejeter l'hypothèse nulle tant qu'il y a des différences significatives entre la consommation d'aliments méditerranéens des enfants britanniques et des enfants espagnols.",
				answer: true
			}
		],
		activeQuestion: -1,
		totalValue: 0,
		init: function()
		{
			if (this.questions.length !== 9) {
				alert("Question count missmatch! Got " + this.questions.length + " expected 9");
				return;
			}
			var value = 1;
			// Setup the Qs with redundant info

var length = this.questions.length,
element = null;
for (var i = 0; i < length; i++) {
element = this.questions[i];
element .id = i;
element .value = value;
element .state = state.READY;
value *= 2;
}
		},
		updateQState: function(question, state)
		{
			question.state = state;
			player.SetVar('tttQuestionState' + question.id, state);
		},
		/*
		 * Functions to be called from Storyline
		 */
		// Resets all the question vars to ready
		setupQuestions: function()
		{
			this.activeQuestion = null;
			this.totalValue = 0;
			player.SetVar('tttQuestionText', '');
			player.SetVar('tttSlideSolved', 0);
var length = this.questions.length,
element = null;
for (var i = 0; i < length; i++) {
element = this.questions[i];
this.updateQState(element , state.READY);
}

		},
		// For when the user picks a question
		chooseQuestion: function(quid)
		{
			var question = this.questions[quid];
			if (question.state !== state.READY)
				return;
			this.activeQuestion = question;
			player.SetVar('tttQuestionText', question.text);
		},
		// Check if the answer is correctus
		checkAnswer: function(choice)
		{
			// Get what we're talkin about
			var question = this.activeQuestion;
			// Hide the question window
var questionText = player.GetVar('tttQuestionText');
			player.SetVar('tttQuestionText', '');
			// Reset the wrong var so we can trigger it if necessary
			player.SetVar('tttQuestionWrong', '');
			// Determine failure
			var choice_ = (choice == 'true') ? true : false;
			// If you pass you're wrong and stupid
			if (choice === 'pass' || choice_ !== question.answer) {
				this.updateQState(question, state.WRONG);
				// Pop up the "no u stupid" box
				player.SetVar('tttQuestionWrong', question.wrong);

window.summary.question.push(questionText);
window.summary.answer.push(choice_);
window.summary.correct.push('Incorrect');

				return;
			}
			// success!
window.summary.question.push(questionText);
window.summary.answer.push(question.answer);
window.summary.correct.push('Correct');
			this.updateQState(question, state.RIGHT);
			this.totalValue |= question.value;
			// Check if we've won
var length = validValues.length,
value = null;
for (var i = 0; i < length; i++) {
value = validValues[i];
if  ( (this.totalValue & value) === value )
player.SetVar('tttSlideSolved', 1);
}
		}
	};
	window.ttt.init();
})();

/*
 *
 * END OF TIC-TAC-TOE GAME
 *
 */


}

function Script89()
{
  window.ttt.setupQuestions();
}

function Script90()
{
  window.ttt.setupQuestions();
}

function Script91()
{
  window.ttt.chooseQuestion(0);
}

function Script92()
{
  window.ttt.chooseQuestion(1);
}

function Script93()
{
  window.ttt.chooseQuestion(2);
}

function Script94()
{
  window.ttt.chooseQuestion(3);
}

function Script95()
{
  window.ttt.chooseQuestion(4);
}

function Script96()
{
  window.ttt.chooseQuestion(5);
}

function Script97()
{
  window.ttt.chooseQuestion(6);
}

function Script98()
{
  window.ttt.chooseQuestion(7);
}

function Script99()
{
  window.ttt.chooseQuestion(8);
}

function Script100()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


lmsAPI.RecordFillInInteraction('12', 'Completed', true, '', 'Microscope Game ', 1, 0, 'Scene2_Slide15');



}

function Script101()
{
  lmsAPI.RecordFillInInteraction('12', '', false, '', 'Microscope Game ', 1, 0, 'Scene2_Slide15');
}

function Script102()
{
  var eyesshut = 100, eyesopen = 10000, inblink = false;
var player = GetPlayer();
function blink(){
  inblink = !inblink;
  if (inblink) {
    player.SetVar('blinkState', 'hide');
    setTimeout(blink, eyesshut + Math.random() * 40);
  } else {
    player.SetVar('blinkState', 'show');
    setTimeout(blink, eyesopen + Math.random() * 500);
  }
}

blink(); 
}

function Script103()
{
  window.ttt.checkAnswer('true');
}

function Script104()
{
  window.ttt.checkAnswer('false');
}

