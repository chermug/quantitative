function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6JMjaBhmbom":
        Script1();
        break;
      case "6S7y9vYXwgL":
        Script2();
        break;
      case "6Gbjxh20d9B":
        Script3();
        break;
      case "6GBnFhV34oe":
        Script4();
        break;
      case "5swo2NwN92C":
        Script5();
        break;
      case "6oIzekozhtn":
        Script6();
        break;
      case "6IAlntdHqLm":
        Script7();
        break;
      case "66AycwFIgm2":
        Script8();
        break;
      case "64Ecc2PrFBT":
        Script9();
        break;
      case "6FMaaLg1ANo":
        Script10();
        break;
      case "6S0bLxqBXGf":
        Script11();
        break;
      case "5yYHoESo9B7":
        Script12();
        break;
      case "6XvQbJNBIlV":
        Script13();
        break;
      case "5kf3IkC8PPT":
        Script14();
        break;
      case "5otwjwp1Qnc":
        Script15();
        break;
      case "5ZmD3e3JISq":
        Script16();
        break;
      case "6evmeWwcucg":
        Script17();
        break;
      case "5wVfr6KYa4P":
        Script18();
        break;
      case "6NIIjNW0sDW":
        Script19();
        break;
      case "5yylsMnX9AP":
        Script20();
        break;
      case "5hB1FbP7rpT":
        Script21();
        break;
      case "5pBciqK0jQK":
        Script22();
        break;
      case "5mOroNU1W0x":
        Script23();
        break;
      case "606a9bG2WHh":
        Script24();
        break;
      case "6NoI90xeO6p":
        Script25();
        break;
      case "5buMB8vu2Zk":
        Script26();
        break;
      case "5bmQyTUWQO7":
        Script27();
        break;
      case "5kJUA5jtuTa":
        Script28();
        break;
      case "6CUZvGPbWkN":
        Script29();
        break;
      case "6fcHFqzEJyC":
        Script30();
        break;
      case "6P806uVjMTc":
        Script31();
        break;
      case "6b9XFWjpwrh":
        Script32();
        break;
      case "5t05oSYewXQ":
        Script33();
        break;
      case "6G7V7oaNuNR":
        Script34();
        break;
      case "6QTrCUZ4ChG":
        Script35();
        break;
      case "6ScUPiKA7y6":
        Script36();
        break;
      case "6BCWU575ZoW":
        Script37();
        break;
      case "5ehNWLvlHDl":
        Script38();
        break;
      case "6og0TSSQTrv":
        Script39();
        break;
      case "6d6TJeY7KoQ":
        Script40();
        break;
      case "63RplRcSRJ1":
        Script41();
        break;
      case "6jmiAYZQhxd":
        Script42();
        break;
      case "5jcBzyjlzK8":
        Script43();
        break;
      case "5bwKDcWa141":
        Script44();
        break;
      case "5VssJHLn1W1":
        Script45();
        break;
      case "6QEXJmctcaP":
        Script46();
        break;
      case "6B95hR8uaIx":
        Script47();
        break;
      case "5nnVorslYFw":
        Script48();
        break;
      case "65JthvUirYq":
        Script49();
        break;
      case "5v94iVxM9eJ":
        Script50();
        break;
      case "5Ufj36OznlC":
        Script51();
        break;
      case "6Ohsz4GtB6b":
        Script52();
        break;
      case "65KVSr1lRJt":
        Script53();
        break;
      case "6f7U8Ya1zUg":
        Script54();
        break;
      case "5lqSm7TBevt":
        Script55();
        break;
      case "664kJ1AS9ij":
        Script56();
        break;
      case "5rKOnurLpVT":
        Script57();
        break;
      case "6rnAPA6Yslj":
        Script58();
        break;
      case "5Vyf7qSqtNN":
        Script59();
        break;
      case "6PxIN5Bl7iH":
        Script60();
        break;
      case "5m5y0oDmTfm":
        Script61();
        break;
      case "5gOYvSSn8B0":
        Script62();
        break;
      case "6LeUMXCjt2e":
        Script63();
        break;
      case "5bZSDbk1BlJ":
        Script64();
        break;
      case "6BH6AUySyZ4":
        Script65();
        break;
      case "6Gp18xE1M8e":
        Script66();
        break;
      case "5t62DhlxDw5":
        Script67();
        break;
      case "5usOMAZhMKZ":
        Script68();
        break;
      case "6Gcz0dc7KgU":
        Script69();
        break;
      case "5mELnBQjmPF":
        Script70();
        break;
      case "6le6e3FEZLT":
        Script71();
        break;
      case "6cTXD1l8SBn":
        Script72();
        break;
      case "5mZRol3z8or":
        Script73();
        break;
      case "5k3UFUW06yn":
        Script74();
        break;
      case "5x6BYFhQlrL":
        Script75();
        break;
      case "5nFldPoLoOm":
        Script76();
        break;
      case "5VcSbh9IVDw":
        Script77();
        break;
      case "6Xeo8XO0kkc":
        Script78();
        break;
      case "5qUPQ3kTlIu":
        Script79();
        break;
      case "6qR4EWy75kH":
        Script80();
        break;
      case "6CxvLdh9i55":
        Script81();
        break;
      case "6Mr1S5FPCVt":
        Script82();
        break;
      case "6iPPKpTwKwS":
        Script83();
        break;
      case "5iqzMkT2rBX":
        Script84();
        break;
      case "65H67EtvCW3":
        Script85();
        break;
      case "5zrRJFWLucR":
        Script86();
        break;
      case "5YAigyqwlhr":
        Script87();
        break;
      case "5jfSTnsrnII":
        Script88();
        break;
      case "6qXTqRwpDsp":
        Script89();
        break;
      case "6GUE4KZ4mVm":
        Script90();
        break;
      case "6P3pWoWanmu":
        Script91();
        break;
      case "6h8l9ggfPnw":
        Script92();
        break;
      case "6Zr0wfkvBlh":
        Script93();
        break;
      case "6dzidcILut6":
        Script94();
        break;
      case "6oVESo7z3jf":
        Script95();
        break;
      case "62pqZEsJXcd":
        Script96();
        break;
  }
}

function Script1()
{
  
/*
 *
 *   ACHIEVEMENTS
 *
 */

/*global GetPlayer:false */
var player = GetPlayer();
(function() {
	'use strict';
	window.achievements = {
		achievements: [
			{
				name: "De eerste vraag",
				desc: "U hebt de eerst vraag goed beantwoord.",
				advance: function()
				{
					this.completed = true;
				}
			},
			{
				name: "Drie in een rij",
				desc: "U hebt drie vragen op rij goed beantwoord.",
				rowCounter: 0,
				advance: function()
				{
					var rowCounter = player.GetVar('ach3Question');
					console.log("in a row: "+rowCounter);
					if (rowCounter  == 3)
						this.completed = true;
				}
			},
			{
				name: "Hypothese",
				desc: "U hebt alle hypothese vragen goed beantwoord.",
				rowCounter: 0,
				advance: function()
				{
					var isHypothesis = player.GetVar('achHypothesis');
					console.log(isHypothesis);
					if (isHypothesis  == 1)
						this.completed = true;
				}
			},
			{
				name: "Alle",
				desc: "U hebt alle vragen goed beantwoord.",
				rowCounter: 0,
				advance: function()
				{
					var isAll = player.GetVar('achAll');
					console.log(isAll);
					if (isAll  == 1)
						this.completed = true;
				}
			},
			{
				name: "",
				desc: "",
				rowCounter: 0,
				advance: function()
				{
					//In each case it will earn something
					this.completed = true;
				}
			},

		],
		completedThisRound: [],

		init: function()
		{
			for (var i = 0; i < this.achievements.length; ++i) {
				this.achievements[i].id = i;
			}
		},
		// public
		advanceAchievement: function(achid)
		{
			var ach = this.achievements[achid];
			if (!ach)
				return;
			if (ach.completed)
				return;
			ach.advance();
			if (!ach.completed)
				return;
			this.completedThisRound.push(ach);
		},
		checkForAchievements: function()
		{
			return this.completedThisRound.length > 0;
		},
		resetAchievementVars: function()
		{
			player.SetVar('achievementActive', 0);
			player.SetVar('achievementName', '');
			player.SetVar('achievementDesc', '');
			player.SetVar('achivementId', -1);
		},
		setupAchievementVars: function()
		{
			var ach = this.completedThisRound.shift();
			player.SetVar('achievementActive', 1);
			player.SetVar('achievementName', ach.name);
			player.SetVar('achievementDesc', ach.desc);
			player.SetVar('achivementId', ach.id);
			player.SetVar('achievementUnlocked' + ach.id, 1);
		},
		// public
		doEverythingAtOnce: function()
		{
			this.resetAchievementVars();
			if (this.checkForAchievements())
				this.setupAchievementVars();

		}
	};
	window.achievements.init();
})();

/*
 *
 *  END OF ACHIEVEMENTS 
 *
 */

}

function Script2()
{
  var eyesshut = 100, eyesopen = 10000, inblink = false;
var player = GetPlayer();
var isPopUp = player.GetVar("isPopUp");
function blink(){
  inblink = !inblink;
 if (isPopUp == 1) {
 setTimeout(blink, 100);
}
  else if (inblink) {
    player.SetVar('blinkState', 'hide');
    setTimeout(blink, eyesshut + Math.random() * 100);
  } else {
    player.SetVar('blinkState', 'show');
    setTimeout(blink, eyesopen + Math.random() * 1000);
  }
}

blink(); 

window.summary = {question: [], answer: [], correct: []}; 
}

function Script3()
{
  var player = GetPlayer();
var score = player.GetVar('score');
var rank;
window.clearTimeout(timeVar);

//Score
if( score >= 1500 )
 rank = "A";
else if( score >= 1400 )
 rank = "B";
else if( score >= 1300 )
 rank = "C";
else if( score >= 1200 )
 rank = "D";
else 
 rank = "E";

player.SetVar('rank', rank);

//Time
function zeroPad(num, places) {
  var zero = places - num.toString().length + 1;
  return Array(+(zero > 0 && zero)).join("0") + num;
}

var time = player.GetVar('time');

var minutes = Math.floor(time / 60);
var seconds = time - minutes * 60;

minutes  = zeroPad(minutes, 2);
seconds  = zeroPad(seconds, 2);

var NewTime = minutes+":"+seconds;
player.SetVar('timeLast', NewTime );

player.SetVar("answerM1", "");
player.SetVar("answerM2", "");
player.SetVar("answerM3", "");
player.SetVar("answerM4", "");
player.SetVar("answerM5", "");
player.SetVar("answerM6", "");

lmsAPI.RecordFillInInteraction('14', score, true, '', 'Score ', 1, 0, 'Scene2_Slide8');
lmsAPI.RecordFillInInteraction('15', NewTime, true, '', 'Playing Time ', 1, 0, 'Scene2_Slide8');

lmsAPI.SetPassed();
player = GetPlayer();
var correct = player.GetVar("correctcounter");
var question = player.GetVar("questioncounter");

var score = ( correct / question ) * 100;
score =  Math.round( Number(score));
player.SetVar("calculatedscore", score);
player.SetVar("calculatedcorrect",correct);
player.SetVar("calculatedquestion",question);

lmsAPI.SetScore(score,100,0);

lmsAPI.RecordFillInInteraction('16', playerName, true, '', 'Player Name ', 1, 0, 'Scene2_Slide8');

lmsAPI.RecordFillInInteraction('17', rank, true, '', 'Rank ', 1, 0, 'Scene2_Slide8');


}

function Script4()
{
  window.timelast = player.GetVar('timeLast');
window.rank = player.GetVar('rank');
window.score = player.GetVar('score');
}

function Script5()
{
  var answersum = "";

if ( player.GetVar('answerM1') !== "")
   answersum +=  player.GetVar('answerM1') + ", ";
if ( player.GetVar('answerM2') !== "")
   answersum +=  player.GetVar('answerM2') + ", ";
if ( player.GetVar('answerM3') !== "")
   answersum +=  player.GetVar('answerM3') + ", ";
if ( player.GetVar('answerM4') !== "")
   answersum +=  player.GetVar('answerM4') + ", ";

lmsAPI.RecordFillInInteraction('18', answersum, true, '', 'Achievements ', 1, 0, 'Scene2_Slide8');
}

function Script6()
{
  var player = GetPlayer();
var formHTML = "<style>table {border-collapse:collapse;margin-top:20px;color:#373737} table, tr, td {padding: 10px;}tr:nth-child(even) {background:#E3F3EF; }tr:nth-child(odd) {background:#C7F1E6; }tr.header{background:#008A6E;color:white;font-weight:bold; }.logo { margin-bottom:10px;} .name {text-transform:uppercase;font-size:24px;font-weight:bold;color:#008A6E;}.label {font-weight:bold;}.logo span {font-size:27px; font-weight: bold; text-decoration:underline; color:#373737 } .logo img {float:right;}</style>";

var answersum = "";

if ( player.GetVar('answerM1') !== "")
   answersum +=  player.GetVar('answerM1') + ", ";
if ( player.GetVar('answerM2') !== "")
   answersum +=  player.GetVar('answerM2') + ", ";
if ( player.GetVar('answerM3') !== "")
   answersum +=  player.GetVar('answerM3') + ", ";
if ( player.GetVar('answerM4') !== "")
   answersum +=  player.GetVar('answerM4') + ", ";

formHTML += "<div class='logo'><span>Exercise Program And Drop Out</span><img src='http://www.playgen.com/chermug/chermug_logo.jpg'></div>";
formHTML += "<span class='name'>" +  player.GetVar('playerName')+ "</span><br/>";
formHTML += "<span class='label'>Score:</span> " + player.GetVar('score') + "<br/>";
formHTML += "<span class='label'>Rank:</span> " + player.GetVar('rank') + "<br/>";
formHTML += "<span class='label'>Time:</span> " + player.GetVar('timeLast') + "<br/>";
formHTML += "<span class='label'>Achievements:</span> " + answersum + "<br/>";

formHTML += "<table><tr class='header'><td>ID</td><td>Question</td><td>Answered</td><td>Correct/Incorrect</td></tr>";

var length = window.summary.question.length;
var question = null;
var answer = null;
var correct = null;

for (var i = 0; i < length; i++) {
question = window.summary.question[i];
answer = window.summary.answer[i];
correct = window.summary.correct[i];
id = i + 1;

formHTML += "<tr><td>" + id + "</td><td>" + question + "</td><td>" + answer + "</td><td>" + correct + "</td></tr>";

}

formHTML += "</table>";

formHTML += "<script>window.print();</script>";

var preview = window.open("about:blank");
preview.document.open();
preview.document.write(formHTML);
preview.document.close();
preview.print();
}

function Script7()
{
  var seconds=0;
timeVar = setTimeout(startTime,1000);

 
function startTime(){
seconds=seconds+1;
var player = GetPlayer();
player.SetVar("time",seconds);
timeVar = setTimeout(startTime,1000);
}
 
}

function Script8()
{
  player = GetPlayer();
answer1 = player.GetVar("answerM1");
answer2 = player.GetVar("answerM2");
answer3 = player.GetVar("answerM3");
answer4 = player.GetVar("answerM4");
answer5 = player.GetVar("answerM5");
answer6 = player.GetVar("answerM6");

var answersum = "";

if ( answer1 !== "")
   answersum += answer1 + ", ";
if ( answer2 !== "")
   answersum += answer2 + ", ";
if ( answer3 !== "")
   answersum += answer3 + ", ";
if ( answer4 !== "")
   answersum += answer4 + ", ";
if ( answer5 !== "")
   answersum += answer5 + ", ";
if ( answer6 !== "")
   answersum += answer6;




 window.summary.question.push('Wat zijn in de studie de hoofdvariabelen?');
  window.summary.answer.push(answersum);
  window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('1', answersum, false, '', 'Wat zijn in de studie de hoofdvariabelen?', 1, 0, 'Scene2_Slide6_1');
}

function Script9()
{
  window.achievements.advanceAchievement(0);
window.achievements.doEverythingAtOnce();
}

function Script10()
{
    window.summary.question.push('Wat zijn in de studie de hoofdvariabelen?');
  window.summary.answer.push('soort oefenprogramma, resultaat');
  window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('1', 'soort oefenprogramma, resultaat', true, '', 'Wat zijn in de studie de hoofdvariabelen?', 1, 0, 'Scene2_Slide9_1');
}

function Script11()
{
  var player = GetPlayer();
player.SetVar("answerM1", "");
player.SetVar("answerM2", "");
player.SetVar("answerM3", "");
player.SetVar("answerM4", "");
player.SetVar("answerM5", "");
player.SetVar("answerM6", "");
}

function Script12()
{
    window.summary.question.push('Wat zijn in deze studie de niveaus van de twee variabelen, soort oefenprogramma en het resultaat?');
  window.summary.answer.push('Body pump, Circuit training, Bleven in het programma, Vielen uit het programma');
  window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('2', 'Body pump, Circuit training, Bleven in het programma, Vielen uit het programma', true, '', 'Wat zijn in deze studie de niveaus van de twee variabelen, soort oefenprogramma en het resultaat?', 1, 0, 'Scene2_Slide6_2');
}

function Script13()
{
  player = GetPlayer();
answer1 = player.GetVar("answerM1");
answer2 = player.GetVar("answerM2");
answer3 = player.GetVar("answerM3");
answer4 = player.GetVar("answerM4");
answer5 = player.GetVar("answerM5");
answer6 = player.GetVar("answerM6");

var answersum = "";

if ( answer1 !== "")
   answersum += answer1 + ", ";
if ( answer2 !== "")
   answersum += answer2 + ", ";
if ( answer3 !== "")
   answersum += answer3 + ", ";
if ( answer4 !== "")
   answersum += answer4 + ", ";
if ( answer5 !== "")
   answersum += answer5 + ", ";
if ( answer6 !== "")
   answersum += answer6;




 window.summary.question.push('Wat zijn in deze studie de niveaus van de twee variabelen, soort oefenprogramma en het resultaat?');
  window.summary.answer.push(answersum);
  window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('2', answersum, false, '', 'Wat zijn in deze studie de niveaus van de twee variabelen, soort oefenprogramma en het resultaat?', 1, 0, 'Scene2_Slide6_2');
}

function Script14()
{
  
/*
 *
 * HANGMAN GAME
 *
 */

/*global GetPlayer:false */
var player = GetPlayer();
(function() {
	'use strict';
	window.hangman = {
		//Use capital letters
		questions: ["NOMINAL"],
		activeQuestion: -1,
		question: '',
		chars: [],
		foundChars: {},
		foundLetters: 0,
		alphabet: ["A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z", "Ex"],
		init: function()
		{
			//console.log("init");

		},
		/*
		 * Functions to be called from Storyline
		 */
		// Setup question and the word into letters
		setupQuestions: function(questionnumber)
		{
			this.foundLetters = 0;
			this.activeQuestion = questionnumber;
			this.question = this.questions[this.activeQuestion-1];
			this.chars = this.question.split('');
			this.foundChars = {};
			for (var i = this.alphabet.length - 1; i >= 0; i--)
				player.SetVar("hmChange"+ this.alphabet[i], 0);


		},
		// Check if any letter or the answer is found
		letterPressed: function(letter)
		{
			if (this.foundChars[letter])
				return;
			player.SetVar("hmChangeSet", 0);
			var found = 0;
			for (var i = this.chars.length - 1; i >= 0; i--) {
				var pos = i+1;
				if(this.chars[i] == letter) {
					player.SetVar("hml"  + pos, letter);
					found = 1;
					this.foundLetters++;
					this.foundChars[letter] = true;
					if (this.foundLetters >= this.chars.length) {
						player.SetVar("hmAnswerFound", 1);
					}	
				}
			}
			if( found != 1) {
				//cant put ! in the stroyline var
				if (letter == "!")
					letter = "Ex";

				var isPressed = player.GetVar("hmChange"+letter);
				if( isPressed == 0) {
				var tleft = player.GetVar("hmtleft");
				tleft = tleft -1;
				player.SetVar("hmtleft", tleft);
				player.SetVar("hmChange"+ letter, 1);
				}
			}
		 

			return;
		}
	};
	window.hangman.init();
})();

/*
 *
 * END OF HANGMAN GAME
 *
 */


}

function Script15()
{
  var seconds=3000;
// display();
var blinkTimer = setTimeout(display,400);
var flag = 0;
 
function display(){
	seconds=seconds-1;
	var player = GetPlayer();
	var tleft = player.GetVar("hmtleft");
	player.SetVar("hmtimer",seconds);
	if( tleft != 9) {
		if(flag == 0) {
			player.SetVar("hmBlink","hide");
			flag = 1;
		}
		else {
		player.SetVar("hmBlink","show");
		flag = 0;
		}
		var blinkTimer = setTimeout(display,400);
	}
	else 
	player.SetVar("hmBlink","show");
}
 
}

function Script16()
{
  window.hangman.setupQuestions(1);
}

function Script17()
{
  window.hangman.letterPressed("B");
}

function Script18()
{
  window.hangman.letterPressed("C");
}

function Script19()
{
  window.hangman.letterPressed("D");
}

function Script20()
{
  window.hangman.letterPressed("E");
}

function Script21()
{
  window.hangman.letterPressed("F");
}

function Script22()
{
  window.hangman.letterPressed("G");
}

function Script23()
{
  window.hangman.letterPressed("H");
}

function Script24()
{
  window.hangman.letterPressed("I");
}

function Script25()
{
  window.hangman.letterPressed("J");
}

function Script26()
{
  window.hangman.letterPressed("K");
}

function Script27()
{
  window.hangman.letterPressed("L");
}

function Script28()
{
  window.hangman.letterPressed("M");
}

function Script29()
{
  window.hangman.letterPressed("N");
}

function Script30()
{
  window.hangman.letterPressed("O");
}

function Script31()
{
  window.hangman.letterPressed("P");
}

function Script32()
{
  window.hangman.letterPressed("Q");
}

function Script33()
{
  window.hangman.letterPressed("R");
}

function Script34()
{
  window.hangman.letterPressed("S");
}

function Script35()
{
  window.hangman.letterPressed("T");
}

function Script36()
{
  window.hangman.letterPressed("U");
}

function Script37()
{
  window.hangman.letterPressed("V");
}

function Script38()
{
  window.hangman.letterPressed("W");
}

function Script39()
{
  window.hangman.letterPressed("X");
}

function Script40()
{
  window.hangman.letterPressed("Y");
}

function Script41()
{
  window.hangman.letterPressed("Z");
}

function Script42()
{
  window.hangman.letterPressed("!");
}

function Script43()
{
  window.hangman.letterPressed("A");
}

function Script44()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script45()
{
    window.summary.question.push('Wat was in de studie het meetniveau dat geschikt is voor het soort oefenprogramma?');
  window.summary.answer.push('Nominal');
  window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('3', 'Nominal', true, '', 'Wat was in de studie het meetniveau dat geschikt is voor het soort oefenprogramma?', 1, 0, 'Scene2_Slide7');
}

function Script46()
{
    window.summary.question.push('Wat was in de studie het meetniveau dat geschikt is voor het soort oefenprogramma?');
  window.summary.answer.push('');
  window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('3', '', false, '', 'Wat was in de studie het meetniveau dat geschikt is voor het soort oefenprogramma?', 1, 0, 'Scene2_Slide7');
}

function Script47()
{
  var seconds=4;
//setTimeout(display,1000);
display();
 
function display(){
seconds=seconds-1;
var player = GetPlayer();
player.SetVar("hmcready",seconds);
var cready = player.GetVar("hmcready");
if ( cready == 0) {
player.SetVar("hmcready", "Go!");
setTimeout(display,1000);
}
else if ( cready == -1) {
player.SetVar("hmcready", "next");
}
else {
setTimeout(display,1000);
}
}
}

function Script48()
{
  var player = GetPlayer();
var name= player.GetVar('achievementName');
var desc = player.GetVar('achievementDesc');

console.log("name:" + name);
console.log("description" + desc);
}

function Script49()
{
  window.hangman.setupQuestions(1);
var seconds=4;
//setTimeout(display,1000);
display();
 
function display(){
seconds=seconds-1;
var player = GetPlayer();
player.SetVar("hmcready",seconds);
var cready = player.GetVar("hmcready");
if ( cready == 0) {
player.SetVar("hmcready", "Go!");
setTimeout(display,1000);
}
else if ( cready == -1) {
player.SetVar("hmcready", "next");
setTimeout(display,1000);
}
else {
setTimeout(display,1000);
}
}
}

function Script50()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script51()
{
    window.summary.question.push('Welk meetniveau in de studie was geschikt voor de uitkomst');
  window.summary.answer.push('Nominal');
  window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('4', 'Nominal', true, '', 'Welk meetniveau in de studie was geschikt voor de uitkomst ', 1, 0, 'Scene2_Slide8_1');
}

function Script52()
{
  var player = GetPlayer();  
var answer = player.GetVar('answer');
window.summary.question.push('Welk meetniveau in de studie was geschikt voor de uitkomst');
window.summary.answer.push(answer);
window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('4', answer, false, '', 'Welk meetniveau in de studie was geschikt voor de uitkomst ', 1, 0, 'Scene2_Slide8_1');
}

function Script53()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script54()
{
    window.summary.question.push('Welk soort ontwerp suggereert deze studie?');
  window.summary.answer.push('een associatie tussen variabelen.');
  window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('5', 'een associatie tussen variabelen.', true, '', 'Welk soort ontwerp suggereert deze studie? ', 1, 0, 'Scene2_Slide8_2');
}

function Script55()
{
    window.summary.question.push('Welk soort ontwerp suggereert deze studie?');
  window.summary.answer.push('verschillen tussen groepen');
  window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('5', 'verschillen tussen groepen', false, '', 'Welk soort ontwerp suggereert deze studie? ', 1, 0, 'Scene2_Slide8_2');
}

function Script56()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script57()
{
    window.summary.question.push('Welke van onderstaande ruwe datasets is de juiste om te testen?');
  window.summary.answer.push('Dataset1');
  window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('9', 'Dataset1', true, '', 'Welke van onderstaande ruwe datasets is de juiste om te testen? ', 1, 0, 'Scene2_Slide9');
}

function Script58()
{
    window.summary.question.push('Welke van onderstaande ruwe datasets is de juiste om te testen?');
  window.summary.answer.push('Dataset2');
  window.summary.correct.push('Inorrect');

lmsAPI.RecordFillInInteraction('9', 'Dataset2', false, '', 'Welke van onderstaande ruwe datasets is de juiste om te testen? ', 1, 0, 'Scene2_Slide9');
}

function Script59()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script60()
{
  window.summary.question.push('Welke grafische afbeelding van de data zou je willen zien?');
window.summary.answer.push('Kruistabel');
window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('10', 'Kruistabel', true, '', 'Welke grafische afbeelding van de data zou je willen zien? ', 1, 0, 'Scene2_Slide10');

}

function Script61()
{
  window.summary.question.push('Welke grafische afbeelding van de data zou je willen zien?');
window.summary.answer.push('Boxplots');
window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('10', 'Boxplots', false, '', 'Welke grafische afbeelding van de data zou je willen zien? ', 1, 0, 'Scene2_Slide10');
}

function Script62()
{
  window.summary.question.push('Welke grafische afbeelding van de data zou je willen zien?');
window.summary.answer.push('Gemiddelden-tabel');
window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('10', 'Gemiddelden-tabel', false, '', 'Welke grafische afbeelding van de data zou je willen zien? ', 1, 0, 'Scene2_Slide10');
}

function Script63()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script64()
{
  player = GetPlayer();  
var answer = player.GetVar('answer');

window.summary.question.push('Welke teststatistiek zou jij willen zien?');
window.summary.answer.push(answer);
window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('12', answer, true, '', 'Welke teststatistiek zou jij willen zien? ', 1, 0, 'Scene2_Slide11_1');
}

function Script65()
{
  player = GetPlayer();  
var answer = player.GetVar('answer');

window.summary.question.push('Welke teststatistiek zou jij willen zien?');
window.summary.answer.push(answer);
window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('12', answer, false, '', 'Welke teststatistiek zou jij willen zien? ', 1, 0, 'Scene2_Slide11_1');
}

function Script66()
{
  player = GetPlayer();  
var answer = player.GetVar('answer');

window.summary.question.push('Welke teststatistiek zou jij willen zien?');
window.summary.answer.push(answer);
window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('12', answer, false, '', 'Welke teststatistiek zou jij willen zien? ', 1, 0, 'Scene2_Slide11_1');
}

function Script67()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}

var time = player.GetVar('time');
//Bronze Gold Silver
if( time <= 15000 && time > 1200 ) {
player.SetVar("achQuestionBronze",1);
}
if( time>= 10000 &&  time <= 12000) {
player.SetVar("achQuestionBronze",0);
player.SetVar("achQuestionSilver",1);
}
if( time < 10000 ) {
player.SetVar("achQuestionSilver",0);
player.SetVar("achQuestionGold",1);
}
}

function Script68()
{
  window.achievements.advanceAchievement(3);
window.achievements.doEverythingAtOnce();

window.achievements.advanceAchievement(4);
window.achievements.doEverythingAtOnce();




}

function Script69()
{
  window.summary.question.push('De berekende waarde voor chi -kwadraat was = 0,052, p <0.820. Was dit significant?');
window.summary.answer.push('Nee');
window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('13', 'Nee', true, '', 'De berekende waarde voor chi -kwadraat was = 0,052, p <0.820. Was dit significant? ', 1, 0, 'Scene2_Slide11_2');
}

function Script70()
{
  var player = GetPlayer();
var time = player.GetVar('time');
//Bronze Gold Silver
if( time <= 15000 && time > 1200 ) {
player.SetVar("achQuestionBronze",1);
}
if( time>= 10000 &&  time <= 12000) {
player.SetVar("achQuestionBronze",0);
player.SetVar("achQuestionSilver",1);
}
if( time < 10000 ) {
player.SetVar("achQuestionSilver",0);
player.SetVar("achQuestionGold",1);
}

window.achievements.advanceAchievement(4);
window.achievements.doEverythingAtOnce();
}

function Script71()
{
  window.summary.question.push('De berekende waarde voor chi -kwadraat was = 0,052, p <0.820. Was dit significant?');
window.summary.answer.push('Ja');
window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('13', 'Ja', false, '', 'De berekende waarde voor chi -kwadraat was = 0,052, p <0.820. Was dit significant? ', 1, 0, 'Scene2_Slide11_2');
}

function Script72()
{
  
/*
 *
 * TIC-TAC-TOE GAME
 *
 */

/*global GetPlayer:false */
var player = GetPlayer();
(function() {
	'use strict';
	var state = {
		READY: 0,
		RIGHT: 1,
		WRONG: 2
	};
	var validValues = [
	// Rows
		1  | 2   | 4,
		8  | 16  | 32,
		64 | 128 | 256,
		// Columns
		1  | 8   | 64,
		2  | 16  | 128,
		4  | 32  | 256,
		// Diagonals
		1 | 16 | 256,
		4 | 16 | 64
	];
	window.ttt = {
		questions: [
			{
				text: "In totaal waren er 140 deelnemers in deze studie.",
				wrong: "Niet correct.",
				answer: true
			},
			{
				text: "De helft van de deelnemers nam deel aan het body pump programma, de andere helft aan de circuit training.",
				wrong: "Niet correct.",
				answer: false
			},
			{
				text: "In totaal waren er meer mensen in de steekproef die in het programma bleven dan dat er uitvielen.",
				wrong: "Niet correct.",
				answer: true
			},
			{
				text: "Er waren meer mensen die uitvielen in het circuit training programma dan in het body pump programma.",
				wrong: "Niet correct.",
				answer: false
			},
			{
				text: "De helft van de deelnemers nam deel aan het body pump programma, de andere helft aan de circuit training.",
				wrong: "Niet correct.",
				answer: false
			},
			{
				text: "In totaal waren er meer mensen die deelnemen aan het body pump programma dan aan de circuit training.",
				wrong: "Niet correct.",
				answer: true
			},
			{
				text: "Er waren meer mensen die uitvielen in het circuit training programma dan in het body pump programma. ",
				wrong: "Niet correct.",
				answer: false
			},
			{
				text: "Er waren meer deelnemers die volhielden in de circuit training dan uitvallers.",
				wrong: "Niet correct.",
				answer: true
			},
			{
				text: "Meer mensen stopten met het body pump programma dan met het circuit training programma.  ",
				wrong: "Niet correct.",
				answer: true
			}
		],
		activeQuestion: -1,
		totalValue: 0,
		init: function()
		{
			if (this.questions.length !== 9) {
				alert("Question count missmatch! Got " + this.questions.length + " expected 9");
				return;
			}
			var value = 1;
			// Setup the Qs with redundant info

var length = this.questions.length,
element = null;
for (var i = 0; i < length; i++) {
element = this.questions[i];
element .id = i;
element .value = value;
element .state = state.READY;
value *= 2;
}
		},
		updateQState: function(question, state)
		{
			question.state = state;
			player.SetVar('tttQuestionState' + question.id, state);
		},
		/*
		 * Functions to be called from Storyline
		 */
		// Resets all the question vars to ready
		setupQuestions: function()
		{
			this.activeQuestion = null;
			this.totalValue = 0;
			player.SetVar('tttQuestionText', '');
			player.SetVar('tttSlideSolved', 0);
var length = this.questions.length,
element = null;
for (var i = 0; i < length; i++) {
element = this.questions[i];
this.updateQState(element , state.READY);
}

		},
		// For when the user picks a question
		chooseQuestion: function(quid)
		{
			var question = this.questions[quid];
			if (question.state !== state.READY)
				return;
			this.activeQuestion = question;
			player.SetVar('tttQuestionText', question.text);
		},
		// Check if the answer is correctus
		checkAnswer: function(choice)
		{
			// Get what we're talkin about
			var question = this.activeQuestion;
			// Hide the question window
var questionText = player.GetVar('tttQuestionText');
			player.SetVar('tttQuestionText', '');
			// Reset the wrong var so we can trigger it if necessary
			player.SetVar('tttQuestionWrong', '');
			// Determine failure
			var choice_ = (choice == 'true') ? true : false;
			// If you pass you're wrong and stupid
			if (choice === 'pass' || choice_ !== question.answer) {
				this.updateQState(question, state.WRONG);
				// Pop up the "no u stupid" box
				player.SetVar('tttQuestionWrong', question.wrong);

window.summary.question.push(questionText);
window.summary.answer.push(choice_);
window.summary.correct.push('Incorrect');

				return;
			}
			// success!
window.summary.question.push(questionText);
window.summary.answer.push(question.answer);
window.summary.correct.push('Correct');
			this.updateQState(question, state.RIGHT);
			this.totalValue |= question.value;
			// Check if we've won
var length = validValues.length,
value = null;
for (var i = 0; i < length; i++) {
value = validValues[i];
if  ( (this.totalValue & value) === value )
player.SetVar('tttSlideSolved', 1);
}
		}
	};
	window.ttt.init();
})();

/*
 *
 * END OF TIC-TAC-TOE GAME
 *
 */


}

function Script73()
{
  window.ttt.setupQuestions();
}

function Script74()
{
  window.ttt.setupQuestions();
}

function Script75()
{
  window.ttt.chooseQuestion(0);
}

function Script76()
{
  window.ttt.chooseQuestion(1);
}

function Script77()
{
  window.ttt.chooseQuestion(2);
}

function Script78()
{
  window.ttt.chooseQuestion(3);
}

function Script79()
{
  window.ttt.chooseQuestion(4);
}

function Script80()
{
  window.ttt.chooseQuestion(5);
}

function Script81()
{
  window.ttt.chooseQuestion(6);
}

function Script82()
{
  window.ttt.chooseQuestion(7);
}

function Script83()
{
  window.ttt.chooseQuestion(8);
}

function Script84()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}

lmsAPI.RecordFillInInteraction('11', 'Completed', true, '', 'Microscope Game ', 1, 0, 'Scene2_Slide12');






}

function Script85()
{
  lmsAPI.RecordFillInInteraction('11', '', false, '', 'Microscope Game ', 1, 0, 'Scene2_Slide10');
}

function Script86()
{
  var eyesshut = 100, eyesopen = 10000, inblink = false;
var player = GetPlayer();
function blink(){
  inblink = !inblink;
  if (inblink) {
    player.SetVar('blinkState', 'hide');
    setTimeout(blink, eyesshut + Math.random() * 40);
  } else {
    player.SetVar('blinkState', 'show');
    setTimeout(blink, eyesopen + Math.random() * 500);
  }
}

blink(); 
}

function Script87()
{
  window.ttt.checkAnswer('true');
}

function Script88()
{
  window.ttt.checkAnswer('false');
}

function Script89()
{
  var player = GetPlayer();
player.SetVar("answerM1", "");
player.SetVar("answerM2", "");
player.SetVar("answerM3", "");
player.SetVar("answerM4", "");
player.SetVar("answerM5", "");
player.SetVar("answerM6", "");
}

function Script90()
{
   window.summary.question.push('Null-hypothesis Part 1');
  window.summary.answer.push('Er is een verband');
  window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('6', 'Er is een verband', false, '', 'Null-hypothesis Part 1 ', 1, 0, 'Scene2_Slide15_1');
}

function Script91()
{
  player = GetPlayer();
answer1 = player.GetVar("answerM4");
answer2 = player.GetVar("answerM3");

 window.summary.question.push('Null-hypothesis Part2');
  window.summary.answer.push(answer1 + answer2);
  window.summary.correct.push('Incorrect');

var answersum = answer1 + answer2;

lmsAPI.RecordFillInInteraction('7', answersum, false, '', 'Null-hypothesis Part 2 ', 1, 0, 'Scene2_Slide15_2');
}

function Script92()
{
  player = GetPlayer();
answer1 = player.GetVar("answerM5");
answer2 = player.GetVar("answerM6");

 window.summary.question.push('Null-hypothesis Part3');
  window.summary.answer.push(answer1 + answer2);
  window.summary.correct.push('Incorrect');

var answersum = answer1 + answer2;

lmsAPI.RecordFillInInteraction('8', answersum, false, '', 'Null-hypothesis Part 3 ', 1, 0, 'Scene2_Slide15_3');
}

function Script93()
{
    window.summary.question.push('Null-hypothesis Part1');
  window.summary.answer.push('Er is geen verband');
  window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('6', 'Er is geen verband', true, '', 'Null-hypothesis Part 1 ', 1, 0, 'Scene2_Slide15_1');
}

function Script94()
{
    window.summary.question.push('Null-hypothesis Part2');
  window.summary.answer.push('Tussen het soort oefenprogrammas');
  window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('7', 'Tussen het soort oefenprogrammas', true, '', 'Null-hypothesis Part 2 ', 1, 0, 'Scene2_Slide15_2');
}

function Script95()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script96()
{
    window.summary.question.push('Null-hypothesis Part3');
  window.summary.answer.push('en de uitkomst');
  window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('8', 'en de uitkomst', true, '', 'Null-hypothesis Part 3 ', 1, 0, 'Scene2_Slide15_3');
}

