function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6YHjmUa8qCs":
        Script1();
        break;
      case "63xnKStn1ZD":
        Script2();
        break;
      case "6lHKrrDqeCI":
        Script3();
        break;
      case "5fKs1iKDcAZ":
        Script4();
        break;
      case "5yDGKAYm3Wk":
        Script5();
        break;
      case "6NYA7W88Bqu":
        Script6();
        break;
      case "6TLSzI2JNoC":
        Script7();
        break;
      case "6ZF7gbw2MlA":
        Script8();
        break;
      case "6V9tQ6n0aoE":
        Script9();
        break;
      case "6YoZZlqRRC6":
        Script10();
        break;
      case "5e5HLYDXLzR":
        Script11();
        break;
      case "5j4wGqFstmR":
        Script12();
        break;
      case "6F5CzquhnpW":
        Script13();
        break;
      case "6PbtDP2Mxjf":
        Script14();
        break;
      case "5uIPacNrSHk":
        Script15();
        break;
      case "6mITJiPkUL5":
        Script16();
        break;
      case "5zgIo8MeEzw":
        Script17();
        break;
      case "6DavqpolGfL":
        Script18();
        break;
      case "6CCvbj99wW5":
        Script19();
        break;
      case "6mXI70uNDit":
        Script20();
        break;
      case "5VmV3J3H1Ay":
        Script21();
        break;
      case "6ZjpOMOJ5mR":
        Script22();
        break;
      case "5rzzmTWM0r7":
        Script23();
        break;
      case "6H6i17Qvvx1":
        Script24();
        break;
      case "5xOoeW7VMNo":
        Script25();
        break;
      case "5a4KKa12QQW":
        Script26();
        break;
      case "6Y5pHfGI9Tp":
        Script27();
        break;
      case "6SDeqoVp09p":
        Script28();
        break;
      case "6r9e5ZyeCUp":
        Script29();
        break;
      case "5uS85lcYcsk":
        Script30();
        break;
      case "6WDAsVGBAur":
        Script31();
        break;
      case "5xn5Zmac7HT":
        Script32();
        break;
      case "69wnwE8JCNQ":
        Script33();
        break;
      case "6oX8b1XNaxP":
        Script34();
        break;
      case "5fMXjLH6bXh":
        Script35();
        break;
      case "5wWvFo6UyA0":
        Script36();
        break;
      case "5h9nyHsXRrX":
        Script37();
        break;
      case "5x6ZupXRmyu":
        Script38();
        break;
      case "5iJXseFtnLy":
        Script39();
        break;
      case "6bb4UGgLFrU":
        Script40();
        break;
      case "5useeWZUzUN":
        Script41();
        break;
      case "6ICOpaetR4S":
        Script42();
        break;
      case "63LyDiQS9t9":
        Script43();
        break;
      case "6UdFZIc07tL":
        Script44();
        break;
      case "5xn61VRHpS6":
        Script45();
        break;
      case "5rjuRNgYbaS":
        Script46();
        break;
      case "6MavnDn0ivQ":
        Script47();
        break;
      case "6NaFL53U61Y":
        Script48();
        break;
      case "6ZEANY46Lbp":
        Script49();
        break;
      case "6VGhgWy3BXK":
        Script50();
        break;
      case "5mykLoHL3bD":
        Script51();
        break;
      case "5huzxmM7Rrc":
        Script52();
        break;
      case "5pDk8Wseds5":
        Script53();
        break;
      case "6kNdYzvB9FY":
        Script54();
        break;
      case "6V6PcUNv4I2":
        Script55();
        break;
      case "6U5JGhPuxd7":
        Script56();
        break;
      case "5lk9C7wpTte":
        Script57();
        break;
      case "63tpmfhtGyo":
        Script58();
        break;
      case "5cvDRi1Ivuf":
        Script59();
        break;
      case "5c9tpVu8Ttd":
        Script60();
        break;
      case "5kvy3s5u90l":
        Script61();
        break;
      case "5WoTAIcAel0":
        Script62();
        break;
      case "5qPdVFV1TU0":
        Script63();
        break;
      case "6T19VEIpRIR":
        Script64();
        break;
      case "5vLabY5xVy9":
        Script65();
        break;
      case "5cUApL7TgSn":
        Script66();
        break;
      case "6mpDKhp9NsM":
        Script67();
        break;
      case "64RRb0YWZIl":
        Script68();
        break;
      case "6BYX0H5GZW7":
        Script69();
        break;
      case "6lN1T8AwYQs":
        Script70();
        break;
      case "6CCfQ8izpdP":
        Script71();
        break;
      case "5a7fXikokED":
        Script72();
        break;
      case "6QBUiq49rAF":
        Script73();
        break;
      case "6KmW1gB988r":
        Script74();
        break;
      case "5o9WLxya2Cr":
        Script75();
        break;
      case "6cMuwNW2imD":
        Script76();
        break;
      case "6RAqJG3KfCy":
        Script77();
        break;
      case "5aGO02bcoAj":
        Script78();
        break;
      case "6BcmUe0XUPn":
        Script79();
        break;
      case "5plaR3AeNcP":
        Script80();
        break;
      case "6CGvSAcMlrz":
        Script81();
        break;
      case "6Woe0r3uRT6":
        Script82();
        break;
      case "6beHXKrLgev":
        Script83();
        break;
      case "6XNaCpMOczH":
        Script84();
        break;
      case "6m5VsQbqf03":
        Script85();
        break;
      case "6HqXG6pidQs":
        Script86();
        break;
      case "6XZ0jxgcu1I":
        Script87();
        break;
      case "5vLqL4vcz7o":
        Script88();
        break;
      case "5myGCADpfJq":
        Script89();
        break;
      case "6XUxuWPvuSr":
        Script90();
        break;
      case "6d9eJDXlRWA":
        Script91();
        break;
      case "5vAsxJIp2N0":
        Script92();
        break;
      case "6J4wMgNjR6D":
        Script93();
        break;
      case "5becrsiZ8Vi":
        Script94();
        break;
      case "6iTKsuJQXlU":
        Script95();
        break;
      case "6kQ5blXZJQR":
        Script96();
        break;
      case "6LU2v9jgdtn":
        Script97();
        break;
      case "5l50v6u49LD":
        Script98();
        break;
      case "6dAj7Z44eIg":
        Script99();
        break;
      case "5XcMKVkEtBV":
        Script100();
        break;
      case "68iUBbb3Aaf":
        Script101();
        break;
      case "6oUUmHi2YQT":
        Script102();
        break;
      case "6TiS3fbPQWH":
        Script103();
        break;
      case "6rQEZdJTtlP":
        Script104();
        break;
  }
}

function Script1()
{
  
/*
 *
 *   ACHIEVEMENTS
 *
 */

/*global GetPlayer:false */
var player = GetPlayer();
(function() {
	'use strict';
	window.achievements = {
		achievements: [
			{
				name: "First Question",
				desc: "You have successfully answered first question correctly.",
				advance: function()
				{
					this.completed = true;
				}
			},
			{
				name: "Three in a row",
				desc: "You have successfully answered three questions correctly in a row.",
				rowCounter: 0,
				advance: function()
				{
					var rowCounter = player.GetVar('ach3Question');
					if (rowCounter  == 3)
						this.completed = true;
				}
			},
			{
				name: "Hypothesis",
				desc: "You have successfully answered all hypothesis questions without any wrong answer.",
				rowCounter: 0,
				advance: function()
				{
					var isHypothesis = player.GetVar('achHypothesis');
					console.log(isHypothesis);
					if (isHypothesis  == 1)
						this.completed = true;
				}
			},
			{
				name: "All",
				desc: "You have successfully answered all of the questions correct.",
				rowCounter: 0,
				advance: function()
				{
					var isAll = player.GetVar('achAll');
					console.log(isAll);
					if (isAll  == 1)
						this.completed = true;
				}
			},
			{
				name: "",
				desc: "",
				rowCounter: 0,
				advance: function()
				{
					//In each case it will earn something
					this.completed = true;
				}
			},

		],
		completedThisRound: [],

		init: function()
		{
			for (var i = 0; i < this.achievements.length; ++i) {
				this.achievements[i].id = i;
			}
		},
		// public
		advanceAchievement: function(achid)
		{
			var ach = this.achievements[achid];
			if (!ach)
				return;
			if (ach.completed)
				return;
			ach.advance();
			if (!ach.completed)
				return;
			this.completedThisRound.push(ach);
		},
		checkForAchievements: function()
		{
			return this.completedThisRound.length > 0;
		},
		resetAchievementVars: function()
		{
			player.SetVar('achievementActive', 0);
			player.SetVar('achievementName', '');
			player.SetVar('achievementDesc', '');
			player.SetVar('achivementId', -1);
		},
		setupAchievementVars: function()
		{
			var ach = this.completedThisRound.shift();
			player.SetVar('achievementActive', 1);
			player.SetVar('achievementName', ach.name);
			player.SetVar('achievementDesc', ach.desc);
			player.SetVar('achivementId', ach.id);
			player.SetVar('achievementUnlocked' + ach.id, 1);
		},
		// public
		doEverythingAtOnce: function()
		{
			this.resetAchievementVars();
			if (this.checkForAchievements())
				this.setupAchievementVars();

		}
	};
	window.achievements.init();
})();

/*
 *
 *  END OF ACHIEVEMENTS 
 *
 */

}

function Script2()
{
  var eyesshut = 100, eyesopen = 10000, inblink = false;
var player = GetPlayer();
var isPopUp = player.GetVar("isPopUp");
function blink(){
  inblink = !inblink;
 if (isPopUp == 1) {
 setTimeout(blink, 100);
}
  else if (inblink) {
    player.SetVar('blinkState', 'hide');
    setTimeout(blink, eyesshut + Math.random() * 100);
  } else {
    player.SetVar('blinkState', 'show');
    setTimeout(blink, eyesopen + Math.random() * 1000);
  }
}

blink(); 

window.summary = {question: [], answer: [], correct: []}; 
}

function Script3()
{
  var player = GetPlayer();
player.SetVar("answerM1", "");
player.SetVar("answerM2", "");
player.SetVar("answerM3", "");
player.SetVar("answerM4", "");
player.SetVar("answerM5", "");
player.SetVar("answerM6", "");
}

function Script4()
{
   window.summary.question.push('Formulate the null-hypothesis - Part1');
  window.summary.answer.push('on eroa');
  window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('7', 'on eroa', false, '', 'Null-hypothesis Part 1 ', 1, 0, 'Scene2_Slide5_1');
}

function Script5()
{
  var player = GetPlayer();
var answer1 = player.GetVar("answerM4");
var answer2 = player.GetVar("answerM3");

 window.summary.question.push('Formulate the null-hypothesis  - Part2');
  window.summary.answer.push(answer1 + answer2);
  window.summary.correct.push('Incorrect');

var answer = answer1 + answer2;

lmsAPI.RecordFillInInteraction('8', answer, false, '', 'Null-hypothesis Part 2', 1, 0, 'Scene2_Slide5_2');
}

function Script6()
{
  var player = GetPlayer();
var answer1 = player.GetVar("answerM5");
var answer2 = player.GetVar("answerM6");

 window.summary.question.push('Formulate the null-hypothesis - Part3');
  window.summary.answer.push(answer1 + answer2);
  window.summary.correct.push('Incorrect');

var answer = answer1 + answer2;

lmsAPI.RecordFillInInteraction('9', answer, false, '', 'Null-hypothesis Part 3', 1, 0, 'Scene2_Slide5_3');
}

function Script7()
{
    window.summary.question.push('Formulate the null-hypothesis  - Part1');
  window.summary.answer.push('ei ole eroa');
  window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('7', 'ei ole eroa', true, '', 'Null-hypothesis Part 1 ', 1, 0, 'Scene2_Slide5_1');
}

function Script8()
{
    window.summary.question.push('Formulate the null-hypothesis  - Part2');
  window.summary.answer.push('poikien ja tyttöjen välillä');
  window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('8', 'poikien ja tyttöjen välillä', true, '', 'Null-hypothesis Part 2', 1, 0, 'Scene2_Slide5_2');
}

function Script9()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script10()
{
    window.summary.question.push('Formulate the null-hypothesis - Part3');
  window.summary.answer.push('lihatuotteiden kulutuksen määrässä');
  window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('9', 'lihatuotteiden kulutuksen määrässä', true, '', 'Null-hypothesis Part 3', 1, 0, 'Scene2_Slide5_3');
}

function Script11()
{
  var player = GetPlayer();
var score = player.GetVar('score');
var rank;
window.clearTimeout(timeVar);

//Score
if( score >= 1500 )
 rank = "A";
else if( score >= 1400 )
 rank = "B";
else if( score >= 1300 )
 rank = "C";
else if( score >= 1200 )
 rank = "D";
else 
 rank = "E";

player.SetVar('rank', rank);

//Time
function zeroPad(num, places) {
  var zero = places - num.toString().length + 1;
  return Array(+(zero > 0 && zero)).join("0") + num;
}

var time = player.GetVar('time');

var minutes = Math.floor(time / 60);
var seconds = time - minutes * 60;

minutes  = zeroPad(minutes, 2);
seconds  = zeroPad(seconds, 2);

var NewTime = minutes+":"+seconds;
player.SetVar('timeLast', NewTime );

player.SetVar("answerM1", "");
player.SetVar("answerM2", "");
player.SetVar("answerM3", "");
player.SetVar("answerM4", "");
player.SetVar("answerM5", "");
player.SetVar("answerM6", "");

lmsAPI.RecordFillInInteraction('17', score, true, '', 'Score ', 1, 0, 'Scene2_Slide8');
lmsAPI.RecordFillInInteraction('18', NewTime, true, '', 'Playing Time ', 1, 0, 'Scene2_Slide8');

lmsAPI.SetPassed();
player = GetPlayer();
var correct = player.GetVar("correctcounter");
var question = player.GetVar("questioncounter");

var score = ( correct / question ) * 100;
score =  Math.round( Number(score));
player.SetVar("calculatedscore", score);
player.SetVar("calculatedcorrect",correct);
player.SetVar("calculatedquestion",question);

lmsAPI.SetScore(score,100,0);

lmsAPI.RecordFillInInteraction('19', playerName, true, '', 'Player Name ', 1, 0, 'Scene2_Slide8');

lmsAPI.RecordFillInInteraction('20', rank, true, '', 'Rank ', 1, 0, 'Scene2_Slide8');

}

function Script12()
{
  var answersum = "";

if ( player.GetVar('answerM1') !== "")
   answersum +=  player.GetVar('answerM1') + ", ";
if ( player.GetVar('answerM2') !== "")
   answersum +=  player.GetVar('answerM2') + ", ";
if ( player.GetVar('answerM3') !== "")
   answersum +=  player.GetVar('answerM3') + ", ";
if ( player.GetVar('answerM4') !== "")
   answersum +=  player.GetVar('answerM4') + ", ";

lmsAPI.RecordFillInInteraction('21', answersum, true, '', 'Achievements ', 1, 0, 'Scene2_Slide8');
}

function Script13()
{
  var player = GetPlayer();
var formHTML = "<style>table {border-collapse:collapse;margin-top:20px;color:#373737} table, tr, td {padding: 10px;}tr:nth-child(even) {background:#E3F3EF; }tr:nth-child(odd) {background:#C7F1E6; }tr.header{background:#008A6E;color:white;font-weight:bold; }.logo { margin-bottom:10px;} .name {text-transform:uppercase;font-size:24px;font-weight:bold;color:#008A6E;}.label {font-weight:bold;}.logo span {font-size:27px; font-weight: bold; text-decoration:underline; color:#373737 } .logo img {float:right;}</style>";

var answersum = "";

if ( player.GetVar('answerM1') !== "")
   answersum +=  player.GetVar('answerM1') + ", ";
if ( player.GetVar('answerM2') !== "")
   answersum +=  player.GetVar('answerM2') + ", ";
if ( player.GetVar('answerM3') !== "")
   answersum +=  player.GetVar('answerM3') + ", ";
if ( player.GetVar('answerM4') !== "")
   answersum +=  player.GetVar('answerM4') + ", ";

formHTML += "<div class='logo'><span>Gender and Protein Consumption</span><img src='http://www.playgen.com/chermug/chermug_logo.jpg'></div>";
formHTML += "<span class='name'>" +  player.GetVar('playerName')+ "</span><br/>";
formHTML += "<span class='label'>Score:</span> " + player.GetVar('score') + "<br/>";
formHTML += "<span class='label'>Rank:</span> " + player.GetVar('rank') + "<br/>";
formHTML += "<span class='label'>Time:</span> " + player.GetVar('timeLast') + "<br/>";
formHTML += "<span class='label'>Achievements:</span> " + answersum + "<br/>";

formHTML += "<table><tr class='header'><td>ID</td><td>Question</td><td>Answered</td><td>Correct/Incorrect</td></tr>";

var length = window.summary.question.length;
var question = null;
var answer = null;
var correct = null;

for (var i = 0; i < length; i++) {
question = window.summary.question[i];
answer = window.summary.answer[i];
correct = window.summary.correct[i];
id = i + 1;

formHTML += "<tr><td>" + id + "</td><td>" + question + "</td><td>" + answer + "</td><td>" + correct + "</td></tr>";

}

formHTML += "</table>";

formHTML += "<script>window.print();</script>";

var preview = window.open("about:blank");
preview.document.open();
preview.document.write(formHTML);
preview.document.close();
preview.print();
}

function Script14()
{
  var seconds=0;
timeVar = setTimeout(startTime,1000);

 
function startTime(){
seconds=seconds+1;
var player = GetPlayer();
player.SetVar("time",seconds);
timeVar = setTimeout(startTime,1000);
}
 
}

function Script15()
{
  var player = GetPlayer();
var answer1 = player.GetVar("answerM1");
var answer2 = player.GetVar("answerM2");
var answer3 = player.GetVar("answerM3");
var answer4 = player.GetVar("answerM4");
var answer5 = player.GetVar("answerM5");
var answer6 = player.GetVar("answerM6");

var answersum = "";

if ( answer1 !== "")
   answersum += answer1 + ", ";
if ( answer2 !== "")
   answersum += answer2 + ", ";
if ( answer3 !== "")
   answersum += answer3 + ", ";
if ( answer4 !== "")
   answersum += answer4 + ", ";
if ( answer5 !== "")
   answersum += answer5 + ", ";
if ( answer6 !== "")
   answersum += answer6 + ", ";


 window.summary.question.push('Mitkä ovat tämän tutkimuksen muuttujat?');
  window.summary.answer.push(answersum);
  window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('1', answersum, false, '', 'Mitkä ovat tämän tutkimuksen muuttujat?', 1, 0, 'Scene2_Slide9_1');
}

function Script16()
{
  window.achievements.advanceAchievement(0);
window.achievements.doEverythingAtOnce();
}

function Script17()
{
  var player = GetPlayer();
var answer1 = player.GetVar("answerM1");
var answer2 = player.GetVar("answerM2");
var answer3 = player.GetVar("answerM3");
var answer4 = player.GetVar("answerM4");
var answer5 = player.GetVar("answerM5");
var answer6 = player.GetVar("answerM6");

var answersum = "";

if ( answer1 !== "")
   answersum += answer1 + ", ";
if ( answer2 !== "")
   answersum += answer2 + ", ";
if ( answer3 !== "")
   answersum += answer3 + ", ";
if ( answer4 !== "")
   answersum += answer4 + ", ";
if ( answer5 !== "")
   answersum += answer5 + ", ";
if ( answer6 !== "")
   answersum += answer6 + ", ";


 window.summary.question.push('Mitkä ovat tämän tutkimuksen muuttujat?');
  window.summary.answer.push(answersum);
  window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('1', answersum, true, '', 'Mitkä ovat tämän tutkimuksen muuttujat?', 1, 0, 'Scene2_Slide9_1');
}

function Script18()
{
  var player = GetPlayer();
player.SetVar("answerM1", "");
player.SetVar("answerM2", "");
player.SetVar("answerM3", "");
player.SetVar("answerM4", "");
player.SetVar("answerM5", "");
player.SetVar("answerM6", "");
}

function Script19()
{
  var player = GetPlayer();
var answer1 = player.GetVar("answerM1");
var answer2 = player.GetVar("answerM2");
var answer3 = player.GetVar("answerM3");
var answer4 = player.GetVar("answerM4");
var answer5 = player.GetVar("answerM5");
var answer6 = player.GetVar("answerM6");

var answersum = "";

if ( answer1 !== "")
   answersum += answer1 + ", ";
if ( answer2 !== "")
   answersum += answer2 + ", ";
if ( answer3 !== "")
   answersum += answer3 + ", ";
if ( answer4 !== "")
   answersum += answer4 + ", ";
if ( answer5 !== "")
   answersum += answer5 + ", ";
if ( answer6 !== "")
   answersum += answer6 + ", ";


 window.summary.question.push('Mikä oli tämän tutkimuksen selittävä (riippumaton) muuttuja?');
  window.summary.answer.push(answersum);
  window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('2', answersum, true, '', 'Mikä oli tämän tutkimuksen selittävä (riippumaton) muuttuja?', 1, 0, 'Scene2_Slide9_2');
}

function Script20()
{
  var player = GetPlayer();
var answer1 = player.GetVar("answerM1");
var answer2 = player.GetVar("answerM2");
var answer3 = player.GetVar("answerM3");
var answer4 = player.GetVar("answerM4");
var answer5 = player.GetVar("answerM5");
var answer6 = player.GetVar("answerM6");

var answersum = "";

if ( answer1 !== "")
   answersum += answer1 + ", ";
if ( answer2 !== "")
   answersum += answer2 + ", ";
if ( answer3 !== "")
   answersum += answer3 + ", ";
if ( answer4 !== "")
   answersum += answer4 + ", ";
if ( answer5 !== "")
   answersum += answer5 + ", ";
if ( answer6 !== "")
   answersum += answer6 + ", ";


 window.summary.question.push('Mikä oli tämän tutkimuksen selittävä (riippumaton) muuttuja?');
  window.summary.answer.push(answersum);
  window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('2', answersum, false, '', 'Mikä oli tämän tutkimuksen selittävä (riippumaton) muuttuja?', 1, 0, 'Scene2_Slide9_2');
}

function Script21()
{
  var player = GetPlayer();
player.SetVar("answerM1", "");
player.SetVar("answerM2", "");
player.SetVar("answerM3", "");
player.SetVar("answerM4", "");
player.SetVar("answerM5", "");
player.SetVar("answerM6", "");
}

function Script22()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script23()
{
  var player = GetPlayer();
var answer1 = player.GetVar("answerM1");
var answer2 = player.GetVar("answerM2");
var answer3 = player.GetVar("answerM3");
var answer4 = player.GetVar("answerM4");
var answer5 = player.GetVar("answerM5");
var answer6 = player.GetVar("answerM6");

var answersum = "";

if ( answer1 !== "")
   answersum += answer1 + ", ";
if ( answer2 !== "")
   answersum += answer2 + ", ";
if ( answer3 !== "")
   answersum += answer3 + ", ";
if ( answer4 !== "")
   answersum += answer4 + ", ";
if ( answer5 !== "")
   answersum += answer5 + ", ";
if ( answer6 !== "")
   answersum += answer6 + ", ";


 window.summary.question.push('Mikä oli tämän tutkimuksen selitettävä (riippuva) muuttuja?');
  window.summary.answer.push(answersum);
  window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('3', answersum, true, '', 'Mikä oli tämän tutkimuksen selitettävä (riippuva) muuttuja?', 1, 0, 'Scene2_Slide9_3');
}

function Script24()
{
  var player = GetPlayer();
var answer1 = player.GetVar("answerM1");
var answer2 = player.GetVar("answerM2");
var answer3 = player.GetVar("answerM3");
var answer4 = player.GetVar("answerM4");
var answer5 = player.GetVar("answerM5");
var answer6 = player.GetVar("answerM6");

var answersum = "";

if ( answer1 !== "")
   answersum += answer1 + ", ";
if ( answer2 !== "")
   answersum += answer2 + ", ";
if ( answer3 !== "")
   answersum += answer3 + ", ";
if ( answer4 !== "")
   answersum += answer4 + ", ";
if ( answer5 !== "")
   answersum += answer5 + ", ";
if ( answer6 !== "")
   answersum += answer6 + ", ";


 window.summary.question.push('Mikä oli tämän tutkimuksen selitettävä (riippuva) muuttuja?');
  window.summary.answer.push(answersum);
  window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('3', answersum, false, '', 'Mikä oli tämän tutkimuksen selitettävä (riippuva) muuttuja?', 1, 0, 'Scene2_Slide9_3');
}

function Script25()
{
  
/*
 *
 * HANGMAN GAME
 *
 */

/*global GetPlayer:false */
var player = GetPlayer();
(function() {
	'use strict';
	window.hangman = {
		//Use capital letters
		questions: ["SUHDELUKUASTEIKKO"],
		activeQuestion: -1,
		question: '',
		chars: [],
		foundChars: {},
		foundLetters: 0,
		alphabet: ["A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z", "Ex"],
		init: function()
		{
			//console.log("init");

		},
		/*
		 * Functions to be called from Storyline
		 */
		// Setup question and the word into letters
		setupQuestions: function(questionnumber)
		{
			this.foundLetters = 0;
			this.activeQuestion = questionnumber;
			this.question = this.questions[this.activeQuestion-1];
			this.chars = this.question.split('');
			this.foundChars = {};
			for (var i = this.alphabet.length - 1; i >= 0; i--)
				player.SetVar("hmChange"+ this.alphabet[i], 0);


		},
		// Check if any letter or the answer is found
		letterPressed: function(letter)
		{
			if (this.foundChars[letter])
				return;
			player.SetVar("hmChangeSet", 0);
			var found = 0;
			for (var i = this.chars.length - 1; i >= 0; i--) {
				var pos = i+1;
				if(this.chars[i] == letter) {
					player.SetVar("hml"  + pos, letter);
					found = 1;
					this.foundLetters++;
					this.foundChars[letter] = true;
					if (this.foundLetters >= this.chars.length) {
						player.SetVar("hmAnswerFound", 1);
					}	
				}
			}
			if( found != 1) {
				//cant put ! in the stroyline var
				if (letter == "!")
					letter = "Ex";

				var isPressed = player.GetVar("hmChange"+letter);
				if( isPressed == 0) {
				var tleft = player.GetVar("hmtleft");
				tleft = tleft -1;
				player.SetVar("hmtleft", tleft);
				player.SetVar("hmChange"+ letter, 1);
				}
			}
		 

			return;
		}
	};
	window.hangman.init();
})();

/*
 *
 * END OF HANGMAN GAME
 *
 */


}

function Script26()
{
  var seconds=3000;
// display();
var blinkTimer = setTimeout(display,400);
var flag = 0;
 
function display(){
	seconds=seconds-1;
	var player = GetPlayer();
	var tleft = player.GetVar("hmtleft");
	player.SetVar("hmtimer",seconds);
	if( tleft != 9) {
		if(flag == 0) {
			player.SetVar("hmBlink","hide");
			flag = 1;
		}
		else {
		player.SetVar("hmBlink","show");
		flag = 0;
		}
		var blinkTimer = setTimeout(display,400);
	}
	else 
	player.SetVar("hmBlink","show");
}
 
}

function Script27()
{
  window.hangman.setupQuestions(1);
}

function Script28()
{
  window.hangman.letterPressed("B");
}

function Script29()
{
  window.hangman.letterPressed("C");
}

function Script30()
{
  window.hangman.letterPressed("D");
}

function Script31()
{
  window.hangman.letterPressed("E");
}

function Script32()
{
  window.hangman.letterPressed("F");
}

function Script33()
{
  window.hangman.letterPressed("G");
}

function Script34()
{
  window.hangman.letterPressed("H");
}

function Script35()
{
  window.hangman.letterPressed("I");
}

function Script36()
{
  window.hangman.letterPressed("J");
}

function Script37()
{
  window.hangman.letterPressed("K");
}

function Script38()
{
  window.hangman.letterPressed("L");
}

function Script39()
{
  window.hangman.letterPressed("M");
}

function Script40()
{
  window.hangman.letterPressed("N");
}

function Script41()
{
  window.hangman.letterPressed("O");
}

function Script42()
{
  window.hangman.letterPressed("P");
}

function Script43()
{
  window.hangman.letterPressed("Q");
}

function Script44()
{
  window.hangman.letterPressed("R");
}

function Script45()
{
  window.hangman.letterPressed("S");
}

function Script46()
{
  window.hangman.letterPressed("T");
}

function Script47()
{
  window.hangman.letterPressed("U");
}

function Script48()
{
  window.hangman.letterPressed("V");
}

function Script49()
{
  window.hangman.letterPressed("W");
}

function Script50()
{
  window.hangman.letterPressed("X");
}

function Script51()
{
  window.hangman.letterPressed("Y");
}

function Script52()
{
  window.hangman.letterPressed("Z");
}

function Script53()
{
  window.hangman.letterPressed("!");
}

function Script54()
{
  window.hangman.letterPressed("A");
}

function Script55()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script56()
{
    window.summary.question.push('In this study what level of measurement is appropriate for consumption of meat products?');
  window.summary.answer.push('Ratio');
  window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('4', 'Ratio', true, '', 'In this study what level of measurement is appropriate for consumption of meat products?', 1, 0, 'Scene2_Slide9_4');
}

function Script57()
{
    window.summary.question.push('In this study what level of measurement is appropriate for consumption of meat products?');
  window.summary.answer.push('');
  window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('4', '', false, '', 'In this study what level of measurement is appropriate for consumption of meat products?', 1, 0, 'Scene2_Slide9_4');
}

function Script58()
{
  var seconds=4;
//setTimeout(display,1000);
display();
 
function display(){
seconds=seconds-1;
var player = GetPlayer();
player.SetVar("hmcready",seconds);
var cready = player.GetVar("hmcready");
if ( cready == 0) {
player.SetVar("hmcready", "Go!");
setTimeout(display,1000);
}
else if ( cready == -1) {
player.SetVar("hmcready", "next");
}
else {
setTimeout(display,1000);
}
}
}

function Script59()
{
  window.hangman.setupQuestions(1);
var seconds=4;
//setTimeout(display,1000);
display();
 
function display(){
seconds=seconds-1;
var player = GetPlayer();
player.SetVar("hmcready",seconds);
var cready = player.GetVar("hmcready");
if ( cready == 0) {
player.SetVar("hmcready", "Go!");
setTimeout(display,1000);
}
else if ( cready == -1) {
player.SetVar("hmcready", "next");
setTimeout(display,1000);
}
else {
setTimeout(display,1000);
}
}
}

function Script60()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script61()
{
  var player = GetPlayer();  
var answer = player.GetVar('answer');
window.summary.question.push('Mikä mitta-asteikko tässä tutkimuksessa sopii sukupuolelle? ');
window.summary.answer.push(answer);
window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('5', answer, true, '', 'Mikä mitta-asteikko tässä tutkimuksessa sopii sukupuolelle?', 1, 0, 'Scene2_Slide11_1');
}

function Script62()
{
  var player = GetPlayer();  
var answer = player.GetVar('answer');
window.summary.question.push('Mikä mitta-asteikko tässä tutkimuksessa sopii sukupuolelle? ');
window.summary.answer.push(answer);
window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('5', answer, false, '', 'Mikä mitta-asteikko tässä tutkimuksessa sopii sukupuolelle?', 1, 0, 'Scene2_Slide11_1');
}

function Script63()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script64()
{
    window.summary.question.push('Mitä tutkimusasetelmaa tässä tutkimuksessa käytetään?');
  window.summary.answer.push('eroja ryhmien välillä');
  window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('6', 'eroja ryhmien välillä', true, '', 'Mitä tutkimusasetelmaa tässä tutkimuksessa käytetään?', 1, 0, 'Scene2_Slide11_2');
}

function Script65()
{
    window.summary.question.push('Mitä tutkimusasetelmaa tässä tutkimuksessa käytetään?');
  window.summary.answer.push('muuttujien välistä yhteyttä');
  window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('6', 'muuttujien välistä yhteyttä', true, '', 'Mitä tutkimusasetelmaa tässä tutkimuksessa käytetään?', 1, 0, 'Scene2_Slide11_2');
}

function Script66()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script67()
{
    window.summary.question.push('Kumpi alla olevasta aineistosta sopii testaamaan hypoteesiasi?');
  window.summary.answer.push('Dataset1');
  window.summary.correct.push('Correct');


lmsAPI.RecordFillInInteraction('10', 'Dataset1', true, '', 'Kumpi alla olevasta aineistosta sopii testaamaan hypoteesiasi? ', 1, 0, 'Scene2_Slide12');
}

function Script68()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script69()
{
    window.summary.question.push('Kumpi alla olevasta aineistosta sopii testaamaan hypoteesiasi?');
  window.summary.answer.push('Dataset2');
  window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('10', 'Dataset2', true, '', 'Kumpi alla olevasta aineistosta sopii testaamaan hypoteesiasi? ', 1, 0, 'Scene2_Slide12');
}

function Script70()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script71()
{
  window.summary.question.push('Mikä graafinen esitys sopii mielestäsi parhaiten tähän aineistoon?');
window.summary.answer.push('Histogrammi');
window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('11', 'Histogrammi', true, '', 'Mikä graafinen esitys sopii mielestäsi parhaiten tähän aineistoon? ', 1, 0, 'Scene2_Slide13');
}

function Script72()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script73()
{
  window.summary.question.push('Mikä graafinen esitys sopii mielestäsi parhaiten tähän aineistoon?');
window.summary.answer.push('Laatikko-viikset');
window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('11', 'Laatikko-viikset', true, '', 'Mikä graafinen esitys sopii mielestäsi parhaiten tähän aineistoon? ', 1, 0, 'Scene2_Slide13');
}

function Script74()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script75()
{
  window.summary.question.push('Mikä graafinen esitys sopii mielestäsi parhaiten tähän aineistoon?');
window.summary.answer.push('Sirontakuvio');
window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('11', 'Sirontakuvio', false, '', 'Mikä graafinen esitys sopii mielestäsi parhaiten tähän aineistoon? ', 1, 0, 'Scene2_Slide13');
}

function Script76()
{
  window.summary.question.push('Mikä graafinen esitys sopii mielestäsi parhaiten tähän aineistoon?');
window.summary.answer.push('Scatter Diagrams');
window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('11', 'Scatter Diagrams', false, '', 'Mikä graafinen esitys sopii mielestäsi parhaiten tähän aineistoon? ', 1, 0, 'Scene2_Slide13');
}

function Script77()
{
  
/*
 *
 * TIC-TAC-TOE GAME
 *
 */

/*global GetPlayer:false */
var player = GetPlayer();
(function() {
	'use strict';
	var state = {
		READY: 0,
		RIGHT: 1,
		WRONG: 2
	};
	var validValues = [
		// Rows
		1  | 2   | 4,
		8  | 16  | 32,
		64 | 128 | 256,
		// Columns
		1  | 8   | 64,
		2  | 16  | 128,
		4  | 32  | 256
	];
	window.ttt = {
		questions: [
			{
				text: "Histogrammi osoittaa, että pojat käyttivät enemmän erilaisia lihatuotteita kuin mitä tytöt.",
				wrong: "Totta, histogrammi osoittaa että pojat käyttivät enemmän erilaisia lihatuotteita kuin mitä tytöt.",
				answer: true
			},
			{
				text: "Histogrammi osoittaa, että useat pojat ja tytöt eivät käyttäneet lainkaan lihatuotteita.",
				wrong: "Totta, histogrammi osoittaa että useat pojat ja tytöt eivät käyttäneet lainkaan lihatuotteita.",
				answer: true
			},
			{
				text: "Kuvaaja B osoittaa saman data-asettelun kuin histogrammi.",
				wrong: "Väärin, kuvaaja B ei näytä samaa merkittävää vaihtelua poikien osalta kuin mitä histogrammissa nähdään, eikä osoita samaa data-asettelua kuin histogrammi.",
				answer: false
			},
			{
				text: "Kuvaaja A osoittaa, että poikien ja tyttöjen lihatuotteiden kulutuksen mediaani on yhtenevä. ",
				wrong: "Totta, kuvaaja osoittaa, että poikien ja tyttöjen lihatuotteiden kulutuksen mediaani on yhtenevä. ",
				answer: true
			},
			{
				text: "Kuvaaja A osoittaa, että tytöt käyttivät enemmän erilaisia lihatuotteita kuin pojat.",
				wrong: "Väärin, kuvaaja A osoittaa, että pojat käyttivät enemmän erilaisia lihatuotteita kuin tytöt.",
				answer: false
			},
			{
				text: "Tulostaulukko osoittaa, että pojat käyttivät keskimääri 7.386 lihatuotetta viikossa.",
				wrong: "Väärin, 7.386 tarkoittaa keskihajontaa poikien lihatuotteiden käytössä per viikko.",
				answer: false
			},
			{
				text: "Tulostaulukon keskiarvot osoittavat, että pojat käyttivät viikottain enemmän lihatuotteita kuin tytöt.",
				wrong: "Totta, tulostaulukon keskiarvot osoittavat, että pojat käyttivät viikottain (11.97) enemmän lihatuotteita kuin tytöt (10.5).",
				answer: true
			},
			{
				text: "Tulostaulukossa näkyvä arvomerkitys osoittaa, että poikien ja tyttöjen lihatuotteiden käytön määrän keskiarvossa on merkittävä ero.",
				wrong: "Väärin, tulostaulukossa näkyvä arvomerkitys (p=.065) osoittaa, että poikien ja tyttöjen lihatuotteiden käytön määrän keskiarvossa ei ole merkittävää eroa.",
				answer: false
			},
			{
				text: "Arvomerkitys osoittaa, että meidän tulee hylätä nollahypoteesi.",
				wrong: "Väärin, arvomerkitys osoittaa, että meidän ei tule hylätä nollahypoteesia.",
				answer: false
			}
		],
		activeQuestion: -1,
		totalValue: 0,
		init: function()
		{
			if (this.questions.length !== 9) {
				alert("Question count missmatch! Got " + this.questions.length + " expected 9");
				return;
			}
			var value = 1;
			// Setup the Qs with redundant info

var length = this.questions.length,
element = null;
for (var i = 0; i < length; i++) {
element = this.questions[i];
element .id = i;
element .value = value;
element .state = state.READY;
value *= 2;
}
		},
		updateQState: function(question, state)
		{
			question.state = state;
			player.SetVar('tttQuestionState' + question.id, state);
		},
		/*
		 * Functions to be called from Storyline
		 */
		// Resets all the question vars to ready
		setupQuestions: function()
		{
			this.activeQuestion = null;
			this.totalValue = 0;
			player.SetVar('tttQuestionText', '');
			player.SetVar('tttSlideSolved', 0);
var length = this.questions.length,
element = null;
for (var i = 0; i < length; i++) {
element = this.questions[i];
this.updateQState(element , state.READY);
}

		},
		// For when the user picks a question
		chooseQuestion: function(quid)
		{
			var question = this.questions[quid];
			if (question.state !== state.READY)
				return;
			this.activeQuestion = question;
			player.SetVar('tttQuestionText', question.text);
		},
		// Check if the answer is correctus
		checkAnswer: function(choice)
		{
			// Get what we're talkin about
			var question = this.activeQuestion;
			// Hide the question window
var questionText = player.GetVar('tttQuestionText');
			player.SetVar('tttQuestionText', '');
			// Reset the wrong var so we can trigger it if necessary
			player.SetVar('tttQuestionWrong', '');
			// Determine failure
			var choice_ = (choice == 'true') ? true : false;
			// If you pass you're wrong and stupid
			if (choice === 'pass' || choice_ !== question.answer) {
				this.updateQState(question, state.WRONG);
				// Pop up the "no u stupid" box
				player.SetVar('tttQuestionWrong', question.wrong);

window.summary.question.push(questionText);
window.summary.answer.push(choice_);
window.summary.correct.push('Incorrect');

				return;
			}
			// success!
window.summary.question.push(questionText);
window.summary.answer.push(question.answer);
window.summary.correct.push('Correct');
			this.updateQState(question, state.RIGHT);
			this.totalValue |= question.value;
			// Check if we've won
var length = validValues.length,
value = null;
for (var i = 0; i < length; i++) {
value = validValues[i];
if  ( (this.totalValue & value) === value )
player.SetVar('tttSlideSolved', 1);
}
		}
	};
	window.ttt.init();
})();

/*
 *
 * END OF TIC-TAC-TOE GAME
 *
 */


}

function Script78()
{
  window.ttt.setupQuestions();
}

function Script79()
{
  window.ttt.setupQuestions();
}

function Script80()
{
  window.ttt.chooseQuestion(0);
}

function Script81()
{
  window.ttt.chooseQuestion(1);
}

function Script82()
{
  window.ttt.chooseQuestion(2);
}

function Script83()
{
  window.ttt.chooseQuestion(3);
}

function Script84()
{
  window.ttt.chooseQuestion(4);
}

function Script85()
{
  window.ttt.chooseQuestion(5);
}

function Script86()
{
  window.ttt.chooseQuestion(6);
}

function Script87()
{
  window.ttt.chooseQuestion(7);
}

function Script88()
{
  window.ttt.chooseQuestion(8);
}

function Script89()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}

lmsAPI.RecordFillInInteraction('12', 'Completed', true, '', 'Microscope Game ', 1, 0, 'Scene2_Slide15');








}

function Script90()
{
  lmsAPI.RecordFillInInteraction('12', '', false, '', 'Microscope Game ', 1, 0, 'Scene2_Slide15');
}

function Script91()
{
  var eyesshut = 100, eyesopen = 10000, inblink = false;
var player = GetPlayer();
function blink(){
  inblink = !inblink;
  if (inblink) {
    player.SetVar('blinkState', 'hide');
    setTimeout(blink, eyesshut + Math.random() * 40);
  } else {
    player.SetVar('blinkState', 'show');
    setTimeout(blink, eyesopen + Math.random() * 500);
  }
}

blink(); 
}

function Script92()
{
  window.ttt.checkAnswer('true');
}

function Script93()
{
  window.ttt.checkAnswer('false');
}

function Script94()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script95()
{
  window.summary.question.push('Mikä tilastollinen testi sopii hypoteesin Poikien ja tyttöjen välillä ei ole merkitsevää eroa lihatuotteiden kulutuksen määrässä testaamiseen?');
window.summary.answer.push('riippumattomien otosten t-testi');
window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('13', 'riippumattomien otosten t-testi', true, '', 'Mikä tilastollinen testi sopii hypoteesin Poikien ja tyttöjen välillä ei ole merkitsevää eroa lihatuotteiden kulutuksen määrässä testaamiseen? ', 1, 0, 'Scene2_Slide14_1');
}

function Script96()
{
  window.summary.question.push('Mikä tilastollinen testi sopii hypoteesin Poikien ja tyttöjen välillä ei ole merkitsevää eroa lihatuotteiden kulutuksen määrässä testaamiseen?');
window.summary.answer.push('Toistettujen mittausten t-testi ');
window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('13', 'Toistettujen mittausten t-testi', false, '', 'Mikä tilastollinen testi sopii hypoteesin Poikien ja tyttöjen välillä ei ole merkitsevää eroa lihatuotteiden kulutuksen määrässä testaamiseen? ', 1, 0, 'Scene2_Slide14_1');
}

function Script97()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script98()
{
  window.summary.question.push('Taulukon tulkinta');
window.summary.answer.push('Taulukko osoittaa, että pojat kuluttavat keskimäärin 11.97 lihatuotetta viikossa');
window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('14', 'Taulukko osoittaa, että pojat kuluttavat keskimäärin 11.97 lihatuotetta viikossa', true, '', 'Taulukon tulkinta ', 1, 0, 'Scene2_Slide14_2');
}

function Script99()
{
  window.summary.question.push('Taulukon tulkinta');
window.summary.answer.push('Taulukko osoittaa, että pojat kuluttavat keskimäärin 7.386 lihatuotetta viikossa.');
window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('15', 'Taulukko osoittaa, että pojat kuluttavat keskimäärin 7.386 lihatuotetta viikossa.', false, '', 'Taulukon tulkinta ', 1, 0, 'Scene2_Slide14_2');
}

function Script100()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}

var time = player.GetVar('time');
//Bronze Gold Silver
if( time <= 15000 && time > 12000 ) {
player.SetVar("achQuestionBronze",1);
}
if( time>= 10000 &&  time <= 12000) {
player.SetVar("achQuestionBronze",0);
player.SetVar("achQuestionSilver",1);
}
if( time < 10000 ) {
player.SetVar("achQuestionSilver",0);
player.SetVar("achQuestionGold",1);
}
}

function Script101()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script102()
{
  window.summary.question.push('Taulukon tulkinta');
window.summary.answer.push('Taulukko osoittaa, että pojat kuluttivat enemmän lihatuotteita viikossa kuin tytöt, mutta ero ei ollut tilastollisesti merkitsevää. ');
window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('16', 'Taulukko osoittaa, että pojat kuluttivat enemmän lihatuotteita viikossa kuin tytöt, mutta ero ei ollut tilastollisesti merkitsevää.', true, '', 'Taulukon tulkinta ', 1, 0, 'Scene2_Slide14_3');
}

function Script103()
{
  var player = GetPlayer();
var time = player.GetVar('time');
//Bronze Gold Silver
if( time <= 15000 && time > 12000 ) {
player.SetVar("achQuestionBronze",1);
}
if( time>= 10000 &&  time <= 12000) {
player.SetVar("achQuestionBronze",0);
player.SetVar("achQuestionSilver",1);
}
if( time < 10000 ) {
player.SetVar("achQuestionSilver",0);
player.SetVar("achQuestionGold",1);
}

window.achievements.advanceAchievement(4);
window.achievements.doEverythingAtOnce();
}

function Script104()
{
  window.summary.question.push('Taulukon tulkinta');
window.summary.answer.push('Taulukko osoittaa, että pojat kuluttivat merkitsevästi enemmän lihatuotteita viikossa kuin tytöt.');
window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('16', 'Taulukko osoittaa, että pojat kuluttivat merkitsevästi enemmän lihatuotteita viikossa kuin tytöt.', false, '', 'Taulukon tulkinta ', 1, 0, 'Scene2_Slide14_3');
}

