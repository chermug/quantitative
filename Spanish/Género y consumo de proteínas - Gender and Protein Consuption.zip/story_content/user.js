function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6hTby9dF0Gj":
        Script1();
        break;
      case "6FnwiMPKAnc":
        Script2();
        break;
      case "6AiEGtNw3HX":
        Script3();
        break;
      case "6jXk4VJU2Fg":
        Script4();
        break;
      case "5pdhMcbpMTb":
        Script5();
        break;
      case "6llhtnGhZxc":
        Script6();
        break;
      case "5vlu7KazxZE":
        Script7();
        break;
      case "5clJsFyIQic":
        Script8();
        break;
      case "5ctVgZeJyJC":
        Script9();
        break;
      case "6kjVA9nuL4O":
        Script10();
        break;
      case "6FDsUFwRp1O":
        Script11();
        break;
      case "6U58cLP8zon":
        Script12();
        break;
      case "6iqGqSWdfRm":
        Script13();
        break;
      case "5e4ez80qyiV":
        Script14();
        break;
      case "60eTzIRNCEF":
        Script15();
        break;
      case "5sKmlh9OGKl":
        Script16();
        break;
      case "6iJ5nxBhzZu":
        Script17();
        break;
      case "60y1OKXvFr2":
        Script18();
        break;
      case "6gMgT2Acxmc":
        Script19();
        break;
      case "5UvFttMUgRL":
        Script20();
        break;
      case "5kXRCQzkZVm":
        Script21();
        break;
      case "5YufPejLCf2":
        Script22();
        break;
      case "5YUMgS1DcGf":
        Script23();
        break;
      case "6oqRN7bVAae":
        Script24();
        break;
      case "6onax3Ika05":
        Script25();
        break;
      case "6EQoS6kDrWG":
        Script26();
        break;
      case "5fPGI9oe5no":
        Script27();
        break;
      case "6DRdVpLlGOh":
        Script28();
        break;
      case "6OWSwEVWoZn":
        Script29();
        break;
      case "5ZHC0cYLNU4":
        Script30();
        break;
      case "6AIFohz60TL":
        Script31();
        break;
      case "6r8YKkuJx56":
        Script32();
        break;
      case "6Hh2ykfOh3D":
        Script33();
        break;
      case "5v5qBSaDJFb":
        Script34();
        break;
      case "5f8ZNkOb8Ls":
        Script35();
        break;
      case "5o6w7qJqHYu":
        Script36();
        break;
      case "5jA5oydGjdp":
        Script37();
        break;
      case "6edozienLUv":
        Script38();
        break;
      case "6KNSmtTB2zm":
        Script39();
        break;
      case "6mc5RbiAeT8":
        Script40();
        break;
      case "65hHmNvv5xp":
        Script41();
        break;
      case "6ILwS7881Zy":
        Script42();
        break;
      case "5W8VnNqnZqJ":
        Script43();
        break;
      case "6OJStfGi0h3":
        Script44();
        break;
      case "63lBVeWwuyD":
        Script45();
        break;
      case "66t0F2nigNB":
        Script46();
        break;
      case "6AeOLVo0vwa":
        Script47();
        break;
      case "65mbfsJJLRM":
        Script48();
        break;
      case "5gTPG7zUOJk":
        Script49();
        break;
      case "65wpxAysdKp":
        Script50();
        break;
      case "6ODO4ICzoPY":
        Script51();
        break;
      case "6JK8Fj4VMf3":
        Script52();
        break;
      case "61qWegjWMw5":
        Script53();
        break;
      case "6oa99CdLn23":
        Script54();
        break;
      case "6cRHamqET0O":
        Script55();
        break;
      case "5rvtxnRxNCu":
        Script56();
        break;
      case "6jqDzqbmhZl":
        Script57();
        break;
      case "665CNU9LDBv":
        Script58();
        break;
      case "6KoQZBywjRK":
        Script59();
        break;
      case "6Dp2ib56EGZ":
        Script60();
        break;
      case "6CqxpTs5gT1":
        Script61();
        break;
      case "5u8EXsE4XDD":
        Script62();
        break;
      case "5oainM7j8Hm":
        Script63();
        break;
      case "5a0sMuw77Ca":
        Script64();
        break;
      case "6Ix8TpHr5yw":
        Script65();
        break;
      case "6g4pBiL1g7C":
        Script66();
        break;
      case "5YtvWDpX8Jt":
        Script67();
        break;
      case "5dZ6d6ecGq0":
        Script68();
        break;
      case "6H3MtozyqAw":
        Script69();
        break;
      case "68NDWyRcvJu":
        Script70();
        break;
      case "6MdeNLTPhyy":
        Script71();
        break;
      case "6E7xGtspZtF":
        Script72();
        break;
      case "5kMX4oOv3Ae":
        Script73();
        break;
      case "5tYPRikISCb":
        Script74();
        break;
      case "5tyWTgViFWw":
        Script75();
        break;
      case "6VJYwYfPwuz":
        Script76();
        break;
      case "5f2Rojgue33":
        Script77();
        break;
      case "6gfzQmOl84F":
        Script78();
        break;
      case "6DjAXCbuwyh":
        Script79();
        break;
      case "6ZoX98cpbw0":
        Script80();
        break;
      case "5aHRYIKRU53":
        Script81();
        break;
      case "5fOrHHHiswz":
        Script82();
        break;
      case "5jpVVfDhRQ1":
        Script83();
        break;
      case "5h8ZHAmZxkU":
        Script84();
        break;
      case "6WZBUXR3RM0":
        Script85();
        break;
      case "6AFxtdfKQPO":
        Script86();
        break;
      case "5ooR5eBvwIv":
        Script87();
        break;
      case "6hxzH5xr0Sr":
        Script88();
        break;
      case "6Nb0scH2e3X":
        Script89();
        break;
      case "5c7tmfflZBX":
        Script90();
        break;
      case "5r3HIeQDDbI":
        Script91();
        break;
      case "5uPjAmVI3Ir":
        Script92();
        break;
      case "6diSrmYXcnr":
        Script93();
        break;
      case "6SnusBOtQMC":
        Script94();
        break;
      case "5iMlCkP1yJD":
        Script95();
        break;
      case "6gZd0x0Ofab":
        Script96();
        break;
      case "6oJgXZthsJa":
        Script97();
        break;
      case "698yhsXqGhi":
        Script98();
        break;
      case "62CtVzSi1Rb":
        Script99();
        break;
      case "6TgB2a49yLR":
        Script100();
        break;
      case "6JWKnPXgd16":
        Script101();
        break;
      case "6MKgtQMMZ73":
        Script102();
        break;
      case "6U2dZ0acAk4":
        Script103();
        break;
      case "6h4S5xwAtGY":
        Script104();
        break;
  }
}

function Script1()
{
  
/*
 *
 *   ACHIEVEMENTS
 *
 */

/*global GetPlayer:false */
var player = GetPlayer();
(function() {
	'use strict';
	window.achievements = {
		achievements: [
			{
				name: "First Question",
				desc: "You have successfully answered first question correctly.",
				advance: function()
				{
					this.completed = true;
				}
			},
			{
				name: "Three in a row",
				desc: "You have successfully answered three questions correctly in a row.",
				rowCounter: 0,
				advance: function()
				{
					var rowCounter = player.GetVar('ach3Question');
					if (rowCounter  == 3)
						this.completed = true;
				}
			},
			{
				name: "Hypothesis",
				desc: "You have successfully answered all hypothesis questions without any wrong answer.",
				rowCounter: 0,
				advance: function()
				{
					var isHypothesis = player.GetVar('achHypothesis');
					console.log(isHypothesis);
					if (isHypothesis  == 1)
						this.completed = true;
				}
			},
			{
				name: "All",
				desc: "You have successfully answered all of the questions correct.",
				rowCounter: 0,
				advance: function()
				{
					var isAll = player.GetVar('achAll');
					console.log(isAll);
					if (isAll  == 1)
						this.completed = true;
				}
			},
			{
				name: "",
				desc: "",
				rowCounter: 0,
				advance: function()
				{
					//In each case it will earn something
					this.completed = true;
				}
			},

		],
		completedThisRound: [],

		init: function()
		{
			for (var i = 0; i < this.achievements.length; ++i) {
				this.achievements[i].id = i;
			}
		},
		// public
		advanceAchievement: function(achid)
		{
			var ach = this.achievements[achid];
			if (!ach)
				return;
			if (ach.completed)
				return;
			ach.advance();
			if (!ach.completed)
				return;
			this.completedThisRound.push(ach);
		},
		checkForAchievements: function()
		{
			return this.completedThisRound.length > 0;
		},
		resetAchievementVars: function()
		{
			player.SetVar('achievementActive', 0);
			player.SetVar('achievementName', '');
			player.SetVar('achievementDesc', '');
			player.SetVar('achivementId', -1);
		},
		setupAchievementVars: function()
		{
			var ach = this.completedThisRound.shift();
			player.SetVar('achievementActive', 1);
			player.SetVar('achievementName', ach.name);
			player.SetVar('achievementDesc', ach.desc);
			player.SetVar('achivementId', ach.id);
			player.SetVar('achievementUnlocked' + ach.id, 1);
		},
		// public
		doEverythingAtOnce: function()
		{
			this.resetAchievementVars();
			if (this.checkForAchievements())
				this.setupAchievementVars();

		}
	};
	window.achievements.init();
})();

/*
 *
 *  END OF ACHIEVEMENTS 
 *
 */

}

function Script2()
{
  var eyesshut = 100, eyesopen = 10000, inblink = false;
var player = GetPlayer();
var isPopUp = player.GetVar("isPopUp");
function blink(){
  inblink = !inblink;
 if (isPopUp == 1) {
 setTimeout(blink, 100);
}
  else if (inblink) {
    player.SetVar('blinkState', 'hide');
    setTimeout(blink, eyesshut + Math.random() * 100);
  } else {
    player.SetVar('blinkState', 'show');
    setTimeout(blink, eyesopen + Math.random() * 1000);
  }
}

blink(); 

window.summary = {question: [], answer: [], correct: []}; 
}

function Script3()
{
  var player = GetPlayer();
player.SetVar("answerM1", "");
player.SetVar("answerM2", "");
player.SetVar("answerM3", "");
player.SetVar("answerM4", "");
player.SetVar("answerM5", "");
player.SetVar("answerM6", "");
}

function Script4()
{
   window.summary.question.push('Formulate the null-hypothesis by selecting the correct sentence parts - Part1');
  window.summary.answer.push('Habrá diferencia');
  window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('7', 'Habrá diferencia', false, '', 'Null-hypothesis Part 1 ', 1, 0, 'Scene2_Slide5_1');
}

function Script5()
{
  var player = GetPlayer();
var answer1 = player.GetVar("answerM4");
var answer2 = player.GetVar("answerM3");

 window.summary.question.push('Formulate the null-hypothesis by selecting the correct sentence parts - Part2');
  window.summary.answer.push(answer1 + answer2);
  window.summary.correct.push('Incorrect');

var answer = answer1 + answer2;

lmsAPI.RecordFillInInteraction('8', answer, false, '', 'Null-hypothesis Part 2', 1, 0, 'Scene2_Slide5_2');
}

function Script6()
{
  var player = GetPlayer();
var answer1 = player.GetVar("answerM5");
var answer2 = player.GetVar("answerM6");

 window.summary.question.push('Formulate the null-hypothesis by selecting the correct sentence parts - Part3');
  window.summary.answer.push(answer1 + answer2);
  window.summary.correct.push('Incorrect');

var answer = answer1 + answer2;

lmsAPI.RecordFillInInteraction('9', answer, false, '', 'Null-hypothesis Part 3', 1, 0, 'Scene2_Slide5_3');
}

function Script7()
{
    window.summary.question.push('Formulate the null-hypothesis by selecting the correct sentence parts - Part1');
  window.summary.answer.push('No habrá diferencia');
  window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('7', 'No habrá diferencia', true, '', 'Null-hypothesis Part 1 ', 1, 0, 'Scene2_Slide5_1');
}

function Script8()
{
    window.summary.question.push('Formulate the null-hypothesis by selecting the correct sentence parts - Part2');
  window.summary.answer.push('entre niños y niñas');
  window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('8', 'entre niños y niñas', true, '', 'Null-hypothesis Part 2', 1, 0, 'Scene2_Slide5_2');
}

function Script9()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script10()
{
    window.summary.question.push('Formulate the null-hypothesis by selecting the correct sentence parts - Part3');
  window.summary.answer.push('en el número de productos cárnicos consumidos');
  window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('9', 'en el número de productos cárnicos consumidos', true, '', 'Null-hypothesis Part 3', 1, 0, 'Scene2_Slide5_3');
}

function Script11()
{
  var player = GetPlayer();
var score = player.GetVar('score');
var rank;
window.clearTimeout(timeVar);

//Score
if( score >= 1500 )
 rank = "A";
else if( score >= 1400 )
 rank = "B";
else if( score >= 1300 )
 rank = "C";
else if( score >= 1200 )
 rank = "D";
else 
 rank = "E";

player.SetVar('rank', rank);

//Time
function zeroPad(num, places) {
  var zero = places - num.toString().length + 1;
  return Array(+(zero > 0 && zero)).join("0") + num;
}

var time = player.GetVar('time');

var minutes = Math.floor(time / 60);
var seconds = time - minutes * 60;

minutes  = zeroPad(minutes, 2);
seconds  = zeroPad(seconds, 2);

var NewTime = minutes+":"+seconds;
player.SetVar('timeLast', NewTime );

player.SetVar("answerM1", "");
player.SetVar("answerM2", "");
player.SetVar("answerM3", "");
player.SetVar("answerM4", "");
player.SetVar("answerM5", "");
player.SetVar("answerM6", "");

lmsAPI.RecordFillInInteraction('17', score, true, '', 'Score ', 1, 0, 'Scene2_Slide8');
lmsAPI.RecordFillInInteraction('18', NewTime, true, '', 'Playing Time ', 1, 0, 'Scene2_Slide8');

lmsAPI.SetPassed();
player = GetPlayer();
var correct = player.GetVar("correctcounter");
var question = player.GetVar("questioncounter");

var score = ( correct / question ) * 100;
score =  Math.round( Number(score));
player.SetVar("calculatedscore", score);
player.SetVar("calculatedcorrect",correct);
player.SetVar("calculatedquestion",question);

lmsAPI.SetScore(score,100,0);

lmsAPI.RecordFillInInteraction('19', playerName, true, '', 'Player Name ', 1, 0, 'Scene2_Slide8');

lmsAPI.RecordFillInInteraction('20', rank, true, '', 'Rank ', 1, 0, 'Scene2_Slide8');

}

function Script12()
{
  var answersum = "";

if ( player.GetVar('answerM1') !== "")
   answersum +=  player.GetVar('answerM1') + ", ";
if ( player.GetVar('answerM2') !== "")
   answersum +=  player.GetVar('answerM2') + ", ";
if ( player.GetVar('answerM3') !== "")
   answersum +=  player.GetVar('answerM3') + ", ";
if ( player.GetVar('answerM4') !== "")
   answersum +=  player.GetVar('answerM4') + ", ";

lmsAPI.RecordFillInInteraction('21', answersum, true, '', 'Achievements ', 1, 0, 'Scene2_Slide8');
}

function Script13()
{
  var player = GetPlayer();
var formHTML = "<style>table {border-collapse:collapse;margin-top:20px;color:#373737} table, tr, td {padding: 10px;}tr:nth-child(even) {background:#E3F3EF; }tr:nth-child(odd) {background:#C7F1E6; }tr.header{background:#008A6E;color:white;font-weight:bold; }.logo { margin-bottom:10px;} .name {text-transform:uppercase;font-size:24px;font-weight:bold;color:#008A6E;}.label {font-weight:bold;}.logo span {font-size:27px; font-weight: bold; text-decoration:underline; color:#373737 } .logo img {float:right;}</style>";

var answersum = "";

if ( player.GetVar('answerM1') !== "")
   answersum +=  player.GetVar('answerM1') + ", ";
if ( player.GetVar('answerM2') !== "")
   answersum +=  player.GetVar('answerM2') + ", ";
if ( player.GetVar('answerM3') !== "")
   answersum +=  player.GetVar('answerM3') + ", ";
if ( player.GetVar('answerM4') !== "")
   answersum +=  player.GetVar('answerM4') + ", ";

formHTML += "<div class='logo'><span>Gender and Protein Consumption</span><img src='http://www.playgen.com/chermug/chermug_logo.jpg'></div>";
formHTML += "<span class='name'>" +  player.GetVar('playerName')+ "</span><br/>";
formHTML += "<span class='label'>Score:</span> " + player.GetVar('score') + "<br/>";
formHTML += "<span class='label'>Rank:</span> " + player.GetVar('rank') + "<br/>";
formHTML += "<span class='label'>Time:</span> " + player.GetVar('timeLast') + "<br/>";
formHTML += "<span class='label'>Achievements:</span> " + answersum + "<br/>";

formHTML += "<table><tr class='header'><td>ID</td><td>Question</td><td>Answered</td><td>Correct/Incorrect</td></tr>";

var length = window.summary.question.length;
var question = null;
var answer = null;
var correct = null;

for (var i = 0; i < length; i++) {
question = window.summary.question[i];
answer = window.summary.answer[i];
correct = window.summary.correct[i];
id = i + 1;

formHTML += "<tr><td>" + id + "</td><td>" + question + "</td><td>" + answer + "</td><td>" + correct + "</td></tr>";

}

formHTML += "</table>";

formHTML += "<script>window.print();</script>";

var preview = window.open("about:blank");
preview.document.open();
preview.document.write(formHTML);
preview.document.close();
preview.print();
}

function Script14()
{
  var seconds=0;
timeVar = setTimeout(startTime,1000);

 
function startTime(){
seconds=seconds+1;
var player = GetPlayer();
player.SetVar("time",seconds);
timeVar = setTimeout(startTime,1000);
}
 
}

function Script15()
{
  var player = GetPlayer();
var answer1 = player.GetVar("answerM1");
var answer2 = player.GetVar("answerM2");
var answer3 = player.GetVar("answerM3");
var answer4 = player.GetVar("answerM4");
var answer5 = player.GetVar("answerM5");
var answer6 = player.GetVar("answerM6");

var answersum = "";

if ( answer1 !== "")
   answersum += answer1 + ", ";
if ( answer2 !== "")
   answersum += answer2 + ", ";
if ( answer3 !== "")
   answersum += answer3 + ", ";
if ( answer4 !== "")
   answersum += answer4 + ", ";
if ( answer5 !== "")
   answersum += answer5 + ", ";
if ( answer6 !== "")
   answersum += answer6 + ", ";


 window.summary.question.push('En el estudio, ¿cuáles son las variables?');
  window.summary.answer.push(answersum);
  window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('1', answersum, false, '', 'En el estudio, ¿cuáles son las variables?', 1, 0, 'Scene2_Slide9_1');
}

function Script16()
{
  window.achievements.advanceAchievement(0);
window.achievements.doEverythingAtOnce();
}

function Script17()
{
  var player = GetPlayer();
var answer1 = player.GetVar("answerM1");
var answer2 = player.GetVar("answerM2");
var answer3 = player.GetVar("answerM3");
var answer4 = player.GetVar("answerM4");
var answer5 = player.GetVar("answerM5");
var answer6 = player.GetVar("answerM6");

var answersum = "";

if ( answer1 !== "")
   answersum += answer1 + ", ";
if ( answer2 !== "")
   answersum += answer2 + ", ";
if ( answer3 !== "")
   answersum += answer3 + ", ";
if ( answer4 !== "")
   answersum += answer4 + ", ";
if ( answer5 !== "")
   answersum += answer5 + ", ";
if ( answer6 !== "")
   answersum += answer6 + ", ";


 window.summary.question.push('En el estudio, ¿cuáles son las variables?');
  window.summary.answer.push(answersum);
  window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('1', answersum, true, '', 'En el estudio, ¿cuáles son las variables?', 1, 0, 'Scene2_Slide9_1');
}

function Script18()
{
  var player = GetPlayer();
player.SetVar("answerM1", "");
player.SetVar("answerM2", "");
player.SetVar("answerM3", "");
player.SetVar("answerM4", "");
player.SetVar("answerM5", "");
player.SetVar("answerM6", "");
}

function Script19()
{
  var player = GetPlayer();
var answer1 = player.GetVar("answerM1");
var answer2 = player.GetVar("answerM2");
var answer3 = player.GetVar("answerM3");
var answer4 = player.GetVar("answerM4");
var answer5 = player.GetVar("answerM5");
var answer6 = player.GetVar("answerM6");

var answersum = "";

if ( answer1 !== "")
   answersum += answer1 + ", ";
if ( answer2 !== "")
   answersum += answer2 + ", ";
if ( answer3 !== "")
   answersum += answer3 + ", ";
if ( answer4 !== "")
   answersum += answer4 + ", ";
if ( answer5 !== "")
   answersum += answer5 + ", ";
if ( answer6 !== "")
   answersum += answer6 + ", ";


 window.summary.question.push('En el mismo estudio, ¿cuál es la variable independiente?');
  window.summary.answer.push(answersum);
  window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('2', answersum, true, '', 'En el mismo estudio, ¿cuál es la variable independiente?', 1, 0, 'Scene2_Slide9_2');
}

function Script20()
{
  var player = GetPlayer();
var answer1 = player.GetVar("answerM1");
var answer2 = player.GetVar("answerM2");
var answer3 = player.GetVar("answerM3");
var answer4 = player.GetVar("answerM4");
var answer5 = player.GetVar("answerM5");
var answer6 = player.GetVar("answerM6");

var answersum = "";

if ( answer1 !== "")
   answersum += answer1 + ", ";
if ( answer2 !== "")
   answersum += answer2 + ", ";
if ( answer3 !== "")
   answersum += answer3 + ", ";
if ( answer4 !== "")
   answersum += answer4 + ", ";
if ( answer5 !== "")
   answersum += answer5 + ", ";
if ( answer6 !== "")
   answersum += answer6 + ", ";


 window.summary.question.push('En el mismo estudio, ¿cuál es la variable independiente?');
  window.summary.answer.push(answersum);
  window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('2', answersum, false, '', 'En el mismo estudio, ¿cuál es la variable independiente?', 1, 0, 'Scene2_Slide9_2');
}

function Script21()
{
  var player = GetPlayer();
player.SetVar("answerM1", "");
player.SetVar("answerM2", "");
player.SetVar("answerM3", "");
player.SetVar("answerM4", "");
player.SetVar("answerM5", "");
player.SetVar("answerM6", "");
}

function Script22()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script23()
{
  var player = GetPlayer();
var answer1 = player.GetVar("answerM1");
var answer2 = player.GetVar("answerM2");
var answer3 = player.GetVar("answerM3");
var answer4 = player.GetVar("answerM4");
var answer5 = player.GetVar("answerM5");
var answer6 = player.GetVar("answerM6");

var answersum = "";

if ( answer1 !== "")
   answersum += answer1 + ", ";
if ( answer2 !== "")
   answersum += answer2 + ", ";
if ( answer3 !== "")
   answersum += answer3 + ", ";
if ( answer4 !== "")
   answersum += answer4 + ", ";
if ( answer5 !== "")
   answersum += answer5 + ", ";
if ( answer6 !== "")
   answersum += answer6 + ", ";


 window.summary.question.push('En el mismo estudio, ¿cuál es la variable dependiente?');
  window.summary.answer.push(answersum);
  window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('3', answersum, true, '', 'En el mismo estudio, ¿cuál es la variable dependiente?', 1, 0, 'Scene2_Slide9_3');
}

function Script24()
{
  var player = GetPlayer();
var answer1 = player.GetVar("answerM1");
var answer2 = player.GetVar("answerM2");
var answer3 = player.GetVar("answerM3");
var answer4 = player.GetVar("answerM4");
var answer5 = player.GetVar("answerM5");
var answer6 = player.GetVar("answerM6");

var answersum = "";

if ( answer1 !== "")
   answersum += answer1 + ", ";
if ( answer2 !== "")
   answersum += answer2 + ", ";
if ( answer3 !== "")
   answersum += answer3 + ", ";
if ( answer4 !== "")
   answersum += answer4 + ", ";
if ( answer5 !== "")
   answersum += answer5 + ", ";
if ( answer6 !== "")
   answersum += answer6 + ", ";


 window.summary.question.push('En el mismo estudio, ¿cuál es la variable dependiente?');
  window.summary.answer.push(answersum);
  window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('3', answersum, false, '', 'En el mismo estudio, ¿cuál es la variable dependiente?', 1, 0, 'Scene2_Slide9_3');
}

function Script25()
{
  
/*
 *
 * HANGMAN GAME
 *
 */

/*global GetPlayer:false */
var player = GetPlayer();
(function() {
	'use strict';
	window.hangman = {
		//Use capital letters
		questions: ["ESCALA"],
		activeQuestion: -1,
		question: '',
		chars: [],
		foundChars: {},
		foundLetters: 0,
		alphabet: ["A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z", "Ex"],
		init: function()
		{
			//console.log("init");

		},
		/*
		 * Functions to be called from Storyline
		 */
		// Setup question and the word into letters
		setupQuestions: function(questionnumber)
		{
			this.foundLetters = 0;
			this.activeQuestion = questionnumber;
			this.question = this.questions[this.activeQuestion-1];
			this.chars = this.question.split('');
			this.foundChars = {};
			for (var i = this.alphabet.length - 1; i >= 0; i--)
				player.SetVar("hmChange"+ this.alphabet[i], 0);


		},
		// Check if any letter or the answer is found
		letterPressed: function(letter)
		{
			if (this.foundChars[letter])
				return;
			player.SetVar("hmChangeSet", 0);
			var found = 0;
			for (var i = this.chars.length - 1; i >= 0; i--) {
				var pos = i+1;
				if(this.chars[i] == letter) {
					player.SetVar("hml"  + pos, letter);
					found = 1;
					this.foundLetters++;
					this.foundChars[letter] = true;
					if (this.foundLetters >= this.chars.length) {
						player.SetVar("hmAnswerFound", 1);
					}	
				}
			}
			if( found != 1) {
				//cant put ! in the stroyline var
				if (letter == "!")
					letter = "Ex";

				var isPressed = player.GetVar("hmChange"+letter);
				if( isPressed == 0) {
				var tleft = player.GetVar("hmtleft");
				tleft = tleft -1;
				player.SetVar("hmtleft", tleft);
				player.SetVar("hmChange"+ letter, 1);
				}
			}
		 

			return;
		}
	};
	window.hangman.init();
})();

/*
 *
 * END OF HANGMAN GAME
 *
 */


}

function Script26()
{
  var seconds=3000;
// display();
var blinkTimer = setTimeout(display,400);
var flag = 0;
 
function display(){
	seconds=seconds-1;
	var player = GetPlayer();
	var tleft = player.GetVar("hmtleft");
	player.SetVar("hmtimer",seconds);
	if( tleft != 9) {
		if(flag == 0) {
			player.SetVar("hmBlink","hide");
			flag = 1;
		}
		else {
		player.SetVar("hmBlink","show");
		flag = 0;
		}
		var blinkTimer = setTimeout(display,400);
	}
	else 
	player.SetVar("hmBlink","show");
}
 
}

function Script27()
{
  window.hangman.setupQuestions(1);
}

function Script28()
{
  window.hangman.letterPressed("B");
}

function Script29()
{
  window.hangman.letterPressed("C");
}

function Script30()
{
  window.hangman.letterPressed("D");
}

function Script31()
{
  window.hangman.letterPressed("E");
}

function Script32()
{
  window.hangman.letterPressed("F");
}

function Script33()
{
  window.hangman.letterPressed("G");
}

function Script34()
{
  window.hangman.letterPressed("H");
}

function Script35()
{
  window.hangman.letterPressed("I");
}

function Script36()
{
  window.hangman.letterPressed("J");
}

function Script37()
{
  window.hangman.letterPressed("K");
}

function Script38()
{
  window.hangman.letterPressed("L");
}

function Script39()
{
  window.hangman.letterPressed("M");
}

function Script40()
{
  window.hangman.letterPressed("N");
}

function Script41()
{
  window.hangman.letterPressed("O");
}

function Script42()
{
  window.hangman.letterPressed("P");
}

function Script43()
{
  window.hangman.letterPressed("Q");
}

function Script44()
{
  window.hangman.letterPressed("R");
}

function Script45()
{
  window.hangman.letterPressed("S");
}

function Script46()
{
  window.hangman.letterPressed("T");
}

function Script47()
{
  window.hangman.letterPressed("U");
}

function Script48()
{
  window.hangman.letterPressed("V");
}

function Script49()
{
  window.hangman.letterPressed("W");
}

function Script50()
{
  window.hangman.letterPressed("X");
}

function Script51()
{
  window.hangman.letterPressed("Y");
}

function Script52()
{
  window.hangman.letterPressed("Z");
}

function Script53()
{
  window.hangman.letterPressed("!");
}

function Script54()
{
  window.hangman.letterPressed("A");
}

function Script55()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script56()
{
    window.summary.question.push('En este estudio, ¿Qué nivel de medición es apropiado para el “consumo de productos cárnicos”?');
  window.summary.answer.push('escala');
  window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('4', 'escala', true, '', 'En este estudio, ¿Qué nivel de medición es apropiado para el “consumo de productos cárnicos”?', 1, 0, 'Scene2_Slide9_4');
}

function Script57()
{
    window.summary.question.push('En este estudio, ¿Qué nivel de medición es apropiado para el “consumo de productos cárnicos”?');
  window.summary.answer.push('');
  window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('4', '', false, '', 'En este estudio, ¿Qué nivel de medición es apropiado para el “consumo de productos cárnicos”?', 1, 0, 'Scene2_Slide9_4');
}

function Script58()
{
  var seconds=4;
//setTimeout(display,1000);
display();
 
function display(){
seconds=seconds-1;
var player = GetPlayer();
player.SetVar("hmcready",seconds);
var cready = player.GetVar("hmcready");
if ( cready == 0) {
player.SetVar("hmcready", "Go!");
setTimeout(display,1000);
}
else if ( cready == -1) {
player.SetVar("hmcready", "next");
}
else {
setTimeout(display,1000);
}
}
}

function Script59()
{
  window.hangman.setupQuestions(1);
var seconds=4;
//setTimeout(display,1000);
display();
 
function display(){
seconds=seconds-1;
var player = GetPlayer();
player.SetVar("hmcready",seconds);
var cready = player.GetVar("hmcready");
if ( cready == 0) {
player.SetVar("hmcready", "Go!");
setTimeout(display,1000);
}
else if ( cready == -1) {
player.SetVar("hmcready", "next");
setTimeout(display,1000);
}
else {
setTimeout(display,1000);
}
}
}

function Script60()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script61()
{
  var player = GetPlayer();  
var answer = player.GetVar('answer');
window.summary.question.push('En este estudio, ¿qué nivel de medición es apropiado para el género?');
window.summary.answer.push(answer);
window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('5', answer, true, '', 'En este estudio, ¿qué nivel de medición es apropiado para el género?', 1, 0, 'Scene2_Slide11_1');
}

function Script62()
{
  var player = GetPlayer();  
var answer = player.GetVar('answer');
window.summary.question.push('En este estudio, ¿qué nivel de medición es apropiado para el género?');
window.summary.answer.push(answer);
window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('5', answer, false, '', 'En este estudio, ¿qué nivel de medición es apropiado para el género?', 1, 0, 'Scene2_Slide11_1');
}

function Script63()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script64()
{
    window.summary.question.push('¿Qué tipo de diseño sugiere este estudio?');
  window.summary.answer.push('diferencias entre grupos');
  window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('6', 'diferencias entre grupos', true, '', '¿Qué tipo de diseño sugiere este estudio?', 1, 0, 'Scene2_Slide11_2');
}

function Script65()
{
    window.summary.question.push('¿Qué tipo de diseño sugiere este estudio?');
  window.summary.answer.push('asociación entre variables.');
  window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('6', 'asociación entre variables.', true, '', '¿Qué tipo de diseño sugiere este estudio?', 1, 0, 'Scene2_Slide11_2');
}

function Script66()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script67()
{
    window.summary.question.push('¿Cuál de los conjuntos de datos sin procesar es el correcto para este estudio?');
  window.summary.answer.push('Dataset1');
  window.summary.correct.push('Correct');


lmsAPI.RecordFillInInteraction('10', 'Dataset1', true, '', '¿Cuál de los conjuntos de datos sin procesar es el correcto para este estudio? ', 1, 0, 'Scene2_Slide12');
}

function Script68()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script69()
{
    window.summary.question.push('¿Cuál de los conjuntos de datos sin procesar es el correcto para este estudio?');
  window.summary.answer.push('Dataset2');
  window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('10', 'Dataset2', true, '', '¿Cuál de los conjuntos de datos sin procesar es el correcto para este estudio? ', 1, 0, 'Scene2_Slide12');
}

function Script70()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script71()
{
  window.summary.question.push('¿Qué representación gráfica de los datos es más apropiada?');
window.summary.answer.push('Histogram');
window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('11', 'Histogram', true, '', '¿Qué representación gráfica de los datos es más apropiada? ', 1, 0, 'Scene2_Slide13');
}

function Script72()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script73()
{
  window.summary.question.push('¿Qué representación gráfica de los datos es más apropiada?');
window.summary.answer.push('Diagramas de cajas y bigotes');
window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('11', 'Diagramas de cajas y bigotes', true, '', '¿Qué representación gráfica de los datos es más apropiada? ', 1, 0, 'Scene2_Slide13');
}

function Script74()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script75()
{
  window.summary.question.push('¿Qué representación gráfica de los datos es más apropiada?');
window.summary.answer.push('Diagramas de dispersión');
window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('11', 'Diagramas de dispersión', false, '', '¿Qué representación gráfica de los datos es más apropiada? ', 1, 0, 'Scene2_Slide13');
}

function Script76()
{
  window.summary.question.push('¿Qué representación gráfica de los datos es más apropiada?');
window.summary.answer.push('Scatter Diagrams');
window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('11', 'Scatter Diagrams', false, '', '¿Qué representación gráfica de los datos es más apropiada? ', 1, 0, 'Scene2_Slide13');
}

function Script77()
{
  
/*
 *
 * TIC-TAC-TOE GAME
 *
 */

/*global GetPlayer:false */
var player = GetPlayer();
(function() {
	'use strict';
	var state = {
		READY: 0,
		RIGHT: 1,
		WRONG: 2
	};
	var validValues = [
		// Rows
		1  | 2   | 4,
		8  | 16  | 32,
		64 | 128 | 256,
		// Columns
		1  | 8   | 64,
		2  | 16  | 128,
		4  | 32  | 256
	];
	window.ttt = {
		questions: [
			{
				text: "El histograma sugiere que los chicos presentaron una mayor variabilidad en el número de productos cárnicos consumido que el realizado por las chicas",
				wrong: "Cierto, el histograma sugiere que los chicos presentaron una mayor variabilidad en el número de productos cárnicos consumido que el realizado por las chicas.",
				answer: true
			},
			{
				text: "El histograma sugiere que varios chicos y chicas no consumieron ningún producto cárnico en absoluto ",
				wrong: "Cierto, el histograma sugiere que varios chicos y chicas no consumieron ningún producto cárnico en absoluto.",
				answer: true
			},
			{
				text: "La gráfica B representa el mismo conjunto de datos que el histograma.",
				wrong: "Falso, la gráfica B no muestra la gran variabilidad en los valores para los chicos mostrados en el histograma y no representa el  mismo conjunto de datos que el histograma",
				answer: false
			},
			{
				text: "La gráfica A sugiere que el número medio de productos cárnicos consumidos por chicos y chicas fue similar ",
				wrong: "Cierto, la gráfica A sugiere que el número medio de productos cárnicos consumidos por chicos y chicas fue similar ",
				answer: true
			},
			{
				text: "La gráfica A muestra que las chicas presentaron mayor variabilidad en el número de productos cárnicos consumidos frente al que presentaron los chicos.",
				wrong: "Falso, la gráfica A muestra que los chicos presentaron mayor variabilidad en el número de productos cárnicos consumidos frente al presentado por las chicas.",
				answer: false
			},
			{
				text: "La tabla de resultados muestra que en media los chicos consumieron 7.386 productos cárnicos por día.",
				wrong: "Falso, 7.386 es la desviación estándar en el número de productos cárnicos consumidos por semana por los chicos.",
				answer: false
			},
			{
				text: "Los valores medios en la tabla de resultados muestran que los chicos consumieron más productos cárnicos por semana que las chicas.",
				wrong: "Cierto, los valores medios en la tabla de resultados muestra que los chicos consumieron más productos cárnicos por semana (11.97) que las chicas (10.5).",
				answer: true
			},
			{
				text: "Los niveles de significación mostrados en la tabla de resultados indican que la diferencia entre la media de productos cárnicos consumidos por chicos y chicas es significativamente diferente",
				wrong: "Falso, los niveles de significación mostrados en la tabla de resultados (p=.065) muestran que la diferencia entre la media de productos cárnicos consumidos por chicos y chicas no es significativamente diferente. ",
				answer: false
			},
			{
				text: "Los niveles de significación muestran que deberíamos rechazar la hipótesis nula",
				wrong: "Falso, el nivel de significación (.065) muestra que debemos no rechazar la hipótesis nula",
				answer: false
			}
		],
		activeQuestion: -1,
		totalValue: 0,
		init: function()
		{
			if (this.questions.length !== 9) {
				alert("Question count missmatch! Got " + this.questions.length + " expected 9");
				return;
			}
			var value = 1;
			// Setup the Qs with redundant info

var length = this.questions.length,
element = null;
for (var i = 0; i < length; i++) {
element = this.questions[i];
element .id = i;
element .value = value;
element .state = state.READY;
value *= 2;
}
		},
		updateQState: function(question, state)
		{
			question.state = state;
			player.SetVar('tttQuestionState' + question.id, state);
		},
		/*
		 * Functions to be called from Storyline
		 */
		// Resets all the question vars to ready
		setupQuestions: function()
		{
			this.activeQuestion = null;
			this.totalValue = 0;
			player.SetVar('tttQuestionText', '');
			player.SetVar('tttSlideSolved', 0);
var length = this.questions.length,
element = null;
for (var i = 0; i < length; i++) {
element = this.questions[i];
this.updateQState(element , state.READY);
}

		},
		// For when the user picks a question
		chooseQuestion: function(quid)
		{
			var question = this.questions[quid];
			if (question.state !== state.READY)
				return;
			this.activeQuestion = question;
			player.SetVar('tttQuestionText', question.text);
		},
		// Check if the answer is correctus
		checkAnswer: function(choice)
		{
			// Get what we're talkin about
			var question = this.activeQuestion;
			// Hide the question window
var questionText = player.GetVar('tttQuestionText');
			player.SetVar('tttQuestionText', '');
			// Reset the wrong var so we can trigger it if necessary
			player.SetVar('tttQuestionWrong', '');
			// Determine failure
			var choice_ = (choice == 'true') ? true : false;
			// If you pass you're wrong and stupid
			if (choice === 'pass' || choice_ !== question.answer) {
				this.updateQState(question, state.WRONG);
				// Pop up the "no u stupid" box
				player.SetVar('tttQuestionWrong', question.wrong);

window.summary.question.push(questionText);
window.summary.answer.push(choice_);
window.summary.correct.push('Incorrect');

				return;
			}
			// success!
window.summary.question.push(questionText);
window.summary.answer.push(question.answer);
window.summary.correct.push('Correct');
			this.updateQState(question, state.RIGHT);
			this.totalValue |= question.value;
			// Check if we've won
var length = validValues.length,
value = null;
for (var i = 0; i < length; i++) {
value = validValues[i];
if  ( (this.totalValue & value) === value )
player.SetVar('tttSlideSolved', 1);
}
		}
	};
	window.ttt.init();
})();

/*
 *
 * END OF TIC-TAC-TOE GAME
 *
 */


}

function Script78()
{
  window.ttt.setupQuestions();
}

function Script79()
{
  window.ttt.setupQuestions();
}

function Script80()
{
  window.ttt.chooseQuestion(0);
}

function Script81()
{
  window.ttt.chooseQuestion(1);
}

function Script82()
{
  window.ttt.chooseQuestion(2);
}

function Script83()
{
  window.ttt.chooseQuestion(3);
}

function Script84()
{
  window.ttt.chooseQuestion(4);
}

function Script85()
{
  window.ttt.chooseQuestion(5);
}

function Script86()
{
  window.ttt.chooseQuestion(6);
}

function Script87()
{
  window.ttt.chooseQuestion(7);
}

function Script88()
{
  window.ttt.chooseQuestion(8);
}

function Script89()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}

lmsAPI.RecordFillInInteraction('12', 'Completed', true, '', 'Microscope Game ', 1, 0, 'Scene2_Slide15');








}

function Script90()
{
  lmsAPI.RecordFillInInteraction('12', '', false, '', 'Microscope Game ', 1, 0, 'Scene2_Slide15');
}

function Script91()
{
  var eyesshut = 100, eyesopen = 10000, inblink = false;
var player = GetPlayer();
function blink(){
  inblink = !inblink;
  if (inblink) {
    player.SetVar('blinkState', 'hide');
    setTimeout(blink, eyesshut + Math.random() * 40);
  } else {
    player.SetVar('blinkState', 'show');
    setTimeout(blink, eyesopen + Math.random() * 500);
  }
}

blink(); 
}

function Script92()
{
  window.ttt.checkAnswer('true');
}

function Script93()
{
  window.ttt.checkAnswer('false');
}

function Script94()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script95()
{
  window.summary.question.push('¿qué test estadístico deberíamos usar?');
window.summary.answer.push('t test para muestras independientes');
window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('13', 't test para muestras independientes', true, '', '¿qué test estadístico deberíamos usar? ', 1, 0, 'Scene2_Slide14_1');
}

function Script96()
{
  window.summary.question.push('¿qué test estadístico deberíamos usar?');
window.summary.answer.push('t test para muestras repetidas  ');
window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('13', 't test para muestras repetidas ', false, '', '¿qué test estadístico deberíamos usar? ', 1, 0, 'Scene2_Slide14_1');
}

function Script97()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script98()
{
  window.summary.question.push('Interpretación de la tabla');
window.summary.answer.push('La tabla muestra que en media los niños cinsumieron 11.97 productos cárnicos por semana. ');
window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('14', 'La tabla muestra que en media los niños cinsumieron 11.97 productos cárnicos por semana. ', true, '', 'Interpretación de la tabla ', 1, 0, 'Scene2_Slide14_2');
}

function Script99()
{
  window.summary.question.push('Interpretación de la tabla');
window.summary.answer.push('La tabla muestra que en media los niños consumieron 7.386 productos cárnicos por semana. ');
window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('15', 'La tabla muestra que en media los niños consumieron 7.386 productos cárnicos por semana. ', false, '', 'Interpretación de la tabla ', 1, 0, 'Scene2_Slide14_2');
}

function Script100()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}

var time = player.GetVar('time');
//Bronze Gold Silver
if( time <= 15000 && time > 12000 ) {
player.SetVar("achQuestionBronze",1);
}
if( time>= 10000 &&  time <= 12000) {
player.SetVar("achQuestionBronze",0);
player.SetVar("achQuestionSilver",1);
}
if( time < 10000 ) {
player.SetVar("achQuestionSilver",0);
player.SetVar("achQuestionGold",1);
}
}

function Script101()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script102()
{
  window.summary.question.push('Interpretation of table');
window.summary.answer.push('La tabla muestra que los niños consumieron más productos cárnicos por semana que las chicas pero no de manera significativa.');
window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('16', 'La tabla muestra que los niños consumieron más productos cárnicos por semana que las chicas pero no de manera significativa.', true, '', 'Interpretation of table ', 1, 0, 'Scene2_Slide14_3');
}

function Script103()
{
  var player = GetPlayer();
var time = player.GetVar('time');
//Bronze Gold Silver
if( time <= 15000 && time > 12000 ) {
player.SetVar("achQuestionBronze",1);
}
if( time>= 10000 &&  time <= 12000) {
player.SetVar("achQuestionBronze",0);
player.SetVar("achQuestionSilver",1);
}
if( time < 10000 ) {
player.SetVar("achQuestionSilver",0);
player.SetVar("achQuestionGold",1);
}

window.achievements.advanceAchievement(4);
window.achievements.doEverythingAtOnce();
}

function Script104()
{
  window.summary.question.push('Interpretation of table');
window.summary.answer.push('La tabla muestra que los niños consumieron más productos cárnicos por semana que las chicas de manera significativa. ');
window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('16', 'La tabla muestra que los niños consumieron más productos cárnicos por semana que las chicas de manera significativa. ', false, '', 'Interpretation of table ', 1, 0, 'Scene2_Slide14_3');
}

