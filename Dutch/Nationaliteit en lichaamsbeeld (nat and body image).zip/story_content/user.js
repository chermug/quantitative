function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5kJK5ijnoUI":
        Script1();
        break;
      case "6N0l0mcquXF":
        Script2();
        break;
      case "6Ois1XiRFO6":
        Script3();
        break;
      case "5gDKMRKg68W":
        Script4();
        break;
      case "5pfIXRSwOvD":
        Script5();
        break;
      case "5XjsUqYkoXM":
        Script6();
        break;
      case "5ykPxChFGZN":
        Script7();
        break;
      case "5qNGgAre14S":
        Script8();
        break;
      case "6h6AjmAwqwD":
        Script9();
        break;
      case "6j4BFt9UU8d":
        Script10();
        break;
      case "62ysThA6nH4":
        Script11();
        break;
      case "5ZIslxsLG7v":
        Script12();
        break;
      case "5gLkt28CoTc":
        Script13();
        break;
      case "6d8OrZyTcLC":
        Script14();
        break;
      case "5zXKuZilHTY":
        Script15();
        break;
      case "5dUtlBeaZEW":
        Script16();
        break;
      case "5ZWRvshPBZv":
        Script17();
        break;
      case "65EgNZWQPdU":
        Script18();
        break;
      case "5aqIx1CUacR":
        Script19();
        break;
      case "6UG2iDBIXDv":
        Script20();
        break;
      case "6HeYVBqO12F":
        Script21();
        break;
      case "6FEBe5YMn3S":
        Script22();
        break;
      case "6bfdeW2ESBg":
        Script23();
        break;
      case "6aQJxOSPMUq":
        Script24();
        break;
      case "6KKxLhjCVcS":
        Script25();
        break;
      case "5pUciTTDGTt":
        Script26();
        break;
      case "6YCY5Z4yRBM":
        Script27();
        break;
      case "6eb5zzrScOz":
        Script28();
        break;
      case "6PfWYVrqFOl":
        Script29();
        break;
      case "5mAoPACqBXB":
        Script30();
        break;
      case "6Avg3xgH6j0":
        Script31();
        break;
      case "6323GJTSEIf":
        Script32();
        break;
      case "5wPB1CD6Y6o":
        Script33();
        break;
      case "5rRAb3AHPkn":
        Script34();
        break;
      case "6l8Ce8YqEOH":
        Script35();
        break;
      case "6XmCDYteqeS":
        Script36();
        break;
      case "6F8rImgneMW":
        Script37();
        break;
      case "64A6gNfVZxz":
        Script38();
        break;
      case "6Zl7tA9XsIE":
        Script39();
        break;
      case "6Q6DyHcQ5Oh":
        Script40();
        break;
      case "5nNHq5CxXk5":
        Script41();
        break;
      case "6NO5TK1tX53":
        Script42();
        break;
      case "6XPOaOxMZWC":
        Script43();
        break;
      case "6j7cdAANWxR":
        Script44();
        break;
      case "5wTJEEGicfa":
        Script45();
        break;
      case "5fxgKwFFJts":
        Script46();
        break;
      case "60FKlTHDTek":
        Script47();
        break;
      case "6kNWJ1lubGw":
        Script48();
        break;
      case "67rQ5kDIBiq":
        Script49();
        break;
      case "5flXqrzar9M":
        Script50();
        break;
      case "6O3mo8GjP4x":
        Script51();
        break;
      case "6TJmwnfCbUY":
        Script52();
        break;
      case "5xoxRScbvL5":
        Script53();
        break;
      case "5cBrKXo9Hkw":
        Script54();
        break;
      case "5o4Hi35feDv":
        Script55();
        break;
      case "5VtRfeRGkhd":
        Script56();
        break;
      case "6KgfEs1cMj1":
        Script57();
        break;
      case "6XEIGFSDOCr":
        Script58();
        break;
      case "5s0oHQ9zkZW":
        Script59();
        break;
      case "5lvTGHT6Iqp":
        Script60();
        break;
      case "6BlewM5YbGV":
        Script61();
        break;
      case "6oruEaBvBN6":
        Script62();
        break;
      case "6jXZyeFbgzB":
        Script63();
        break;
      case "5q1vvb1diDA":
        Script64();
        break;
      case "5hU4a3kXE0E":
        Script65();
        break;
      case "5mheKX12Tuk":
        Script66();
        break;
      case "5wVS3uCUsSD":
        Script67();
        break;
      case "5uPexZPJ5dd":
        Script68();
        break;
      case "6A3r1Ig23Xi":
        Script69();
        break;
      case "6A9x0RGrnjM":
        Script70();
        break;
      case "6qbCbgXLngH":
        Script71();
        break;
      case "6E36569MAfl":
        Script72();
        break;
      case "6OAGXYfYNm3":
        Script73();
        break;
      case "5rzpA4uC9GR":
        Script74();
        break;
      case "6qtVlbDQpuR":
        Script75();
        break;
      case "60w1IEXseiB":
        Script76();
        break;
      case "6Vj42nXlIJn":
        Script77();
        break;
      case "6gyodbuzbLE":
        Script78();
        break;
      case "62a4o2YUaQn":
        Script79();
        break;
      case "6fNR6cgxiVh":
        Script80();
        break;
      case "6aqCM2NUb6C":
        Script81();
        break;
      case "5lHWXepokAc":
        Script82();
        break;
      case "602LdMm2Klw":
        Script83();
        break;
      case "6WlJp6LgMQV":
        Script84();
        break;
      case "5YpVzCaSFAa":
        Script85();
        break;
      case "5VjDSHSBfLH":
        Script86();
        break;
      case "66ayRgjsOsX":
        Script87();
        break;
      case "6qSdjmcGyvJ":
        Script88();
        break;
      case "69YJqFT3GzO":
        Script89();
        break;
      case "68ZaKGFgUIA":
        Script90();
        break;
      case "6NskoV4TbW9":
        Script91();
        break;
      case "6AlG7MUAQrX":
        Script92();
        break;
      case "6r6HLv5tKta":
        Script93();
        break;
      case "5lu8BnF58zB":
        Script94();
        break;
  }
}

function Script1()
{
  
/*
 *
 *   ACHIEVEMENTS
 *
 */

/*global GetPlayer:false */
var player = GetPlayer();
(function() {
	'use strict';
	window.achievements = {
		achievements: [
			{
				name: "De eerste vraag",
				desc: "U hebt de eerst vraag goed beantwoord.",
				advance: function()
				{
					this.completed = true;
				}
			},
			{
				name: "Drie in een rij",
				desc: "U hebt drie vragen op rij goed beantwoord.",
				rowCounter: 0,
				advance: function()
				{
					var rowCounter = player.GetVar('ach3Question');
					console.log("in a row: "+rowCounter);
					if (rowCounter  == 3)
						this.completed = true;
				}
			},
			{
				name: "Hypothese",
				desc: "U hebt alle hypothese vragen goed beantwoord.",
				rowCounter: 0,
				advance: function()
				{
					var isHypothesis = player.GetVar('achHypothesis');
					console.log(isHypothesis);
					if (isHypothesis  == 1)
						this.completed = true;
				}
			},
			{
				name: "Alle",
				desc: "U hebt alle vragen goed beantwoord.",
				rowCounter: 0,
				advance: function()
				{
					var isAll = player.GetVar('achAll');
					console.log(isAll);
					if (isAll  == 1)
						this.completed = true;
				}
			},
			{
				name: "",
				desc: "",
				rowCounter: 0,
				advance: function()
				{
					//In each case it will earn something
					this.completed = true;
				}
			},

		],
		completedThisRound: [],

		init: function()
		{
			for (var i = 0; i < this.achievements.length; ++i) {
				this.achievements[i].id = i;
			}
		},
		// public
		advanceAchievement: function(achid)
		{
			var ach = this.achievements[achid];
			if (!ach)
				return;
			if (ach.completed)
				return;
			ach.advance();
			if (!ach.completed)
				return;
			this.completedThisRound.push(ach);
		},
		checkForAchievements: function()
		{
			return this.completedThisRound.length > 0;
		},
		resetAchievementVars: function()
		{
			player.SetVar('achievementActive', 0);
			player.SetVar('achievementName', '');
			player.SetVar('achievementDesc', '');
			player.SetVar('achivementId', -1);
		},
		setupAchievementVars: function()
		{
			var ach = this.completedThisRound.shift();
			player.SetVar('achievementActive', 1);
			player.SetVar('achievementName', ach.name);
			player.SetVar('achievementDesc', ach.desc);
			player.SetVar('achivementId', ach.id);
			player.SetVar('achievementUnlocked' + ach.id, 1);
		},
		// public
		doEverythingAtOnce: function()
		{
			this.resetAchievementVars();
			if (this.checkForAchievements())
				this.setupAchievementVars();

		}
	};
	window.achievements.init();
})();

/*
 *
 *  END OF ACHIEVEMENTS 
 *
 */

}

function Script2()
{
  var eyesshut = 100, eyesopen = 10000, inblink = false;
var player = GetPlayer();
var isPopUp = player.GetVar("isPopUp");
function blink(){
  inblink = !inblink;
 if (isPopUp == 1) {
 setTimeout(blink, 100);
}
  else if (inblink) {
    player.SetVar('blinkState', 'hide');
    setTimeout(blink, eyesshut + Math.random() * 100);
  } else {
    player.SetVar('blinkState', 'show');
    setTimeout(blink, eyesopen + Math.random() * 1000);
  }
}

blink(); 

window.summary = {question: [], answer: [], correct: []}; 
}

function Script3()
{
  var player = GetPlayer();
player.SetVar("answerM1", "");
player.SetVar("answerM2", "");
player.SetVar("answerM3", "");
player.SetVar("answerM4", "");
player.SetVar("answerM5", "");
player.SetVar("answerM6", "");
}

function Script4()
{
   window.summary.question.push('Null-hypothesis - Part1');
  window.summary.answer.push('Er is een verschil');
  window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('6', 'Er is een verschil', false, '', 'Null-hypothesis Part 1 ', 1, 0, 'Scene2_Slide6_1');
}

function Script5()
{
  player = GetPlayer();
answer1 = player.GetVar("answerM4");
answer2 = player.GetVar("answerM3");

 window.summary.question.push('Null-hypothesis - Part2');
  window.summary.answer.push(answer1 + answer2);
  window.summary.correct.push('Incorrect');

var answersum = answer1 + answer2;

lmsAPI.RecordFillInInteraction('7', answersum, false, '', 'Null-hypothesis Part 2 ', 1, 0, 'Scene2_Slide6_2');
}

function Script6()
{
  player = GetPlayer();
answer1 = player.GetVar("answerM5");
answer2 = player.GetVar("answerM6");

 window.summary.question.push('Null-hypothesis - Part3');
  window.summary.answer.push(answer1 + answer2);
  window.summary.correct.push('Incorrect');


var answersum = answer1 + answer2;

lmsAPI.RecordFillInInteraction('8', answersum, false, '', 'Null-hypothesis Part 3 ', 1, 0, 'Scene2_Slide6_3');
}

function Script7()
{
    window.summary.question.push('Null-hypothesis - Part1');
  window.summary.answer.push('Er is geen verschil');
  window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('6', 'Er is geen verschil', true, '', 'Null-hypothesis Part 1 ', 1, 0, 'Scene2_Slide6_1');
}

function Script8()
{
    window.summary.question.push('Null-hypothesis - Part2');
  window.summary.answer.push('Tussen nationaliteit');
  window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('7', 'Tussen nationaliteit', true, '', 'Null-hypothesis Part 2 ', 1, 0, 'Scene2_Slide6_2');
}

function Script9()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script10()
{
    window.summary.question.push('Null-hypothesis - Part3');
  window.summary.answer.push('en  lichaamsbeeld');
  window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('8', 'en  lichaamsbeeld', true, '', 'Null-hypothesis Part 3 ', 1, 0, 'Scene2_Slide6_3');
}

function Script11()
{
  var player = GetPlayer();
var score = player.GetVar('score');
var rank;
window.clearTimeout(timeVar);

//Score
if( score >= 1500 )
 rank = "A";
else if( score >= 1400 )
 rank = "B";
else if( score >= 1300 )
 rank = "C";
else if( score >= 1200 )
 rank = "D";
else 
 rank = "E";

player.SetVar('rank', rank);

//Time
function zeroPad(num, places) {
  var zero = places - num.toString().length + 1;
  return Array(+(zero > 0 && zero)).join("0") + num;
}

var time = player.GetVar('time');

var minutes = Math.floor(time / 60);
var seconds = time - minutes * 60;

minutes  = zeroPad(minutes, 2);
seconds  = zeroPad(seconds, 2);

var NewTime = minutes+":"+seconds;
player.SetVar('timeLast', NewTime );

player.SetVar("answerM1", "");
player.SetVar("answerM2", "");
player.SetVar("answerM3", "");
player.SetVar("answerM4", "");
player.SetVar("answerM5", "");
player.SetVar("answerM6", "");

lmsAPI.RecordFillInInteraction('14', score, true, '', 'Score ', 1, 0, 'Scene2_Slide8');
lmsAPI.RecordFillInInteraction('15', NewTime, true, '', 'Playing Time ', 1, 0, 'Scene2_Slide8');

lmsAPI.SetPassed();
player = GetPlayer();
var correct = player.GetVar("correctcounter");
var question = player.GetVar("questioncounter");

var score = ( correct / question ) * 100;
score =  Math.round( Number(score));
player.SetVar("calculatedscore", score);
player.SetVar("calculatedcorrect",correct);
player.SetVar("calculatedquestion",question);

lmsAPI.SetScore(score,100,0);

lmsAPI.RecordFillInInteraction('16', playerName, true, '', 'Player Name ', 1, 0, 'Scene2_Slide8');

lmsAPI.RecordFillInInteraction('17', rank, true, '', 'Rank ', 1, 0, 'Scene2_Slide8');


}

function Script12()
{
  var answersum = "";

if ( player.GetVar('answerM1') !== "")
   answersum +=  player.GetVar('answerM1') + ", ";
if ( player.GetVar('answerM2') !== "")
   answersum +=  player.GetVar('answerM2') + ", ";
if ( player.GetVar('answerM3') !== "")
   answersum +=  player.GetVar('answerM3') + ", ";
if ( player.GetVar('answerM4') !== "")
   answersum +=  player.GetVar('answerM4') + ", ";

lmsAPI.RecordFillInInteraction('18', answersum, true, '', 'Achievements ', 1, 0, 'Scene2_Slide8');
}

function Script13()
{
  var player = GetPlayer();
var formHTML = "<style>table {border-collapse:collapse;margin-top:20px;color:#373737} table, tr, td {padding: 10px;}tr:nth-child(even) {background:#E3F3EF; }tr:nth-child(odd) {background:#C7F1E6; }tr.header{background:#008A6E;color:white;font-weight:bold; }.logo { margin-bottom:10px;} .name {text-transform:uppercase;font-size:24px;font-weight:bold;color:#008A6E;}.label {font-weight:bold;}.logo span {font-size:27px; font-weight: bold; text-decoration:underline; color:#373737 } .logo img {float:right;}</style>";

var answersum = "";

if ( player.GetVar('answerM1') !== "")
   answersum +=  player.GetVar('answerM1') + ", ";
if ( player.GetVar('answerM2') !== "")
   answersum +=  player.GetVar('answerM2') + ", ";
if ( player.GetVar('answerM3') !== "")
   answersum +=  player.GetVar('answerM3') + ", ";
if ( player.GetVar('answerM4') !== "")
   answersum +=  player.GetVar('answerM4') + ", ";

formHTML += "<div class='logo'><span>Nationality and Body Image</span><img src='http://www.playgen.com/chermug/chermug_logo.jpg'></div>";
formHTML += "<span class='name'>" +  player.GetVar('playerName')+ "</span><br/>";
formHTML += "<span class='label'>Score:</span> " + player.GetVar('score') + "<br/>";
formHTML += "<span class='label'>Rank:</span> " + player.GetVar('rank') + "<br/>";
formHTML += "<span class='label'>Time:</span> " + player.GetVar('timeLast') + "<br/>";
formHTML += "<span class='label'>Achievements:</span> " + answersum + "<br/>";

formHTML += "<table><tr class='header'><td>ID</td><td>Question</td><td>Answered</td><td>Correct/Incorrect</td></tr>";

var length = window.summary.question.length;
var question = null;
var answer = null;
var correct = null;

for (var i = 0; i < length; i++) {
question = window.summary.question[i];
answer = window.summary.answer[i];
correct = window.summary.correct[i];
id = i + 1;

formHTML += "<tr><td>" + id + "</td><td>" + question + "</td><td>" + answer + "</td><td>" + correct + "</td></tr>";

}

formHTML += "</table>";

formHTML += "<script>window.print();</script>";

var preview = window.open("about:blank");
preview.document.open();
preview.document.write(formHTML);
preview.document.close();
preview.print();
}

function Script14()
{
  var seconds=0;
timeVar = setTimeout(startTime,1000);

 
function startTime(){
seconds=seconds+1;
var player = GetPlayer();
player.SetVar("time",seconds);
timeVar = setTimeout(startTime,1000);
}
 
}

function Script15()
{
  player = GetPlayer();
answer1 = player.GetVar("answerM1");
answer2 = player.GetVar("answerM2");
answer3 = player.GetVar("answerM3");
answer4 = player.GetVar("answerM4");
answer5 = player.GetVar("answerM5");
answer6 = player.GetVar("answerM6");
answer7 = player.GetVar("answerM7");
answer8 = player.GetVar("answerM8");

var answersum = "";

if ( answer1 !== "")
   answersum += answer1 + ", ";
if ( answer2 !== "")
   answersum += answer2 + ", ";
if ( answer3 !== "")
   answersum += answer3 + ", ";
if ( answer4 !== "")
   answersum += answer4 + ", ";
if ( answer5 !== "")
   answersum += answer5 + ", ";
if ( answer6 !== "")
   answersum += answer6;
if ( answer7 !== "")
   answersum += answer7 + ", ";
if ( answer8 !== "")
   answersum += answer8;


 window.summary.question.push('Wat zijn in de studie de hoofdvariabelen?');
  window.summary.answer.push(answersum);
  window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('1', answersum, false, '', 'Wat zijn in de studie de hoofdvariabelen?', 1, 0, 'Scene2_Slide9_1');
}

function Script16()
{
  window.achievements.advanceAchievement(0);
window.achievements.doEverythingAtOnce();
}

function Script17()
{
  player = GetPlayer();
answer1 = player.GetVar("answerM1");
answer2 = player.GetVar("answerM2");
answer3 = player.GetVar("answerM3");
answer4 = player.GetVar("answerM4");
answer5 = player.GetVar("answerM5");
answer6 = player.GetVar("answerM6");
answer7 = player.GetVar("answerM7");
answer8 = player.GetVar("answerM8");

var answersum = "";

if ( answer1 !== "")
   answersum += answer1 + ", ";
if ( answer2 !== "")
   answersum += answer2 + ", ";
if ( answer3 !== "")
   answersum += answer3 + ", ";
if ( answer4 !== "")
   answersum += answer4 + ", ";
if ( answer5 !== "")
   answersum += answer5 + ", ";
if ( answer6 !== "")
   answersum += answer6;
if ( answer7 !== "")
   answersum += answer7 + ", ";
if ( answer8 !== "")
   answersum += answer8;


 window.summary.question.push('Wat zijn in de studie de hoofdvariabelen?');
  window.summary.answer.push(answersum);
  window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('1', answersum, true, '', 'Wat zijn in de studie de hoofdvariabelen?', 1, 0, 'Scene2_Slide9_1');
}

function Script18()
{
  var player = GetPlayer();
player.SetVar("answerM1", "");
player.SetVar("answerM2", "");
player.SetVar("answerM3", "");
player.SetVar("answerM4", "");
player.SetVar("answerM5", "");
player.SetVar("answerM6", "");
player.SetVar("answerM7", "");
player.SetVar("answerM8", "");
}

function Script19()
{
  player = GetPlayer();
answer1 = player.GetVar("answerM1");
answer2 = player.GetVar("answerM2");
answer3 = player.GetVar("answerM3");
answer4 = player.GetVar("answerM4");
answer5 = player.GetVar("answerM5");
answer6 = player.GetVar("answerM6");
answer7 = player.GetVar("answerM7");
answer8 = player.GetVar("answerM8");

var answersum = "";

if ( answer1 !== "")
   answersum += answer1 + ", ";
if ( answer2 !== "")
   answersum += answer2 + ", ";
if ( answer3 !== "")
   answersum += answer3 + ", ";
if ( answer4 !== "")
   answersum += answer4 + ", ";
if ( answer5 !== "")
   answersum += answer5 + ", ";
if ( answer6 !== "")
   answersum += answer6;
if ( answer7 !== "")
   answersum += answer7 + ", ";
if ( answer8 !== "")
   answersum += answer8;


 window.summary.question.push('Wat zijn in deze studie de niveaus van de twee variabelen, nationaliteit en lichaamsbeeld');
  window.summary.answer.push(answersum);
  window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('2', answersum, true, '', 'Wat zijn in deze studie de niveaus van de twee variabelen, nationaliteit en lichaamsbeeld', 1, 0, 'Scene2_Slide9_2');
}

function Script20()
{
  player = GetPlayer();
answer1 = player.GetVar("answerM1");
answer2 = player.GetVar("answerM2");
answer3 = player.GetVar("answerM3");
answer4 = player.GetVar("answerM4");
answer5 = player.GetVar("answerM5");
answer6 = player.GetVar("answerM6");
answer7 = player.GetVar("answerM7");
answer8 = player.GetVar("answerM8");

var answersum = "";

if ( answer1 !== "")
   answersum += answer1 + ", ";
if ( answer2 !== "")
   answersum += answer2 + ", ";
if ( answer3 !== "")
   answersum += answer3 + ", ";
if ( answer4 !== "")
   answersum += answer4 + ", ";
if ( answer5 !== "")
   answersum += answer5 + ", ";
if ( answer6 !== "")
   answersum += answer6;
if ( answer7 !== "")
   answersum += answer7 + ", ";
if ( answer8 !== "")
   answersum += answer8;


 window.summary.question.push('Wat zijn in deze studie de niveaus van de twee variabelen, nationaliteit en lichaamsbeeld');
  window.summary.answer.push(answersum);
  window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('2', answersum, false, '', 'Wat zijn in deze studie de niveaus van de twee variabelen, nationaliteit en lichaamsbeeld', 1, 0, 'Scene2_Slide9_2');
}

function Script21()
{
  
/*
 *
 * HANGMAN GAME
 *
 */

/*global GetPlayer:false */
var player = GetPlayer();
(function() {
	'use strict';
	window.hangman = {
		//Use capital letters
		questions: ["NOMINAL"],
		activeQuestion: -1,
		question: '',
		chars: [],
		foundChars: {},
		foundLetters: 0,
		alphabet: ["A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z", "Ex"],
		init: function()
		{
			//console.log("init");

		},
		/*
		 * Functions to be called from Storyline
		 */
		// Setup question and the word into letters
		setupQuestions: function(questionnumber)
		{
			this.foundLetters = 0;
			this.activeQuestion = questionnumber;
			this.question = this.questions[this.activeQuestion-1];
			this.chars = this.question.split('');
			this.foundChars = {};
			for (var i = this.alphabet.length - 1; i >= 0; i--)
				player.SetVar("hmChange"+ this.alphabet[i], 0);


		},
		// Check if any letter or the answer is found
		letterPressed: function(letter)
		{
			if (this.foundChars[letter])
				return;
			player.SetVar("hmChangeSet", 0);
			var found = 0;
			for (var i = this.chars.length - 1; i >= 0; i--) {
				var pos = i+1;
				if(this.chars[i] == letter) {
					player.SetVar("hml"  + pos, letter);
					found = 1;
					this.foundLetters++;
					this.foundChars[letter] = true;
					if (this.foundLetters >= this.chars.length) {
						player.SetVar("hmAnswerFound", 1);
					}	
				}
			}
			if( found != 1) {
				//cant put ! in the stroyline var
				if (letter == "!")
					letter = "Ex";

				var isPressed = player.GetVar("hmChange"+letter);
				if( isPressed == 0) {
				var tleft = player.GetVar("hmtleft");
				tleft = tleft -1;
				player.SetVar("hmtleft", tleft);
				player.SetVar("hmChange"+ letter, 1);
				}
			}
		 

			return;
		}
	};
	window.hangman.init();
})();

/*
 *
 * END OF HANGMAN GAME
 *
 */


}

function Script22()
{
  var seconds=3000;
// display();
var blinkTimer = setTimeout(display,400);
var flag = 0;
 
function display(){
	seconds=seconds-1;
	var player = GetPlayer();
	var tleft = player.GetVar("hmtleft");
	player.SetVar("hmtimer",seconds);
	if( tleft != 9) {
		if(flag == 0) {
			player.SetVar("hmBlink","hide");
			flag = 1;
		}
		else {
		player.SetVar("hmBlink","show");
		flag = 0;
		}
		var blinkTimer = setTimeout(display,400);
	}
	else 
	player.SetVar("hmBlink","show");
}
 
}

function Script23()
{
  window.hangman.setupQuestions(1);
}

function Script24()
{
  window.hangman.letterPressed("B");
}

function Script25()
{
  window.hangman.letterPressed("C");
}

function Script26()
{
  window.hangman.letterPressed("D");
}

function Script27()
{
  window.hangman.letterPressed("E");
}

function Script28()
{
  window.hangman.letterPressed("F");
}

function Script29()
{
  window.hangman.letterPressed("G");
}

function Script30()
{
  window.hangman.letterPressed("H");
}

function Script31()
{
  window.hangman.letterPressed("I");
}

function Script32()
{
  window.hangman.letterPressed("J");
}

function Script33()
{
  window.hangman.letterPressed("K");
}

function Script34()
{
  window.hangman.letterPressed("L");
}

function Script35()
{
  window.hangman.letterPressed("M");
}

function Script36()
{
  window.hangman.letterPressed("N");
}

function Script37()
{
  window.hangman.letterPressed("O");
}

function Script38()
{
  window.hangman.letterPressed("P");
}

function Script39()
{
  window.hangman.letterPressed("Q");
}

function Script40()
{
  window.hangman.letterPressed("R");
}

function Script41()
{
  window.hangman.letterPressed("S");
}

function Script42()
{
  window.hangman.letterPressed("T");
}

function Script43()
{
  window.hangman.letterPressed("U");
}

function Script44()
{
  window.hangman.letterPressed("V");
}

function Script45()
{
  window.hangman.letterPressed("W");
}

function Script46()
{
  window.hangman.letterPressed("X");
}

function Script47()
{
  window.hangman.letterPressed("Y");
}

function Script48()
{
  window.hangman.letterPressed("Z");
}

function Script49()
{
  window.hangman.letterPressed("!");
}

function Script50()
{
  window.hangman.letterPressed("A");
}

function Script51()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script52()
{
    window.summary.question.push('Wat is in de studie het meetniveau dat geschikt is voor nationaliteit?');
  window.summary.answer.push('Nominal');
  window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('3', 'Nominal', true, '', 'Wat is in de studie het meetniveau dat geschikt is voor nationaliteit?', 1, 0, 'Scene2_Slide10');
}

function Script53()
{
    window.summary.question.push('Wat is in de studie het meetniveau dat geschikt is voor nationaliteit?');
  window.summary.answer.push('');
  window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('3', '', false, '', 'Wat is in de studie het meetniveau dat geschikt is voor nationaliteit?', 1, 0, 'Scene2_Slide10');
}

function Script54()
{
  var seconds=4;
//setTimeout(display,1000);
display();
 
function display(){
seconds=seconds-1;
var player = GetPlayer();
player.SetVar("hmcready",seconds);
var cready = player.GetVar("hmcready");
if ( cready == 0) {
player.SetVar("hmcready", "Go!");
setTimeout(display,1000);
}
else if ( cready == -1) {
player.SetVar("hmcready", "next");
}
else {
setTimeout(display,1000);
}
}
}

function Script55()
{
  var player = GetPlayer();
var name= player.GetVar('achievementName');
var desc = player.GetVar('achievementDesc');

console.log("name:" + name);
console.log("description" + desc);
}

function Script56()
{
  window.hangman.setupQuestions(1);
var seconds=4;
//setTimeout(display,1000);
display();
 
function display(){
seconds=seconds-1;
var player = GetPlayer();
player.SetVar("hmcready",seconds);
var cready = player.GetVar("hmcready");
if ( cready == 0) {
player.SetVar("hmcready", "Go!");
setTimeout(display,1000);
}
else if ( cready == -1) {
player.SetVar("hmcready", "next");
setTimeout(display,1000);
}
else {
setTimeout(display,1000);
}
}
}

function Script57()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script58()
{
  var player = GetPlayer();  
var answer = player.GetVar('answer');
window.summary.question.push('Welk meetniveau in de studie was geschikt voor lichaamsbeeld?');
window.summary.answer.push(answer);
window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('4', answer, true, '', 'Welk meetniveau in de studie was geschikt voor lichaamsbeeld? ', 1, 0, 'Scene2_Slide11_1');
}

function Script59()
{
  var player = GetPlayer();  
var answer = player.GetVar('answer');
window.summary.question.push('Welk meetniveau in de studie was geschikt voor lichaamsbeeld?');
window.summary.answer.push(answer);
window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('4', answer, false, '', 'Welk meetniveau in de studie was geschikt voor lichaamsbeeld? ', 1, 0, 'Scene2_Slide11_1');
}

function Script60()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script61()
{
    window.summary.question.push('Welk soort ontwerp suggereert dit scenario?');
  window.summary.answer.push('een associatie tussen variabelen');
  window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('5', 'een associatie tussen variabelen', true, '', 'Welk soort ontwerp suggereert dit scenario? ', 1, 0, 'Scene2_Slide11_2');
}

function Script62()
{
    window.summary.question.push('Welk soort ontwerp suggereert dit scenario?');
  window.summary.answer.push('verschillen tussen groepen');
  window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('5', 'verschillen tussen groepen', false, '', 'Welk soort ontwerp suggereert dit scenario? ', 1, 0, 'Scene2_Slide11_2');
}

function Script63()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script64()
{
    window.summary.question.push('Welke van onderstaande ruwe datasets is de juiste om te testen?');
  window.summary.answer.push('Dataset1');
  window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('9', 'Dataset1', true, '', 'Welke van onderstaande ruwe datasets is de juiste om te testen? ', 1, 0, 'Scene2_Slide12');
}

function Script65()
{
    window.summary.question.push('Welke van onderstaande ruwe datasets is de juiste om te testen?');
  window.summary.answer.push('Dataset2');
  window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('9', 'Dataset2', false, '', 'Welke van onderstaande ruwe datasets is de juiste om te testen? ', 1, 0, 'Scene2_Slide12');
}

function Script66()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script67()
{
  player = GetPlayer();  
var answer = player.GetVar('answer');

window.summary.question.push('Welke grafische afbeelding van de data zou je willen zien?');
window.summary.answer.push(answer);
window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('10', answer, true, '', 'Welke grafische afbeelding van de data zou je willen zien? ', 1, 0, 'Scene2_Slide13');
}

function Script68()
{
  player = GetPlayer();  
var answer = player.GetVar('answer');

window.summary.question.push('Welke grafische afbeelding van de data zou je willen zien?');
window.summary.answer.push(answer);
window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('10', answer, false, '', 'Welke grafische afbeelding van de data zou je willen zien? ', 1, 0, 'Scene2_Slide13');
}

function Script69()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script70()
{
  window.summary.question.push('Welke teststatistiek zou jij willen zien?');
window.summary.answer.push('Chi-kwadraat waarde');
window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('12', 'Chi-kwadraat waarde', true, '', 'Welke teststatistiek zou jij willen zien? ', 1, 0, 'Scene2_Slide14');
}

function Script71()
{
  window.summary.question.push('Welke teststatistiek zou jij willen zien?');
window.summary.answer.push('Pearsons r');
window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('12', 'Pearsons r', false, '', 'Welke teststatistiek zou jij willen zien? ', 1, 0, 'Scene2_Slide14_1');
}

function Script72()
{
  window.summary.question.push('Welke teststatistiek zou jij willen zien?');
window.summary.answer.push('Spearmans rho');
window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('12', 'Spearmans rho', false, '', 'Welke teststatistiek zou jij willen zien? ', 1, 0, 'Scene2_Slide14_1');
}

function Script73()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}

var time = player.GetVar('time');
//Bronze Gold Silver
if( time <= 15000 && time > 1200 ) {
player.SetVar("achQuestionBronze",1);
}
if( time>= 10000 &&  time <= 12000) {
player.SetVar("achQuestionBronze",0);
player.SetVar("achQuestionSilver",1);
}
if( time < 10000 ) {
player.SetVar("achQuestionSilver",0);
player.SetVar("achQuestionGold",1);
}
}

function Script74()
{
  window.achievements.advanceAchievement(3);
window.achievements.doEverythingAtOnce();

window.achievements.advanceAchievement(4);
window.achievements.doEverythingAtOnce();




}

function Script75()
{
  window.summary.question.push('De berekende waarde voor chi -kwadraat =6.142, p=.046. Is de chi-kwadraat waarde significant? ');
window.summary.answer.push('Ja');
window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('13', 'Ja', true, '', 'De berekende waarde voor chi -kwadraat =6.142, p=.046. Is de chi-kwadraat waarde significant? ', 1, 0, 'Scene2_Slide14_2');
}

function Script76()
{
  var player = GetPlayer();
var time = player.GetVar('time');
//Bronze Gold Silver
if( time <= 15000 && time > 1200 ) {
player.SetVar("achQuestionBronze",1);
}
if( time>= 10000 &&  time <= 12000) {
player.SetVar("achQuestionBronze",0);
player.SetVar("achQuestionSilver",1);
}
if( time < 10000 ) {
player.SetVar("achQuestionSilver",0);
player.SetVar("achQuestionGold",1);
}

window.achievements.advanceAchievement(4);
window.achievements.doEverythingAtOnce();
}

function Script77()
{
  window.summary.question.push('De berekende waarde voor chi -kwadraat =6.142, p=.046. Is de chi-kwadraat waarde significant?');
window.summary.answer.push('Nee');
window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('13', 'Nee', false, '', 'De berekende waarde voor chi -kwadraat =6.142, p=.046. Is de chi-kwadraat waarde significant? ', 1, 0, 'Scene2_Slide14_2');
}

function Script78()
{
  
/*
 *
 * TIC-TAC-TOE GAME
 *
 */

/*global GetPlayer:false */
var player = GetPlayer();
(function() {
	'use strict';
	var state = {
		READY: 0,
		RIGHT: 1,
		WRONG: 2
	};
	var validValues = [
	// Rows
		1  | 2   | 4,
		8  | 16  | 32,
		64 | 128 | 256,
		// Columns
		1  | 8   | 64,
		2  | 16  | 128,
		4  | 32  | 256,
		// Diagonals
		1 | 16 | 256,
		4 | 16 | 64
	];
	window.ttt = {
		questions: [
			{
				text: "In totaal waren er meer Britse dan Deense studenten.",
				wrong: "Niet correct.",
				answer: true
			},
			{
				text: "Het meest gebruikte antwoord van Deense studenten was precies goed. ",
				wrong: "Niet correct.",
				answer: true
			},
			{
				text: "In totaal, het minst voorkomende antwoord was te dun. ",
				wrong: "Niet correct.",
				answer: true
			},
			{
				text: "In totaal het meest voorkomende categorie was Britse studente die ‘te dun’ waren.",
				wrong: "Niet correct.",
				answer: false
			},
			{
				text: "Het meest gebruikte antwoord van Britse studenten was precies goed.",
				wrong: "Niet correct.",
				answer: false
			},
			{
				text: "Het minst gebruikte antwoord van Britse studenten was te dun. ",
				wrong: "Niet correct. ",
				answer: true
			},
			{
				text: "Er waren meer Deense dan Britse studenten die te dik waren. ",
				wrong: "Niet correct.",
				answer: false
			},
			{
				text: "Er waren meer Britse dan Deense studenten die precies goed waren.",
				wrong: "INiet correct.",
				answer: false
			},
			{
				text: "in totaal, de minst voorkomende categorie was Britse studenten die te dun waren. ",
				wrong: "Niet correct.",
				answer: true
			}
		],
		activeQuestion: -1,
		totalValue: 0,
		init: function()
		{
			if (this.questions.length !== 9) {
				alert("Question count missmatch! Got " + this.questions.length + " expected 9");
				return;
			}
			var value = 1;
			// Setup the Qs with redundant info

var length = this.questions.length,
element = null;
for (var i = 0; i < length; i++) {
element = this.questions[i];
element .id = i;
element .value = value;
element .state = state.READY;
value *= 2;
}
		},
		updateQState: function(question, state)
		{
			question.state = state;
			player.SetVar('tttQuestionState' + question.id, state);
		},
		/*
		 * Functions to be called from Storyline
		 */
		// Resets all the question vars to ready
		setupQuestions: function()
		{
			this.activeQuestion = null;
			this.totalValue = 0;
			player.SetVar('tttQuestionText', '');
			player.SetVar('tttSlideSolved', 0);
var length = this.questions.length,
element = null;
for (var i = 0; i < length; i++) {
element = this.questions[i];
this.updateQState(element , state.READY);
}

		},
		// For when the user picks a question
		chooseQuestion: function(quid)
		{
			var question = this.questions[quid];
			if (question.state !== state.READY)
				return;
			this.activeQuestion = question;
			player.SetVar('tttQuestionText', question.text);
		},
		// Check if the answer is correctus
		checkAnswer: function(choice)
		{
			// Get what we're talkin about
			var question = this.activeQuestion;
			// Hide the question window
var questionText = player.GetVar('tttQuestionText');
			player.SetVar('tttQuestionText', '');
			// Reset the wrong var so we can trigger it if necessary
			player.SetVar('tttQuestionWrong', '');
			// Determine failure
			var choice_ = (choice == 'true') ? true : false;
			// If you pass you're wrong and stupid
			if (choice === 'pass' || choice_ !== question.answer) {
				this.updateQState(question, state.WRONG);
				// Pop up the "no u stupid" box
				player.SetVar('tttQuestionWrong', question.wrong);

window.summary.question.push(questionText);
window.summary.answer.push(choice_);
window.summary.correct.push('Incorrect');

				return;
			}
			// success!
window.summary.question.push(questionText);
window.summary.answer.push(question.answer);
window.summary.correct.push('Correct');
			this.updateQState(question, state.RIGHT);
			this.totalValue |= question.value;
			// Check if we've won
var length = validValues.length,
value = null;
for (var i = 0; i < length; i++) {
value = validValues[i];
if  ( (this.totalValue & value) === value )
player.SetVar('tttSlideSolved', 1);
}
		}
	};
	window.ttt.init();
})();

/*
 *
 * END OF TIC-TAC-TOE GAME
 *
 */


}

function Script79()
{
  window.ttt.setupQuestions();
}

function Script80()
{
  window.ttt.setupQuestions();
}

function Script81()
{
  window.ttt.chooseQuestion(0);
}

function Script82()
{
  window.ttt.chooseQuestion(1);
}

function Script83()
{
  window.ttt.chooseQuestion(2);
}

function Script84()
{
  window.ttt.chooseQuestion(3);
}

function Script85()
{
  window.ttt.chooseQuestion(4);
}

function Script86()
{
  window.ttt.chooseQuestion(5);
}

function Script87()
{
  window.ttt.chooseQuestion(6);
}

function Script88()
{
  window.ttt.chooseQuestion(7);
}

function Script89()
{
  window.ttt.chooseQuestion(8);
}

function Script90()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


lmsAPI.RecordFillInInteraction('11', 'Completed', true, '', 'Microscope Game ', 1, 0, 'Scene2_Slide15');



}

function Script91()
{
  lmsAPI.RecordFillInInteraction('11', '', false, '', 'Microscope Game ', 1, 0, 'Scene2_Slide15');
}

function Script92()
{
  var eyesshut = 100, eyesopen = 10000, inblink = false;
var player = GetPlayer();
function blink(){
  inblink = !inblink;
  if (inblink) {
    player.SetVar('blinkState', 'hide');
    setTimeout(blink, eyesshut + Math.random() * 40);
  } else {
    player.SetVar('blinkState', 'show');
    setTimeout(blink, eyesopen + Math.random() * 500);
  }
}

blink(); 
}

function Script93()
{
  window.ttt.checkAnswer('true');
}

function Script94()
{
  window.ttt.checkAnswer('false');
}

