function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6Hamqkwv8HR":
        Script1();
        break;
      case "6BC5FXOFRpv":
        Script2();
        break;
      case "66IW5LlhkIv":
        Script3();
        break;
      case "5YzpE4FBLCa":
        Script4();
        break;
      case "5ocIOk89Jiz":
        Script5();
        break;
      case "5ukkHTAafer":
        Script6();
        break;
      case "6GT7WBjpKWM":
        Script7();
        break;
      case "6C5dPmCnXnP":
        Script8();
        break;
      case "6FtQ6E3MIGQ":
        Script9();
        break;
      case "5b99QcWmBy2":
        Script10();
        break;
      case "6iFhJgHtukI":
        Script11();
        break;
      case "5hk0JhDYJpC":
        Script12();
        break;
      case "6bRt96Es3Te":
        Script13();
        break;
      case "5eHVfeecsdi":
        Script14();
        break;
      case "5mWkT5pbW41":
        Script15();
        break;
      case "5YNtbzRh0Vf":
        Script16();
        break;
      case "5aC6jVLBsWc":
        Script17();
        break;
      case "6jnLZItk6tK":
        Script18();
        break;
      case "6LUANN1NKxm":
        Script19();
        break;
      case "5inZVDEFjRY":
        Script20();
        break;
      case "62170lbTb2S":
        Script21();
        break;
      case "5wLfv3NdhuL":
        Script22();
        break;
      case "5qNSADnkkVs":
        Script23();
        break;
      case "5n5OtSUeKTJ":
        Script24();
        break;
      case "5YnGQ2F7jU5":
        Script25();
        break;
      case "6XHJRvtU7Kx":
        Script26();
        break;
      case "5YRoJX65FU2":
        Script27();
        break;
      case "5sYUANy88YR":
        Script28();
        break;
      case "5r0WMSufehj":
        Script29();
        break;
      case "64pKU4qPZkS":
        Script30();
        break;
      case "5muw7Tai7fL":
        Script31();
        break;
      case "5utM5KvkGvX":
        Script32();
        break;
      case "6HQFVjr1wWO":
        Script33();
        break;
      case "5iAHTXFXNr0":
        Script34();
        break;
      case "5nPmw8pspcs":
        Script35();
        break;
      case "5chodjyoKXs":
        Script36();
        break;
      case "66TDLQSuz2J":
        Script37();
        break;
      case "6NQtYrfNtkY":
        Script38();
        break;
      case "5VwLEjjDIxP":
        Script39();
        break;
      case "6Y7qOn9WxUg":
        Script40();
        break;
      case "6SVgz86Onqh":
        Script41();
        break;
      case "6Pa0ufedPkK":
        Script42();
        break;
      case "5zPqFT5QwzQ":
        Script43();
        break;
      case "6fyT8PhPPN9":
        Script44();
        break;
      case "63DwVH3IEzk":
        Script45();
        break;
      case "6Ft5Tt8huuX":
        Script46();
        break;
      case "61Ew11oEV2J":
        Script47();
        break;
      case "6431LRO5nwl":
        Script48();
        break;
      case "6hd2TFvkFLA":
        Script49();
        break;
      case "6d1I24ggDDC":
        Script50();
        break;
      case "6NgR2LrnTl2":
        Script51();
        break;
      case "5vAItcp2WpN":
        Script52();
        break;
      case "5rxx28apWYe":
        Script53();
        break;
      case "64jNt7lo7Y8":
        Script54();
        break;
      case "6o7hzjGtmuR":
        Script55();
        break;
      case "5ebiCRuOSwn":
        Script56();
        break;
      case "6AlA3twEYJL":
        Script57();
        break;
      case "6W6QvtFpGqE":
        Script58();
        break;
      case "6Ra4TuHIt9m":
        Script59();
        break;
      case "6CrpUJixGr5":
        Script60();
        break;
      case "5suAdmd90o1":
        Script61();
        break;
      case "6X93boG7RoS":
        Script62();
        break;
      case "6SJtSjRTGAD":
        Script63();
        break;
      case "5femKWwCiIl":
        Script64();
        break;
      case "6fCsz1fwSFH":
        Script65();
        break;
      case "5eJDVuM9HpR":
        Script66();
        break;
      case "6dhMpGuB5r7":
        Script67();
        break;
      case "5hUwbYGcIa6":
        Script68();
        break;
      case "6gRsPpaBK3m":
        Script69();
        break;
      case "5tOcL3zr04q":
        Script70();
        break;
      case "5WEmDUA1hCi":
        Script71();
        break;
      case "5XZbyfda8Q4":
        Script72();
        break;
      case "654MTmSF2oY":
        Script73();
        break;
      case "6OsNbV5zSuo":
        Script74();
        break;
      case "5cFEv7aodJ1":
        Script75();
        break;
      case "6P32fgBfYxm":
        Script76();
        break;
      case "6Pjlizhfs0k":
        Script77();
        break;
      case "6FhUR2BAdfY":
        Script78();
        break;
      case "5Va0s0Hnnsd":
        Script79();
        break;
      case "6RvJont8inr":
        Script80();
        break;
      case "6aguLdcR9kU":
        Script81();
        break;
      case "6lXQHk2xY7v":
        Script82();
        break;
      case "6JHpJZek0lc":
        Script83();
        break;
      case "6no4rZ6IyOq":
        Script84();
        break;
      case "5eC08XnQ5GL":
        Script85();
        break;
      case "5dojWZwulaU":
        Script86();
        break;
      case "6Gsf2SooVZ7":
        Script87();
        break;
      case "6mQGN4grvFN":
        Script88();
        break;
      case "6rcMjoVkzVv":
        Script89();
        break;
      case "6UWaCsXB8A3":
        Script90();
        break;
      case "5nfWahyA6t7":
        Script91();
        break;
      case "5mUp4eEwhFI":
        Script92();
        break;
      case "6iyTr8Zlmrt":
        Script93();
        break;
      case "6VEBOjCKcL0":
        Script94();
        break;
      case "6GfKqqfazYs":
        Script95();
        break;
      case "6T75O9Md2xg":
        Script96();
        break;
      case "5qpAzWVX0zl":
        Script97();
        break;
      case "6KwDRRSgiw5":
        Script98();
        break;
      case "6TWHStiMH2C":
        Script99();
        break;
      case "5rISQT1MJov":
        Script100();
        break;
      case "5rU8dKVSRKo":
        Script101();
        break;
      case "5WHxmpj9kRs":
        Script102();
        break;
      case "658ZoHz9fzV":
        Script103();
        break;
      case "5xbnjr0p8ji":
        Script104();
        break;
      case "68R009yn9mX":
        Script105();
        break;
      case "6PaogH2LFr8":
        Script106();
        break;
      case "6A7yYwkv5xJ":
        Script107();
        break;
  }
}

function Script1()
{
  
/*
 *
 *   ACHIEVEMENTS
 *
 */

/*global GetPlayer:false */
var player = GetPlayer();
(function() {
	'use strict';
	window.achievements = {
		achievements: [
			{
				name: "De eerste vraag",
				desc: "U hebt de eerst vraag goed beantwoord.",
				advance: function()
				{
					this.completed = true;
				}
			},
			{
				name: "Drie in een rij",
				desc: "U hebt drie vragen op rij goed beantwoord.",
				rowCounter: 0,
				advance: function()
				{
					var rowCounter = player.GetVar('ach3Question');
					console.log("in a row: "+rowCounter);
					if (rowCounter  == 3)
						this.completed = true;
				}
			},
			{
				name: "Hypothese",
				desc: "U hebt alle hypothese vragen goed beantwoord.",
				rowCounter: 0,
				advance: function()
				{
					var isHypothesis = player.GetVar('achHypothesis');
					console.log(isHypothesis);
					if (isHypothesis  == 1)
						this.completed = true;
				}
			},
			{
				name: "Alle",
				desc: "U hebt alle vragen goed beantwoord.",
				rowCounter: 0,
				advance: function()
				{
					var isAll = player.GetVar('achAll');
					console.log(isAll);
					if (isAll  == 1)
						this.completed = true;
				}
			},
			{
				name: "",
				desc: "",
				rowCounter: 0,
				advance: function()
				{
					//In each case it will earn something
					this.completed = true;
				}
			},

		],
		completedThisRound: [],

		init: function()
		{
			for (var i = 0; i < this.achievements.length; ++i) {
				this.achievements[i].id = i;
			}
		},
		// public
		advanceAchievement: function(achid)
		{
			var ach = this.achievements[achid];
			if (!ach)
				return;
			if (ach.completed)
				return;
			ach.advance();
			if (!ach.completed)
				return;
			this.completedThisRound.push(ach);
		},
		checkForAchievements: function()
		{
			return this.completedThisRound.length > 0;
		},
		resetAchievementVars: function()
		{
			player.SetVar('achievementActive', 0);
			player.SetVar('achievementName', '');
			player.SetVar('achievementDesc', '');
			player.SetVar('achivementId', -1);
		},
		setupAchievementVars: function()
		{
			var ach = this.completedThisRound.shift();
			player.SetVar('achievementActive', 1);
			player.SetVar('achievementName', ach.name);
			player.SetVar('achievementDesc', ach.desc);
			player.SetVar('achivementId', ach.id);
			player.SetVar('achievementUnlocked' + ach.id, 1);
		},
		// public
		doEverythingAtOnce: function()
		{
			this.resetAchievementVars();
			if (this.checkForAchievements())
				this.setupAchievementVars();

		}
	};
	window.achievements.init();
})();

/*
 *
 *  END OF ACHIEVEMENTS 
 *
 */

}

function Script2()
{
  var eyesshut = 100, eyesopen = 10000, inblink = false;
var player = GetPlayer();
var isPopUp = player.GetVar("isPopUp");
function blink(){
  inblink = !inblink;
 if (isPopUp == 1) {
 setTimeout(blink, 100);
}
  else if (inblink) {
    player.SetVar('blinkState', 'hide');
    setTimeout(blink, eyesshut + Math.random() * 100);
  } else {
    player.SetVar('blinkState', 'show');
    setTimeout(blink, eyesopen + Math.random() * 1000);
  }
}

blink(); 

window.summary = {question: [], answer: [], correct: []}; 
}

function Script3()
{
  var player = GetPlayer();
player.SetVar("answerM1", "");
player.SetVar("answerM2", "");
player.SetVar("answerM3", "");
player.SetVar("answerM4", "");
player.SetVar("answerM5", "");
}

function Script4()
{
   window.summary.question.push('Formulate the null-hypothesis by selecting the correct sentence parts - Part1');
  window.summary.answer.push('There will be a difference');
  window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('7', 'There will be a difference', false, '', 'Null-hypothesis Part 1 ', 1, 0, 'Scene2_Slide6_1');
}

function Script5()
{
   window.summary.question.push('Formulate the null-hypothesis by selecting the correct sentence parts - Part2');
  window.summary.answer.push('between the Fat- buster diet.');
  window.summary.correct.push('Incorrect');


lmsAPI.RecordFillInInteraction('8', 'between the Fat- buster diet', false, '', 'Null-hypothesis Part 2 ', 1, 0, 'Scene2_Slide6_2');
}

function Script6()
{
  var player = GetPlayer();
var answer1 = player.GetVar("answerM5");
var answer2 = player.GetVar("answerM6");

 window.summary.question.push('Formulate the null-hypothesis by selecting the correct sentence parts - Part3');
  window.summary.answer.push(answer1 + answer2);
  window.summary.correct.push('Incorrect');

var answer = answer1 + answer2;

lmsAPI.RecordFillInInteraction('9', answer, false, '', 'Null-hypothesis Part 3 ', 1, 0, 'Scene2_Slide6_3');
}

function Script7()
{
    window.summary.question.push('Formulate the null-hypothesis by selecting the correct sentence parts - Part1');
  window.summary.answer.push('There will be no difference.');
  window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('7', 'There will be no difference', true, '', 'Null-hypothesis Part 1 ', 1, 0, 'Scene2_Slide6_1');
}

function Script8()
{
   window.summary.question.push('Formulate the null-hypothesis by selecting the correct sentence parts - Part2');
  window.summary.answer.push('between the Fat-buster and the Lo -carb diets');
  window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('8', 'between the Fat-buster and the Lo -carb diets', true, '', 'Null-hypothesis Part 2 ', 1, 0, 'Scene2_Slide6_2');
}

function Script9()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script10()
{
    window.summary.question.push('Formulate the null-hypothesis by selecting the correct sentence parts - Part3');
  window.summary.answer.push('in weight loss');
  window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('9', 'in weight loss', true, '', 'Null-hypothesis Part 3 ', 1, 0, 'Scene2_Slide6_3');
}

function Script11()
{
  var answersum = "";

if ( player.GetVar('answerM1') !== "")
   answersum +=  player.GetVar('answerM1') + ", ";
if ( player.GetVar('answerM2') !== "")
   answersum +=  player.GetVar('answerM2') + ", ";
if ( player.GetVar('answerM3') !== "")
   answersum +=  player.GetVar('answerM3') + ", ";
if ( player.GetVar('answerM4') !== "")
   answersum +=  player.GetVar('answerM4') + ", ";

lmsAPI.RecordFillInInteraction('18', answersum, true, '', 'Achievements ', 1, 0, 'Scene2_Slide8');
}

function Script12()
{
  var player = GetPlayer();
var formHTML = "<style>table {border-collapse:collapse;margin-top:20px;color:#373737} table, tr, td {padding: 10px;}tr:nth-child(even) {background:#E3F3EF; }tr:nth-child(odd) {background:#C7F1E6; }tr.header{background:#008A6E;color:white;font-weight:bold; }.logo { margin-bottom:10px;} .name {text-transform:uppercase;font-size:24px;font-weight:bold;color:#008A6E;}.label {font-weight:bold;}.logo span {font-size:27px; font-weight: bold; text-decoration:underline; color:#373737 } .logo img {float:right;}</style>";

var answersum = "";

if ( player.GetVar('answerM1') !== "")
   answersum +=  player.GetVar('answerM1') + ", ";
if ( player.GetVar('answerM2') !== "")
   answersum +=  player.GetVar('answerM2') + ", ";
if ( player.GetVar('answerM3') !== "")
   answersum +=  player.GetVar('answerM3') + ", ";
if ( player.GetVar('answerM4') !== "")
   answersum +=  player.GetVar('answerM4') + ", ";

formHTML += "<div class='logo'><span>Type of Diet and Weight Loss</span><img src='http://www.playgen.com/chermug/chermug_logo.jpg'></div>";
formHTML += "<span class='name'>" +  player.GetVar('playerName')+ "</span><br/>";
formHTML += "<span class='label'>Score:</span> " + player.GetVar('score') + "<br/>";
formHTML += "<span class='label'>Rank:</span> " + player.GetVar('rank') + "<br/>";
formHTML += "<span class='label'>Time:</span> " + player.GetVar('timeLast') + "<br/>";
formHTML += "<span class='label'>Achievements:</span> " + answersum + "<br/>";

formHTML += "<table><tr class='header'><td>ID</td><td>Question</td><td>Answered</td><td>Correct/Incorrect</td></tr>";

var length = window.summary.question.length;
var question = null;
var answer = null;
var correct = null;

for (var i = 0; i < length; i++) {
question = window.summary.question[i];
answer = window.summary.answer[i];
correct = window.summary.correct[i];
id = i + 1;

formHTML += "<tr><td>" + id + "</td><td>" + question + "</td><td>" + answer + "</td><td>" + correct + "</td></tr>";

}

formHTML += "</table>";

formHTML += "<script>window.print();</script>";

var preview = window.open("about:blank");
preview.document.open();
preview.document.write(formHTML);
preview.document.close();
preview.print();
}

function Script13()
{
  var seconds=0;
timeVar = setTimeout(startTime,1000);

 
function startTime(){
seconds=seconds+1;
var player = GetPlayer();
player.SetVar("time",seconds);
timeVar = setTimeout(startTime,1000);
}
 
}

function Script14()
{
  var player = GetPlayer();
var answer1 = player.GetVar("answerM1");
var answer2 = player.GetVar("answerM2");
var answer3 = player.GetVar("answerM3");
var answer4 = player.GetVar("answerM4");
var answer5 = player.GetVar("answerM5");

var answersum = "";

if ( answer1 !== "")
   answersum += answer1 + ", ";
if ( answer2 !== "")
   answersum += answer2 + ", ";
if ( answer3 !== "")
   answersum += answer3 + ", ";
if ( answer4 !== "")
   answersum += answer4 + ", ";
if ( answer5 !== "")
   answersum += answer5 + ", ";


 window.summary.question.push('In the study what are the variables?');
  window.summary.answer.push(answersum);
  window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('1', answersum, false, '', 'In the study what are the variables?', 1, 0, 'Scene2_Slide9_1');
}

function Script15()
{
  window.achievements.advanceAchievement(0);
window.achievements.doEverythingAtOnce();
}

function Script16()
{
  var player = GetPlayer();
var answer1 = player.GetVar("answerM1");
var answer2 = player.GetVar("answerM2");
var answer3 = player.GetVar("answerM3");
var answer4 = player.GetVar("answerM4");
var answer5 = player.GetVar("answerM5");

var answersum = "";

if ( answer1 !== "")
   answersum += answer1 + ", ";
if ( answer2 !== "")
   answersum += answer2 + ", ";
if ( answer3 !== "")
   answersum += answer3 + ", ";
if ( answer4 !== "")
   answersum += answer4 + ", ";
if ( answer5 !== "")
   answersum += answer5 + ", ";


 window.summary.question.push('In the study what are the variables?');
  window.summary.answer.push(answersum);
  window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('1', answersum, true, '', 'In the study what are the variables?', 1, 0, 'Scene2_Slide9_1');
}

function Script17()
{
  var player = GetPlayer();
var answer1 = player.GetVar("answerM1");
var answer2 = player.GetVar("answerM2");
var answer3 = player.GetVar("answerM3");
var answer4 = player.GetVar("answerM4");
var answer5 = player.GetVar("answerM5");

var answersum = "";

if ( answer1 !== "")
   answersum += answer1 + ", ";
if ( answer2 !== "")
   answersum += answer2 + ", ";
if ( answer3 !== "")
   answersum += answer3 + ", ";
if ( answer4 !== "")
   answersum += answer4 + ", ";
if ( answer5 !== "")
   answersum += answer5 + ", ";


 window.summary.question.push('In the study what are the independent variables?');
  window.summary.answer.push(answersum);
  window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('2', answersum, true, '', 'In the study what are the independent variables?', 1, 0, 'Scene2_Slide9_2');
}

function Script18()
{
  var player = GetPlayer();
var answer1 = player.GetVar("answerM1");
var answer2 = player.GetVar("answerM2");
var answer3 = player.GetVar("answerM3");
var answer4 = player.GetVar("answerM4");
var answer5 = player.GetVar("answerM5");

var answersum = "";

if ( answer1 !== "")
   answersum += answer1 + ", ";
if ( answer2 !== "")
   answersum += answer2 + ", ";
if ( answer3 !== "")
   answersum += answer3 + ", ";
if ( answer4 !== "")
   answersum += answer4 + ", ";
if ( answer5 !== "")
   answersum += answer5 + ", ";


 window.summary.question.push('In the study what are the independent variables?');
  window.summary.answer.push(answersum);
  window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('2', answersum, false, '', 'In the study what are the independent variables?', 1, 0, 'Scene2_Slide9_2');
}

function Script19()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script20()
{
  var player = GetPlayer();
var answer1 = player.GetVar("answerM1");
var answer2 = player.GetVar("answerM2");
var answer3 = player.GetVar("answerM3");
var answer4 = player.GetVar("answerM4");
var answer5 = player.GetVar("answerM5");

var answersum = "";

if ( answer1 !== "")
   answersum += answer1 + ", ";
if ( answer2 !== "")
   answersum += answer2 + ", ";
if ( answer3 !== "")
   answersum += answer3 + ", ";
if ( answer4 !== "")
   answersum += answer4 + ", ";
if ( answer5 !== "")
   answersum += answer5 + ", ";


 window.summary.question.push('In the study what are the dependent variables?');
  window.summary.answer.push(answersum);
  window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('3', answersum, true, '', 'In the study what are the dependent variables?', 1, 0, 'Scene2_Slide9_3');
}

function Script21()
{
  var player = GetPlayer();
var answer1 = player.GetVar("answerM1");
var answer2 = player.GetVar("answerM2");
var answer3 = player.GetVar("answerM3");
var answer4 = player.GetVar("answerM4");
var answer5 = player.GetVar("answerM5");

var answersum = "";

if ( answer1 !== "")
   answersum += answer1 + ", ";
if ( answer2 !== "")
   answersum += answer2 + ", ";
if ( answer3 !== "")
   answersum += answer3 + ", ";
if ( answer4 !== "")
   answersum += answer4 + ", ";
if ( answer5 !== "")
   answersum += answer5 + ", ";


 window.summary.question.push('In the study what are the dependent variables?');
  window.summary.answer.push(answersum);
  window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('3', answersum, false, '', 'In the study what are the dependent variables?', 1, 0, 'Scene2_Slide9_3');
}

function Script22()
{
  
/*
 *
 * HANGMAN GAME
 *
 */

/*global GetPlayer:false */
var player = GetPlayer();
(function() {
	'use strict';
	window.hangman = {
		//Use capital letters
		questions: ["NOMINAL"],
		activeQuestion: -1,
		question: '',
		chars: [],
		foundChars: {},
		foundLetters: 0,
		alphabet: ["A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z", "Ex"],
		init: function()
		{
			//console.log("init");

		},
		/*
		 * Functions to be called from Storyline
		 */
		// Setup question and the word into letters
		setupQuestions: function(questionnumber)
		{
			this.foundLetters = 0;
			this.activeQuestion = questionnumber;
			this.question = this.questions[this.activeQuestion-1];
			this.chars = this.question.split('');
			this.foundChars = {};
			for (var i = this.alphabet.length - 1; i >= 0; i--)
				player.SetVar("hmChange"+ this.alphabet[i], 0);


		},
		// Check if any letter or the answer is found
		letterPressed: function(letter)
		{
			if (this.foundChars[letter])
				return;
			player.SetVar("hmChangeSet", 0);
			var found = 0;
			for (var i = this.chars.length - 1; i >= 0; i--) {
				var pos = i+1;
				if(this.chars[i] == letter) {
					player.SetVar("hml"  + pos, letter);
					found = 1;
					this.foundLetters++;
					this.foundChars[letter] = true;
					if (this.foundLetters >= this.chars.length) {
						player.SetVar("hmAnswerFound", 1);
					}	
				}
			}
			if( found != 1) {
				//cant put ! in the stroyline var
				if (letter == "!")
					letter = "Ex";

				var isPressed = player.GetVar("hmChange"+letter);
				if( isPressed == 0) {
				var tleft = player.GetVar("hmtleft");
				tleft = tleft -1;
				player.SetVar("hmtleft", tleft);
				player.SetVar("hmChange"+ letter, 1);
				}
			}
		 

			return;
		}
	};
	window.hangman.init();
})();

/*
 *
 * END OF HANGMAN GAME
 *
 */


}

function Script23()
{
  var seconds=3000;
// display();
var blinkTimer = setTimeout(display,400);
var flag = 0;
 
function display(){
	seconds=seconds-1;
	var player = GetPlayer();
	var tleft = player.GetVar("hmtleft");
	player.SetVar("hmtimer",seconds);
	if( tleft != 9) {
		if(flag == 0) {
			player.SetVar("hmBlink","hide");
			flag = 1;
		}
		else {
		player.SetVar("hmBlink","show");
		flag = 0;
		}
		var blinkTimer = setTimeout(display,400);
	}
	else 
	player.SetVar("hmBlink","show");
}
 
}

function Script24()
{
  window.hangman.setupQuestions(1);
}

function Script25()
{
  window.hangman.letterPressed("B");
}

function Script26()
{
  window.hangman.letterPressed("C");
}

function Script27()
{
  window.hangman.letterPressed("D");
}

function Script28()
{
  window.hangman.letterPressed("E");
}

function Script29()
{
  window.hangman.letterPressed("F");
}

function Script30()
{
  window.hangman.letterPressed("G");
}

function Script31()
{
  window.hangman.letterPressed("H");
}

function Script32()
{
  window.hangman.letterPressed("I");
}

function Script33()
{
  window.hangman.letterPressed("J");
}

function Script34()
{
  window.hangman.letterPressed("K");
}

function Script35()
{
  window.hangman.letterPressed("L");
}

function Script36()
{
  window.hangman.letterPressed("M");
}

function Script37()
{
  window.hangman.letterPressed("N");
}

function Script38()
{
  window.hangman.letterPressed("O");
}

function Script39()
{
  window.hangman.letterPressed("P");
}

function Script40()
{
  window.hangman.letterPressed("Q");
}

function Script41()
{
  window.hangman.letterPressed("R");
}

function Script42()
{
  window.hangman.letterPressed("S");
}

function Script43()
{
  window.hangman.letterPressed("T");
}

function Script44()
{
  window.hangman.letterPressed("U");
}

function Script45()
{
  window.hangman.letterPressed("V");
}

function Script46()
{
  window.hangman.letterPressed("W");
}

function Script47()
{
  window.hangman.letterPressed("X");
}

function Script48()
{
  window.hangman.letterPressed("Y");
}

function Script49()
{
  window.hangman.letterPressed("Z");
}

function Script50()
{
  window.hangman.letterPressed("!");
}

function Script51()
{
  window.hangman.letterPressed("A");
}

function Script52()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script53()
{
    window.summary.question.push('In the study, what level of measurement is appropriate for kind of diet?');
  window.summary.answer.push('Nominal');
  window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('4', 'Nominal', true, '', 'In the study, what level of measurement is appropriate for kind of diet?', 1, 0, 'Scene2_Slide10');
}

function Script54()
{
    window.summary.question.push('In the study, what level of measurement is appropriate for kind of diet?');
  window.summary.answer.push('');
  window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('4', '', false, '', 'In the study, what level of measurement is appropriate for kind of diet?', 1, 0, 'Scene2_Slide10');
}

function Script55()
{
  var seconds=4;
//setTimeout(display,1000);
display();
 
function display(){
seconds=seconds-1;
var player = GetPlayer();
player.SetVar("hmcready",seconds);
var cready = player.GetVar("hmcready");
if ( cready == 0) {
player.SetVar("hmcready", "Go!");
setTimeout(display,1000);
}
else if ( cready == -1) {
player.SetVar("hmcready", "next");
}
else {
setTimeout(display,1000);
}
}
}

function Script56()
{
  window.hangman.setupQuestions(1);
var seconds=4;
//setTimeout(display,1000);
display();
 
function display(){
seconds=seconds-1;
var player = GetPlayer();
player.SetVar("hmcready",seconds);
var cready = player.GetVar("hmcready");
if ( cready == 0) {
player.SetVar("hmcready", "Go!");
setTimeout(display,1000);
}
else if ( cready == -1) {
player.SetVar("hmcready", "next");
setTimeout(display,1000);
}
else {
setTimeout(display,1000);
}
}
}

function Script57()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script58()
{
  var player = GetPlayer();  
var answer = player.GetVar('answer');
window.summary.question.push('In the study what level of measurement is weight loss?');
window.summary.answer.push(answer);
window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('5', answer, true, '', 'In the study what level of measurement is weight loss? ', 1, 0, 'Scene2_Slide11_1');
}

function Script59()
{
  var player = GetPlayer();  
var answer = player.GetVar('answer');
window.summary.question.push('In the study what level of measurement is weight loss?');
window.summary.answer.push(answer);
window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('5', answer, false, '', 'In the study what level of measurement is weight loss? ', 1, 0, 'Scene2_Slide11_1');
}

function Script60()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script61()
{
    window.summary.question.push('Which kind of design does this study suggest?');
  window.summary.answer.push('differences between groups');
  window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('6', 'differences between groups', true, '', 'Which kind of design does this study suggest? ', 1, 0, 'Scene2_Slide11_2');
}

function Script62()
{
    window.summary.question.push('Which kind of design does this study suggest?');
  window.summary.answer.push('an association between variables.');
  window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('6', 'an association between variables', false, '', 'Which kind of design does this study suggest? ', 1, 0, 'Scene2_Slide11_2');
}

function Script63()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script64()
{
    window.summary.question.push('Which raw data set below is the correct one to test your data?');
  window.summary.answer.push('Dataset1');
  window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('10', 'Dataset1', true, '', 'Which raw data set below is the correct one to test your data? ', 1, 0, 'Scene2_Slide12');
}

function Script65()
{
    window.summary.question.push('Which raw data set below is the correct one to test your data?');
  window.summary.answer.push('Dataset2');
  window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('10', 'Dataset2', false, '', 'Which raw data set below is the correct one to test your data? ', 1, 0, 'Scene2_Slide12');
}

function Script66()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script67()
{
  window.summary.question.push('Which graphical representation of the data would you like to see?');
window.summary.answer.push('Boxplots');
window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('11', 'Boxplots', true, '', 'Which graphical representation of the data would you like to see? ', 1, 0, 'Scene2_Slide13');

}

function Script68()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script69()
{
  window.summary.question.push('Which graphical representation of the data would you like to see?');
window.summary.answer.push('Frequency Distribution Histogram');
window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('11', 'Frequency Distribution Histogram', true, '', 'Which graphical representation of the data would you like to see? ', 1, 0, 'Scene2_Slide13');
}

function Script70()
{
  window.summary.question.push('Which graphical representation of the data would you like to see?');
window.summary.answer.push('Scatter Diagrams');
window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('11', 'Scatter Diagrams', false, '', 'Which graphical representation of the data would you like to see? ', 1, 0, 'Scene2_Slide13');
}

function Script71()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script72()
{
  window.summary.question.push('The histogram shows that the median weight loss was higher for participants on the Fat-buster diet than for those on the Lo-carb diet.');
window.summary.answer.push('True');
window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('13', 'True', true, '', 'The histogram shows that the median weight loss was higher for participants on the Fat-buster diet than for those on the Lo-carb diet? ', 1, 0, 'Scene2_Slide14_1');
}

function Script73()
{
  window.summary.question.push('The histogram shows that the median weight loss was higher for participants on the Fat-buster diet than for those on the Lo-carb diet.');
window.summary.answer.push('False');
window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('13', 'False', false, '', 'The histogram shows that the median weight loss was higher for participants on the Fat-buster diet than for those on the Lo-carb diet? ', 1, 0, 'Scene2_Slide14_1');
}

function Script74()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script75()
{
  window.summary.question.push('The histogram shows that there was more variability in weight loss for participants on the Fat-buster diet than the Lo-carb diet.');
window.summary.answer.push('False');
window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('14', 'False', true, '', 'The histogram shows that there was more variability in weight loss for participants on the Fat-buster diet than the Lo-carb diet.', 1, 0, 'Scene2_Slide14_2');
}

function Script76()
{
  window.summary.question.push('The histogram shows that there was more variability in weight loss for participants on the Fat-buster diet than the Lo-carb diet.');
window.summary.answer.push('True');
window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('14', 'True', false, '', 'The histogram shows that there was more variability in weight loss for participants on the Fat-buster diet than the Lo-carb diet.', 1, 0, 'Scene2_Slide14_2');
}

function Script77()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script78()
{
  window.summary.question.push('Choose the boxplot which matches this histogram');
window.summary.answer.push('Boxplot1');
window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('15', 'Boxplot1', true, '', 'Choose the boxplot which matches this histogram', 1, 0, 'Scene2_Slide14_3');
}

function Script79()
{
  window.summary.question.push('Choose the boxplot which matches this histogram');
window.summary.answer.push('Boxplot2');
window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('15', 'Boxplot2', false, '', 'Choose the boxplot which matches this histogram', 1, 0, 'Scene2_Slide14_3');
}

function Script80()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script81()
{
  window.summary.question.push('To test the hypothesis that “There will be no difference between the Lo-carb and the Fat-buster diets in the amount of weight lost.” which  statistical test should we use?');
window.summary.answer.push('Independent samples t test');
window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('16', 'Independent samples t test', true, '', 'To test the hypothesis that “There will be no difference between the Lo-carb and the Fat-buster diets in the amount of weight lost.” which  statistical test should we use?', 1, 0, 'Scene2_Slide14_4');
}

function Script82()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script83()
{
  window.summary.question.push('To test the hypothesis that “There will be no difference between the Lo-carb and the Fat-buster diets in the amount of weight lost.” which  statistical test should we use?');
window.summary.answer.push('Mann Whitney U test');
window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('16', 'Mann Whitney U test', true, '', 'To test the hypothesis that “There will be no difference between the Lo-carb and the Fat-buster diets in the amount of weight lost.” which  statistical test should we use?', 1, 0, 'Scene2_Slide14_4');
}

function Script84()
{
  window.summary.question.push('To test the hypothesis that “There will be no difference between the Lo-carb and the Fat-buster diets in the amount of weight lost.” which  statistical test should we use?');
window.summary.answer.push('Repeated measures t test ');
window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('16', 'Repeated measures t test', false, '', 'To test the hypothesis that “There will be no difference between the Lo-carb and the Fat-buster diets in the amount of weight lost.” which  statistical test should we use?', 1, 0, 'Scene2_Slide14_4');
}

function Script85()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script86()
{
  window.summary.question.push('The values in the table of 4.303 and .9428 show that:');
window.summary.answer.push('those on the Lo-carb diet showed greater variability in weight loss than those on the Fat-buster diet.');
window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('17', 'those on the Lo-carb diet showed greater variability in weight loss than those on the Fat-buster diet', false, '', 'The values in the table of 4.303 and .9428 show that:', 1, 0, 'Scene2_Slide14_5');
}

function Script87()
{
  window.summary.question.push('The values in the table of 4.303 and .9428 show that:');
window.summary.answer.push('those on the Lo-carb diet lost more weight than those on the Fat-buster diet.');
window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('17', 'those on the Lo-carb diet lost more weight than those on the Fat-buster diet', false, '', 'The values in the table of 4.303 and .9428 show that:', 1, 0, 'Scene2_Slide14_5');
}

function Script88()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script89()
{
  window.summary.question.push('The table shows that on average those on the Fat buster diet lost more weight than those on the Lo-carb diet.');
window.summary.answer.push('True');
window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('18', 'True', true, '', 'The table shows that on average those on the Fat buster diet lost more weight than those on the Lo-carb diet:', 1, 0, 'Scene2_Slide14_6');

var player = GetPlayer();
var score = player.GetVar('score');
var playerName = player.GetVar('playerName');
var rank;
window.clearTimeout(timeVar);

//Score
if( score >= 1500 )
 rank = "A";
else if( score >= 1400 )
 rank = "B";
else if( score >= 1300 )
 rank = "C";
else if( score >= 1200 )
 rank = "D";
else 
 rank = "E";

player.SetVar('rank', rank);

//Time
function zeroPad(num, places) {
  var zero = places - num.toString().length + 1;
  return Array(+(zero > 0 && zero)).join("0") + num;
}

var time = player.GetVar('time');

var minutes = Math.floor(time / 60);
var seconds = time - minutes * 60;

minutes  = zeroPad(minutes, 2);
seconds  = zeroPad(seconds, 2);

var NewTime = minutes+":"+seconds;
player.SetVar('timeLast', NewTime );


lmsAPI.RecordFillInInteraction('19', score, true, '', 'Score ', 1, 0, 'Scene2_Slide8');
lmsAPI.RecordFillInInteraction('20', NewTime, true, '', 'Playing Time ', 1, 0, 'Scene2_Slide8');

lmsAPI.SetPassed();
player = GetPlayer();
var correct = player.GetVar("correctcounter");
var question = player.GetVar("questioncounter");

var score = ( correct / question ) * 100;
score =  Math.round( Number(score));
player.SetVar("calculatedscore", score);
player.SetVar("calculatedcorrect",correct);
player.SetVar("calculatedquestion",question);

lmsAPI.SetScore(score,100,0);

lmsAPI.RecordFillInInteraction('21', playerName, true, '', 'Player Name ', 1, 0, 'Scene2_Slide8');

lmsAPI.RecordFillInInteraction('22', rank, true, '', 'Rank ', 1, 0, 'Scene2_Slide8');
}

function Script90()
{
  window.summary.question.push('The table shows that on average those on the Fat buster diet lost more weight than those on the Lo-carb diet.');
window.summary.answer.push('False');
window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('18', 'False', false, '', 'The table shows that on average those on the Fat buster diet lost more weight than those on the Lo-carb diet.', 1, 0, 'Scene2_Slide14_6');

var player = GetPlayer();
var score = player.GetVar('score');
var playerName = player.GetVar('playerName');
var rank;
window.clearTimeout(timeVar);

//Score
if( score >= 1500 )
 rank = "A";
else if( score >= 1400 )
 rank = "B";
else if( score >= 1300 )
 rank = "C";
else if( score >= 1200 )
 rank = "D";
else 
 rank = "E";

player.SetVar('rank', rank);

//Time
function zeroPad(num, places) {
  var zero = places - num.toString().length + 1;
  return Array(+(zero > 0 && zero)).join("0") + num;
}

var time = player.GetVar('time');

var minutes = Math.floor(time / 60);
var seconds = time - minutes * 60;

minutes  = zeroPad(minutes, 2);
seconds  = zeroPad(seconds, 2);

var NewTime = minutes+":"+seconds;
player.SetVar('timeLast', NewTime );


lmsAPI.RecordFillInInteraction('19', score, true, '', 'Score ', 1, 0, 'Scene2_Slide8');
lmsAPI.RecordFillInInteraction('20', NewTime, true, '', 'Playing Time ', 1, 0, 'Scene2_Slide8');

lmsAPI.SetPassed();
player = GetPlayer();
var correct = player.GetVar("correctcounter");
var question = player.GetVar("questioncounter");

var score = ( correct / question ) * 100;
score =  Math.round( Number(score));
player.SetVar("calculatedscore", score);
player.SetVar("calculatedcorrect",correct);
player.SetVar("calculatedquestion",question);

lmsAPI.SetScore(score,100,0);

lmsAPI.RecordFillInInteraction('21', playerName, true, '', 'Player Name ', 1, 0, 'Scene2_Slide8');

lmsAPI.RecordFillInInteraction('22', rank, true, '', 'Rank ', 1, 0, 'Scene2_Slide8');
}

function Script91()
{
  
/*
 *
 * TIC-TAC-TOE GAME
 *
 */

/*global GetPlayer:false */
var player = GetPlayer();
(function() {
	'use strict';
	var state = {
		READY: 0,
		RIGHT: 1,
		WRONG: 2
	};
	var validValues = [
		// Rows
		1  | 2   | 4,
		8  | 16  | 32,
		64 | 128 | 256,
		// Columns
		1  | 8   | 64,
		2  | 16  | 128,
		4  | 32  | 256
	];
	window.ttt = {
		questions: [
			{
				text: "De histogram toont dat de mediaan van ‘gewichtsverlies’ hoger was bij deelnemers aan het Fat-buster dieet dan bij deelnemers aan het Lo-carb-dieet.",
				wrong: "Juist, de histogram toont dat de mediaan van ‘gewichtsverlies’ hoger was bij deelnemers aan het Fat-buster dieet dan bij deelnemers aan het Lo-carb-dieet.",
				answer: true
			},
			{
				text: "De histogram toont dat er meer variatie in ‘gewichtsverlies’ was bij deelnemers aan het Fat-buster dieet dan bij deelnemers aan het Lo-carb-dieet.",
				wrong: "Onjuist, de histogram toont dat er meer variatie in gewichtsverlies was bij deelnemers aan het Lo-carb dieet dan bij deelnemers aan het Fat-buster dieet.",
				answer: false
			},
			{
				text: "Boxplot B representeert dezelfde dataset als de histogram.",
				wrong: "Onjuist, er zijn geen negatieve waarden voor gewichtsverlies in boxplot B, dit suggereert dat deze boxplot onjuist is.",
				answer: false
			},
			{
				text: "De histogram laat zien dat sommige deelnemers aan het Fat-buster dieet  zelfs in gewicht toenamen.",
				wrong: "Onjuist, de histogram laat zien dat sommige deelnemers aan het Lo-carb dieet juist in gewicht toenamen.",
				answer: false
			},
			{
				text: "Boxplot A toont dat de deelnemers aan het Lo-carb dieet meer variatie in gewichtsverlies laten zien dat die aan het Fat-buster dieet.",
				wrong: "Juist, de boxplot toont dat de deelnemers aan het Lo-carb dieet meer variatie in gewichtsverlies laten zien dat die aan het Fat-buster dieet.",
				answer: true
			},
			{
				text: "De resultaattabel toont dat het gemiddelde gewichtsverlies per week voor de LO-carb dieet deelnemers 4.30 kg was.",
				wrong: "Onjuist, de waarde 4.30 toont de standaard deviatie voor de LO-carb dieet deelnemers. ",
				answer: false
			},
			{
				text: "De resultaattabel toont dat gemiddeld de deelnemers aan het Fat-buster dieet meer gewicht verloren hebben dan de deelnemers aan het Lo-carb dieet.",
				wrong: "Juist, de tabel toont dat gemiddeld de deelnemers aan het Fat-buster dieet meer gewicht (4.85 kg) verloren hebben dan die aan het Lo-carb dieet (3.22 kg).",
				answer: true
			},
			{
				text: "Levene’s test voor gelijke varianties suggereert dat de varianties van de twee groepen gelijk.",
				wrong: "Onjuist, Levene’s test voor gelijke varianties suggereert dat de standaard deviatie voor de Lo-carb hoger was dan voor de Fat-buster dieet deelnemers (F=30.696, p=.000).",
				answer: false
			},
			{
				text: "De significantie waarde van de t-test toont dat we de nulhypothese moeten verwerpen.",
				wrong: "Onjuist, de significantie waarde van .051 (geen aanname van gelijke variantie) betekent dat we de nulhypothese moeten aannemen.",
				answer: false
			}
		],
		activeQuestion: -1,
		totalValue: 0,
		init: function()
		{
			if (this.questions.length !== 9) {
				alert("Question count missmatch! Got " + this.questions.length + " expected 9");
				return;
			}
			var value = 1;
			// Setup the Qs with redundant info

var length = this.questions.length,
element = null;
for (var i = 0; i < length; i++) {
element = this.questions[i];
element .id = i;
element .value = value;
element .state = state.READY;
value *= 2;
}
		},
		updateQState: function(question, state)
		{
			question.state = state;
			player.SetVar('tttQuestionState' + question.id, state);
		},
		/*
		 * Functions to be called from Storyline
		 */
		// Resets all the question vars to ready
		setupQuestions: function()
		{
			this.activeQuestion = null;
			this.totalValue = 0;
			player.SetVar('tttQuestionText', '');
			player.SetVar('tttSlideSolved', 0);
var length = this.questions.length,
element = null;
for (var i = 0; i < length; i++) {
element = this.questions[i];
this.updateQState(element , state.READY);
}

		},
		// For when the user picks a question
		chooseQuestion: function(quid)
		{
			var question = this.questions[quid];
			if (question.state !== state.READY)
				return;
			this.activeQuestion = question;
			player.SetVar('tttQuestionText', question.text);
		},
		// Check if the answer is correctus
		checkAnswer: function(choice)
		{
			// Get what we're talkin about
			var question = this.activeQuestion;
			// Hide the question window
var questionText = player.GetVar('tttQuestionText');
			player.SetVar('tttQuestionText', '');
			// Reset the wrong var so we can trigger it if necessary
			player.SetVar('tttQuestionWrong', '');
			// Determine failure
			var choice_ = (choice == 'true') ? true : false;
			// If you pass you're wrong and stupid
			if (choice === 'pass' || choice_ !== question.answer) {
				this.updateQState(question, state.WRONG);
				// Pop up the "no u stupid" box
				player.SetVar('tttQuestionWrong', question.wrong);

window.summary.question.push(questionText);
window.summary.answer.push(choice_);
window.summary.correct.push('Incorrect');

				return;
			}
			// success!
window.summary.question.push(questionText);
window.summary.answer.push(question.answer);
window.summary.correct.push('Correct');
			this.updateQState(question, state.RIGHT);
			this.totalValue |= question.value;
			// Check if we've won
var length = validValues.length,
value = null;
for (var i = 0; i < length; i++) {
value = validValues[i];
if  ( (this.totalValue & value) === value )
player.SetVar('tttSlideSolved', 1);
}
		}
	};
	window.ttt.init();
})();

/*
 *
 * END OF TIC-TAC-TOE GAME
 *
 */


}

function Script92()
{
  window.ttt.setupQuestions();
}

function Script93()
{
  window.ttt.setupQuestions();
}

function Script94()
{
  window.ttt.chooseQuestion(0);
}

function Script95()
{
  window.ttt.chooseQuestion(1);
}

function Script96()
{
  window.ttt.chooseQuestion(2);
}

function Script97()
{
  window.ttt.chooseQuestion(3);
}

function Script98()
{
  window.ttt.chooseQuestion(4);
}

function Script99()
{
  window.ttt.chooseQuestion(5);
}

function Script100()
{
  window.ttt.chooseQuestion(6);
}

function Script101()
{
  window.ttt.chooseQuestion(7);
}

function Script102()
{
  window.ttt.chooseQuestion(8);
}

function Script103()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}

lmsAPI.RecordFillInInteraction('12', 'Completed', true, '', 'Microscope Game ', 1, 0, 'Scene2_Slide15');







}

function Script104()
{
  lmsAPI.RecordFillInInteraction('12', '', false, '', 'Microscope Game ', 1, 0, 'Scene2_Slide15');
}

function Script105()
{
  var eyesshut = 100, eyesopen = 10000, inblink = false;
var player = GetPlayer();
function blink(){
  inblink = !inblink;
  if (inblink) {
    player.SetVar('blinkState', 'hide');
    setTimeout(blink, eyesshut + Math.random() * 40);
  } else {
    player.SetVar('blinkState', 'show');
    setTimeout(blink, eyesopen + Math.random() * 500);
  }
}

blink(); 
}

function Script106()
{
  window.ttt.checkAnswer('true');
}

function Script107()
{
  window.ttt.checkAnswer('false');
}

