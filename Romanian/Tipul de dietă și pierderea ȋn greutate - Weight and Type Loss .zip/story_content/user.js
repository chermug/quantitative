function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6CMVEOf82YZ":
        Script1();
        break;
      case "6TFYlSFBMcX":
        Script2();
        break;
      case "6BR4KiJLr9P":
        Script3();
        break;
      case "5qR9ygYtLqx":
        Script4();
        break;
      case "6JadJexaEh4":
        Script5();
        break;
      case "6b1ylhFzvnA":
        Script6();
        break;
      case "6paPT6q5pIc":
        Script7();
        break;
      case "68qFKR9dLG4":
        Script8();
        break;
      case "6JAaxLenOia":
        Script9();
        break;
      case "6mpOxarzvuT":
        Script10();
        break;
      case "6QlcbMguyHK":
        Script11();
        break;
      case "5jFKfGnSWLm":
        Script12();
        break;
      case "6EEU9HL3S0V":
        Script13();
        break;
      case "5gTjnRTnMbE":
        Script14();
        break;
      case "6S6qRWEc6zl":
        Script15();
        break;
      case "6d5ADdoJRQH":
        Script16();
        break;
      case "5wI9hxUfbmS":
        Script17();
        break;
      case "5zeoXj10jrP":
        Script18();
        break;
      case "65HcOmMjRKY":
        Script19();
        break;
      case "6Vw48i9vyha":
        Script20();
        break;
      case "6oRhJUm4rJp":
        Script21();
        break;
      case "6fXNLoixo9b":
        Script22();
        break;
      case "67mqbuHVXRx":
        Script23();
        break;
      case "5dEexui4QIU":
        Script24();
        break;
      case "5zXJ7qDhbmH":
        Script25();
        break;
      case "6rov9menPfI":
        Script26();
        break;
      case "5lqggnGS0om":
        Script27();
        break;
      case "5r079CTnBC0":
        Script28();
        break;
      case "6eniBMaD0zM":
        Script29();
        break;
      case "5y6RkifSP4s":
        Script30();
        break;
      case "6QT4UMRVq7I":
        Script31();
        break;
      case "5WYgqMlfmqT":
        Script32();
        break;
      case "68mA9lydyeB":
        Script33();
        break;
      case "5dVJfQ0Z4Za":
        Script34();
        break;
      case "6Q4apWTH62H":
        Script35();
        break;
      case "5eqHnzhkPKg":
        Script36();
        break;
      case "6FFHpwdQNoy":
        Script37();
        break;
      case "5j3nypVsHYS":
        Script38();
        break;
      case "5nsaAGIna9Y":
        Script39();
        break;
      case "6FrAU7X0dOU":
        Script40();
        break;
      case "6IrB34WnaPk":
        Script41();
        break;
      case "689H0lp0evD":
        Script42();
        break;
      case "66YnnIDlcMM":
        Script43();
        break;
      case "6GJOnN1MIgM":
        Script44();
        break;
      case "6VHfBUNddhg":
        Script45();
        break;
      case "5fhxFlv9XiE":
        Script46();
        break;
      case "5wJqnnp2sjT":
        Script47();
        break;
      case "5pZyn8qbIGO":
        Script48();
        break;
      case "5jYST76pjwF":
        Script49();
        break;
      case "5eq7GwbbEaW":
        Script50();
        break;
      case "5tUexMw9jQ4":
        Script51();
        break;
      case "6DxWo2thvc2":
        Script52();
        break;
      case "5aewdc7Q5sz":
        Script53();
        break;
      case "660rIWZWUyP":
        Script54();
        break;
      case "6Gs59q3CFVY":
        Script55();
        break;
      case "6UYIbH9AJeA":
        Script56();
        break;
      case "6EjMj6NMkeY":
        Script57();
        break;
      case "5YotBLpy2q5":
        Script58();
        break;
      case "5uaHnl6cEAZ":
        Script59();
        break;
      case "64g0aP3PxvM":
        Script60();
        break;
      case "6egBEKpeTMj":
        Script61();
        break;
      case "65BRFhzv2ly":
        Script62();
        break;
      case "5yZbqyEQB3n":
        Script63();
        break;
      case "6ks6EsxlJS2":
        Script64();
        break;
      case "6dt6cSH4ZLj":
        Script65();
        break;
      case "6ZxzhHceRh6":
        Script66();
        break;
      case "6aLUTssAEYz":
        Script67();
        break;
      case "6fYK9MZDpUJ":
        Script68();
        break;
      case "6mOTJN8dNCv":
        Script69();
        break;
      case "60npQ4vOJr0":
        Script70();
        break;
      case "62XgWumTPCf":
        Script71();
        break;
      case "6TB41swfmor":
        Script72();
        break;
      case "67CJmPMMUZi":
        Script73();
        break;
      case "6CE83yNHagl":
        Script74();
        break;
      case "6bwMxi3M1lF":
        Script75();
        break;
      case "5w5hQMgV2s1":
        Script76();
        break;
      case "676K3zATfss":
        Script77();
        break;
      case "5wsSStH5d1Y":
        Script78();
        break;
      case "6NJ9kT3ol7A":
        Script79();
        break;
      case "6EmirolSFqy":
        Script80();
        break;
      case "6QMxWZQE2fH":
        Script81();
        break;
      case "6mIqnwYUTHz":
        Script82();
        break;
      case "6j0o3shelTm":
        Script83();
        break;
      case "5o7MJavhV7t":
        Script84();
        break;
      case "5wnzRXlnVNR":
        Script85();
        break;
      case "6RYBqasrohS":
        Script86();
        break;
      case "5ZeTfpcjRwO":
        Script87();
        break;
      case "65EjkBUkrQW":
        Script88();
        break;
      case "6iUtVGuyujU":
        Script89();
        break;
      case "6JIxyLOlnqL":
        Script90();
        break;
      case "5kx80UOq9lo":
        Script91();
        break;
      case "657iuL1QEte":
        Script92();
        break;
      case "6ID2wfrDWvV":
        Script93();
        break;
      case "5taLPpodQsI":
        Script94();
        break;
      case "69HUNGefctF":
        Script95();
        break;
      case "5UtYdhwEX9y":
        Script96();
        break;
      case "6E37kKbiPOs":
        Script97();
        break;
      case "60nokXLlka8":
        Script98();
        break;
      case "6RSLmQ53lbg":
        Script99();
        break;
      case "5vPhN3Y2ezQ":
        Script100();
        break;
      case "5WKCCL1t7b5":
        Script101();
        break;
      case "6YQ7kdEZLN5":
        Script102();
        break;
      case "6kVOSLI1hqB":
        Script103();
        break;
      case "5Y6VJ573Zt7":
        Script104();
        break;
      case "5kgd8OuNpB4":
        Script105();
        break;
      case "61IsIBWDGBE":
        Script106();
        break;
      case "60h5Zig3FG7":
        Script107();
        break;
      case "5wtoHaXu5Go":
        Script108();
        break;
  }
}

function Script1()
{
  
/*
 *
 *   ACHIEVEMENTS
 *
 */

/*global GetPlayer:false */
var player = GetPlayer();
(function() {
	'use strict';
	window.achievements = {
		achievements: [
			{
				name: "First Question",
				desc: "You have successfully answered first question correctly.",
				advance: function()
				{
					this.completed = true;
				}
			},
			{
				name: "Three in a row",
				desc: "You have successfully answered three questions correctly in a row.",
				rowCounter: 0,
				advance: function()
				{
					var rowCounter = player.GetVar('ach3Question');
					if (rowCounter  == 3)
						this.completed = true;
				}
			},
			{
				name: "Hypothesis",
				desc: "You have successfully answered all hypothesis questions without any wrong answer.",
				rowCounter: 0,
				advance: function()
				{
					var isHypothesis = player.GetVar('achHypothesis');
					console.log(isHypothesis);
					if (isHypothesis  == 1)
						this.completed = true;
				}
			},
			{
				name: "All",
				desc: "You have successfully answered all of the questions correct.",
				rowCounter: 0,
				advance: function()
				{
					var isAll = player.GetVar('achAll');
					console.log(isAll);
					if (isAll  == 1)
						this.completed = true;
				}
			},
			{
				name: "",
				desc: "",
				rowCounter: 0,
				advance: function()
				{
					//In each case it will earn something
					this.completed = true;
				}
			},

		],
		completedThisRound: [],

		init: function()
		{
			for (var i = 0; i < this.achievements.length; ++i) {
				this.achievements[i].id = i;
			}
		},
		// public
		advanceAchievement: function(achid)
		{
			var ach = this.achievements[achid];
			if (!ach)
				return;
			if (ach.completed)
				return;
			ach.advance();
			if (!ach.completed)
				return;
			this.completedThisRound.push(ach);
		},
		checkForAchievements: function()
		{
			return this.completedThisRound.length > 0;
		},
		resetAchievementVars: function()
		{
			player.SetVar('achievementActive', 0);
			player.SetVar('achievementName', '');
			player.SetVar('achievementDesc', '');
			player.SetVar('achivementId', -1);
		},
		setupAchievementVars: function()
		{
			var ach = this.completedThisRound.shift();
			player.SetVar('achievementActive', 1);
			player.SetVar('achievementName', ach.name);
			player.SetVar('achievementDesc', ach.desc);
			player.SetVar('achivementId', ach.id);
			player.SetVar('achievementUnlocked' + ach.id, 1);
		},
		// public
		doEverythingAtOnce: function()
		{
			this.resetAchievementVars();
			if (this.checkForAchievements())
				this.setupAchievementVars();

		}
	};
	window.achievements.init();
})();

/*
 *
 *  END OF ACHIEVEMENTS 
 *
 */

}

function Script2()
{
  var eyesshut = 100, eyesopen = 10000, inblink = false;
var player = GetPlayer();
var isPopUp = player.GetVar("isPopUp");
function blink(){
  inblink = !inblink;
 if (isPopUp == 1) {
 setTimeout(blink, 100);
}
  else if (inblink) {
    player.SetVar('blinkState', 'hide');
    setTimeout(blink, eyesshut + Math.random() * 100);
  } else {
    player.SetVar('blinkState', 'show');
    setTimeout(blink, eyesopen + Math.random() * 1000);
  }
}

blink(); 

window.summary = {question: [], answer: [], correct: []}; 
}

function Script3()
{
  var player = GetPlayer();
player.SetVar("answerM1", "");
player.SetVar("answerM2", "");
player.SetVar("answerM3", "");
player.SetVar("answerM4", "");
player.SetVar("answerM5", "");
}

function Script4()
{
   window.summary.question.push('Formulate the null-hypothesis by selecting the correct sentence parts - Part1');
  window.summary.answer.push('Va exista o diferență');
  window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('7', 'Va exista o diferență', false, '', 'Null-hypothesis Part 1 ', 1, 0, 'Scene2_Slide6_1');
}

function Script5()
{
   window.summary.question.push('Formulate the null-hypothesis by selecting the correct sentence parts - Part2');
  window.summary.answer.push('ȋntre dieta Distrugătoare de grăsimi');
  window.summary.correct.push('Incorrect');


lmsAPI.RecordFillInInteraction('8', 'ȋntre dieta Distrugătoare de grăsimi', false, '', 'Null-hypothesis Part 2 ', 1, 0, 'Scene2_Slide6_2');
}

function Script6()
{
  player = GetPlayer();
answer1 = player.GetVar("answerM5");
answer2 = player.GetVar("answerM6");

 window.summary.question.push('Formulate the null-hypothesis by selecting the correct sentence parts - Part3');
  window.summary.answer.push(answer1 + answer2);
  window.summary.correct.push('Incorrect');

var answer = answer1 + answer2;

lmsAPI.RecordFillInInteraction('9', answer, false, '', 'Null-hypothesis Part 3 ', 1, 0, 'Scene2_Slide6_3');
}

function Script7()
{
    window.summary.question.push('Formulate the null-hypothesis by selecting the correct sentence parts - Part1');
  window.summary.answer.push('Nu va exista o diferență');
  window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('7', 'Nu va exista o diferență', true, '', 'Null-hypothesis Part 1 ', 1, 0, 'Scene2_Slide6_1');
}

function Script8()
{
   window.summary.question.push('Formulate the null-hypothesis by selecting the correct sentence parts - Part2');
  window.summary.answer.push('ȋntre dieta distrugătoare de grăsimi și dieta bazată pe puțini carbohidrați ');
  window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('8', 'ȋntre dieta distrugătoare de grăsimi și dieta bazată pe puțini carbohidrați ', true, '', 'Null-hypothesis Part 2 ', 1, 0, 'Scene2_Slide6_2');
}

function Script9()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script10()
{
    window.summary.question.push('Formulate the null-hypothesis by selecting the correct sentence parts - Part3');
  window.summary.answer.push('ȋn pierderea ȋn greutate');
  window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('9', 'ȋn pierderea ȋn greutate', true, '', 'Null-hypothesis Part 3 ', 1, 0, 'Scene2_Slide6_3');
}

function Script11()
{
  var player = GetPlayer();
var score = player.GetVar('score');
var rank;
window.clearTimeout(timeVar);

//Score
if( score >= 1500 )
 rank = "A";
else if( score >= 1400 )
 rank = "B";
else if( score >= 1300 )
 rank = "C";
else if( score >= 1200 )
 rank = "D";
else 
 rank = "E";

player.SetVar('rank', rank);

//Time
function zeroPad(num, places) {
  var zero = places - num.toString().length + 1;
  return Array(+(zero > 0 && zero)).join("0") + num;
}

var time = player.GetVar('time');

var minutes = Math.floor(time / 60);
var seconds = time - minutes * 60;

minutes  = zeroPad(minutes, 2);
seconds  = zeroPad(seconds, 2);

var NewTime = minutes+":"+seconds;
player.SetVar('timeLast', NewTime );

player.SetVar("answerM1", "");
player.SetVar("answerM2", "");
player.SetVar("answerM3", "");
player.SetVar("answerM4", "");
player.SetVar("answerM5", "");
player.SetVar("answerM6", "");

lmsAPI.RecordFillInInteraction('14', score, true, '', 'Score ', 1, 0, 'Scene2_Slide8');
lmsAPI.RecordFillInInteraction('15', NewTime, true, '', 'Playing Time ', 1, 0, 'Scene2_Slide8');

lmsAPI.SetPassed();
player = GetPlayer();
var correct = player.GetVar("correctcounter");
var question = player.GetVar("questioncounter");

var score = ( correct / question ) * 100;
score =  Math.round( Number(score));
player.SetVar("calculatedscore", score);
player.SetVar("calculatedcorrect",correct);
player.SetVar("calculatedquestion",question);

lmsAPI.SetScore(score,100,0);

lmsAPI.RecordFillInInteraction('16', playerName, true, '', 'Player Name ', 1, 0, 'Scene2_Slide8');

lmsAPI.RecordFillInInteraction('17', rank, true, '', 'Rank ', 1, 0, 'Scene2_Slide8');
}

function Script12()
{
  var answersum = "";

if ( player.GetVar('answerM1') !== "")
   answersum +=  player.GetVar('answerM1') + ", ";
if ( player.GetVar('answerM2') !== "")
   answersum +=  player.GetVar('answerM2') + ", ";
if ( player.GetVar('answerM3') !== "")
   answersum +=  player.GetVar('answerM3') + ", ";
if ( player.GetVar('answerM4') !== "")
   answersum +=  player.GetVar('answerM4') + ", ";

lmsAPI.RecordFillInInteraction('18', answersum, true, '', 'Achievements ', 1, 0, 'Scene2_Slide8');
}

function Script13()
{
  var player = GetPlayer();
var formHTML = "<style>table {border-collapse:collapse;margin-top:20px;color:#373737} table, tr, td {padding: 10px;}tr:nth-child(even) {background:#E3F3EF; }tr:nth-child(odd) {background:#C7F1E6; }tr.header{background:#008A6E;color:white;font-weight:bold; }.logo { margin-bottom:10px;} .name {text-transform:uppercase;font-size:24px;font-weight:bold;color:#008A6E;}.label {font-weight:bold;}.logo span {font-size:27px; font-weight: bold; text-decoration:underline; color:#373737 } .logo img {float:right;}</style>";

var answersum = "";

if ( player.GetVar('answerM1') !== "")
   answersum +=  player.GetVar('answerM1') + ", ";
if ( player.GetVar('answerM2') !== "")
   answersum +=  player.GetVar('answerM2') + ", ";
if ( player.GetVar('answerM3') !== "")
   answersum +=  player.GetVar('answerM3') + ", ";
if ( player.GetVar('answerM4') !== "")
   answersum +=  player.GetVar('answerM4') + ", ";

formHTML += "<div class='logo'><span>Type of Diet and Weight Loss</span><img src='http://www.playgen.com/chermug/chermug_logo.jpg'></div>";
formHTML += "<span class='name'>" +  player.GetVar('playerName')+ "</span><br/>";
formHTML += "<span class='label'>Score:</span> " + player.GetVar('score') + "<br/>";
formHTML += "<span class='label'>Rank:</span> " + player.GetVar('rank') + "<br/>";
formHTML += "<span class='label'>Time:</span> " + player.GetVar('timeLast') + "<br/>";
formHTML += "<span class='label'>Achievements:</span> " + answersum + "<br/>";

formHTML += "<table><tr class='header'><td>ID</td><td>Question</td><td>Answered</td><td>Correct/Incorrect</td></tr>";

var length = window.summary.question.length;
var question = null;
var answer = null;
var correct = null;

for (var i = 0; i < length; i++) {
question = window.summary.question[i];
answer = window.summary.answer[i];
correct = window.summary.correct[i];
id = i + 1;

formHTML += "<tr><td>" + id + "</td><td>" + question + "</td><td>" + answer + "</td><td>" + correct + "</td></tr>";

}

formHTML += "</table>";

formHTML += "<script>window.print();</script>";

var preview = window.open("about:blank");
preview.document.open();
preview.document.write(formHTML);
preview.document.close();
preview.print();
}

function Script14()
{
  var seconds=0;
timeVar = setTimeout(startTime,1000);

 
function startTime(){
seconds=seconds+1;
var player = GetPlayer();
player.SetVar("time",seconds);
timeVar = setTimeout(startTime,1000);
}
 
}

function Script15()
{
  var player = GetPlayer();
var answer1 = player.GetVar("answerM1");
var answer2 = player.GetVar("answerM2");
var answer3 = player.GetVar("answerM3");
var answer4 = player.GetVar("answerM4");
var answer5 = player.GetVar("answerM5");

var answersum = "";

if ( answer1 !== "")
   answersum += answer1 + ", ";
if ( answer2 !== "")
   answersum += answer2 + ", ";
if ( answer3 !== "")
   answersum += answer3 + ", ";
if ( answer4 !== "")
   answersum += answer4 + ", ";
if ( answer5 !== "")
   answersum += answer5 + ", ";


 window.summary.question.push('Care sunt variabilele din studiu?');
  window.summary.answer.push(answersum);
  window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('1', answersum, false, '', 'Care sunt variabilele din studiu?', 1, 0, 'Scene2_Slide9_1');
}

function Script16()
{
  window.achievements.advanceAchievement(0);
window.achievements.doEverythingAtOnce();
}

function Script17()
{
  var player = GetPlayer();
var answer1 = player.GetVar("answerM1");
var answer2 = player.GetVar("answerM2");
var answer3 = player.GetVar("answerM3");
var answer4 = player.GetVar("answerM4");
var answer5 = player.GetVar("answerM5");

var answersum = "";

if ( answer1 !== "")
   answersum += answer1 + ", ";
if ( answer2 !== "")
   answersum += answer2 + ", ";
if ( answer3 !== "")
   answersum += answer3 + ", ";
if ( answer4 !== "")
   answersum += answer4 + ", ";
if ( answer5 !== "")
   answersum += answer5 + ", ";


 window.summary.question.push('Care sunt variabilele din studiu?');
  window.summary.answer.push(answersum);
  window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('1', answersum, true, '', 'Care sunt variabilele din studiu?', 1, 0, 'Scene2_Slide9_1');
}

function Script18()
{
  player = GetPlayer();
answer1 = player.GetVar("answerM1");
answer2 = player.GetVar("answerM2");
answer3 = player.GetVar("answerM3");
answer4 = player.GetVar("answerM4");
answer5 = player.GetVar("answerM5");

var answersum = "";

if ( answer1 !== "")
   answersum += answer1 + ", ";
if ( answer2 !== "")
   answersum += answer2 + ", ";
if ( answer3 !== "")
   answersum += answer3 + ", ";
if ( answer4 !== "")
   answersum += answer4 + ", ";
if ( answer5 !== "")
   answersum += answer5 + ", ";


 window.summary.question.push('Care este variabila independentă ȋn cadrul aceluiași studiu?');
  window.summary.answer.push(answersum);
  window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('2', answersum, true, '', 'Care este variabila independentă ȋn cadrul aceluiași studiu?', 1, 0, 'Scene2_Slide9_2');
}

function Script19()
{
  player = GetPlayer();
answer1 = player.GetVar("answerM1");
answer2 = player.GetVar("answerM2");
answer3 = player.GetVar("answerM3");
answer4 = player.GetVar("answerM4");
answer5 = player.GetVar("answerM5");

var answersum = "";

if ( answer1 !== "")
   answersum += answer1 + ", ";
if ( answer2 !== "")
   answersum += answer2 + ", ";
if ( answer3 !== "")
   answersum += answer3 + ", ";
if ( answer4 !== "")
   answersum += answer4 + ", ";
if ( answer5 !== "")
   answersum += answer5 + ", ";


 window.summary.question.push('Care este variabila independentă ȋn cadrul aceluiași studiu?');
  window.summary.answer.push(answersum);
  window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('2', answersum, false, '', 'Care este variabila independentă ȋn cadrul aceluiași studiu?', 1, 0, 'Scene2_Slide9_2');
}

function Script20()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script21()
{
  player = GetPlayer();
answer1 = player.GetVar("answerM1");
answer2 = player.GetVar("answerM2");
answer3 = player.GetVar("answerM3");
answer4 = player.GetVar("answerM4");
answer5 = player.GetVar("answerM5");

var answersum = "";

if ( answer1 !== "")
   answersum += answer1 + ", ";
if ( answer2 !== "")
   answersum += answer2 + ", ";
if ( answer3 !== "")
   answersum += answer3 + ", ";
if ( answer4 !== "")
   answersum += answer4 + ", ";
if ( answer5 !== "")
   answersum += answer5 + ", ";


 window.summary.question.push('Care este variabila dependentă ȋn cadrul aceluiași studiu??');
  window.summary.answer.push(answersum);
  window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('3', answersum, true, '', 'Care este variabila dependentă ȋn cadrul aceluiași studiu?', 1, 0, 'Scene2_Slide9_3');
}

function Script22()
{
  player = GetPlayer();
answer1 = player.GetVar("answerM1");
answer2 = player.GetVar("answerM2");
answer3 = player.GetVar("answerM3");
answer4 = player.GetVar("answerM4");
answer5 = player.GetVar("answerM5");

var answersum = "";

if ( answer1 !== "")
   answersum += answer1 + ", ";
if ( answer2 !== "")
   answersum += answer2 + ", ";
if ( answer3 !== "")
   answersum += answer3 + ", ";
if ( answer4 !== "")
   answersum += answer4 + ", ";
if ( answer5 !== "")
   answersum += answer5 + ", ";


 window.summary.question.push('Care este variabila dependentă ȋn cadrul aceluiași studiu?');
  window.summary.answer.push(answersum);
  window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('3', answersum, false, '', 'Care este variabila dependentă ȋn cadrul aceluiași studiu?', 1, 0, 'Scene2_Slide9_3');
}

function Script23()
{
  
/*
 *
 * HANGMAN GAME
 *
 */

/*global GetPlayer:false */
var player = GetPlayer();
(function() {
	'use strict';
	window.hangman = {
		//Use capital letters
		questions: ["NOMINAL"],
		activeQuestion: -1,
		question: '',
		chars: [],
		foundChars: {},
		foundLetters: 0,
		alphabet: ["A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z", "Ex"],
		init: function()
		{
			//console.log("init");

		},
		/*
		 * Functions to be called from Storyline
		 */
		// Setup question and the word into letters
		setupQuestions: function(questionnumber)
		{
			this.foundLetters = 0;
			this.activeQuestion = questionnumber;
			this.question = this.questions[this.activeQuestion-1];
			this.chars = this.question.split('');
			this.foundChars = {};
			for (var i = this.alphabet.length - 1; i >= 0; i--)
				player.SetVar("hmChange"+ this.alphabet[i], 0);


		},
		// Check if any letter or the answer is found
		letterPressed: function(letter)
		{
			if (this.foundChars[letter])
				return;
			player.SetVar("hmChangeSet", 0);
			var found = 0;
			for (var i = this.chars.length - 1; i >= 0; i--) {
				var pos = i+1;
				if(this.chars[i] == letter) {
					player.SetVar("hml"  + pos, letter);
					found = 1;
					this.foundLetters++;
					this.foundChars[letter] = true;
					if (this.foundLetters >= this.chars.length) {
						player.SetVar("hmAnswerFound", 1);
					}	
				}
			}
			if( found != 1) {
				//cant put ! in the stroyline var
				if (letter == "!")
					letter = "Ex";

				var isPressed = player.GetVar("hmChange"+letter);
				if( isPressed == 0) {
				var tleft = player.GetVar("hmtleft");
				tleft = tleft -1;
				player.SetVar("hmtleft", tleft);
				player.SetVar("hmChange"+ letter, 1);
				}
			}
		 

			return;
		}
	};
	window.hangman.init();
})();

/*
 *
 * END OF HANGMAN GAME
 *
 */


}

function Script24()
{
  var seconds=3000;
// display();
var blinkTimer = setTimeout(display,400);
var flag = 0;
 
function display(){
	seconds=seconds-1;
	var player = GetPlayer();
	var tleft = player.GetVar("hmtleft");
	player.SetVar("hmtimer",seconds);
	if( tleft != 9) {
		if(flag == 0) {
			player.SetVar("hmBlink","hide");
			flag = 1;
		}
		else {
		player.SetVar("hmBlink","show");
		flag = 0;
		}
		var blinkTimer = setTimeout(display,400);
	}
	else 
	player.SetVar("hmBlink","show");
}
 
}

function Script25()
{
  window.hangman.setupQuestions(1);
}

function Script26()
{
  window.hangman.letterPressed("B");
}

function Script27()
{
  window.hangman.letterPressed("C");
}

function Script28()
{
  window.hangman.letterPressed("D");
}

function Script29()
{
  window.hangman.letterPressed("E");
}

function Script30()
{
  window.hangman.letterPressed("F");
}

function Script31()
{
  window.hangman.letterPressed("G");
}

function Script32()
{
  window.hangman.letterPressed("H");
}

function Script33()
{
  window.hangman.letterPressed("I");
}

function Script34()
{
  window.hangman.letterPressed("J");
}

function Script35()
{
  window.hangman.letterPressed("K");
}

function Script36()
{
  window.hangman.letterPressed("L");
}

function Script37()
{
  window.hangman.letterPressed("M");
}

function Script38()
{
  window.hangman.letterPressed("N");
}

function Script39()
{
  window.hangman.letterPressed("O");
}

function Script40()
{
  window.hangman.letterPressed("P");
}

function Script41()
{
  window.hangman.letterPressed("Q");
}

function Script42()
{
  window.hangman.letterPressed("R");
}

function Script43()
{
  window.hangman.letterPressed("S");
}

function Script44()
{
  window.hangman.letterPressed("T");
}

function Script45()
{
  window.hangman.letterPressed("U");
}

function Script46()
{
  window.hangman.letterPressed("V");
}

function Script47()
{
  window.hangman.letterPressed("W");
}

function Script48()
{
  window.hangman.letterPressed("X");
}

function Script49()
{
  window.hangman.letterPressed("Y");
}

function Script50()
{
  window.hangman.letterPressed("Z");
}

function Script51()
{
  window.hangman.letterPressed("!");
}

function Script52()
{
  window.hangman.letterPressed("A");
}

function Script53()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script54()
{
    window.summary.question.push('Ȋn acest studiu, care nivel de măsurare este cel potrivit pentru tipul de dietă?');
  window.summary.answer.push('Nominal');
  window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('4', 'Nominal', true, '', 'Ȋn acest studiu, care nivel de măsurare este cel potrivit pentru tipul de dietă?', 1, 0, 'Scene2_Slide10');
}

function Script55()
{
    window.summary.question.push('Ȋn acest studiu, care nivel de măsurare este cel potrivit pentru tipul de dietă?');
  window.summary.answer.push('');
  window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('4', '', false, '', 'Ȋn acest studiu, care nivel de măsurare este cel potrivit pentru tipul de dietă?', 1, 0, 'Scene2_Slide10');
}

function Script56()
{
  var seconds=4;
//setTimeout(display,1000);
display();
 
function display(){
seconds=seconds-1;
var player = GetPlayer();
player.SetVar("hmcready",seconds);
var cready = player.GetVar("hmcready");
if ( cready == 0) {
player.SetVar("hmcready", "Go!");
setTimeout(display,1000);
}
else if ( cready == -1) {
player.SetVar("hmcready", "next");
}
else {
setTimeout(display,1000);
}
}
}

function Script57()
{
  window.hangman.setupQuestions(1);
var seconds=4;
//setTimeout(display,1000);
display();
 
function display(){
seconds=seconds-1;
var player = GetPlayer();
player.SetVar("hmcready",seconds);
var cready = player.GetVar("hmcready");
if ( cready == 0) {
player.SetVar("hmcready", "Go!");
setTimeout(display,1000);
}
else if ( cready == -1) {
player.SetVar("hmcready", "next");
setTimeout(display,1000);
}
else {
setTimeout(display,1000);
}
}
}

function Script58()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script59()
{
  var player = GetPlayer();  
var answer = player.GetVar('answer');
window.summary.question.push('In acest studiu, ȋn baza cărui nivel de măsurare este cuantificată greutatea pierdută? ');
window.summary.answer.push(answer);
window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('5', answer, true, '', 'In acest studiu, ȋn baza cărui nivel de măsurare este cuantificată greutatea pierdută?  ', 1, 0, 'Scene2_Slide11_1');
}

function Script60()
{
  var player = GetPlayer();  
var answer = player.GetVar('answer');
window.summary.question.push('In acest studiu, ȋn baza cărui nivel de măsurare este cuantificată greutatea pierdută?');
window.summary.answer.push(answer);
window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('5', answer, false, '', 'In acest studiu, ȋn baza cărui nivel de măsurare este cuantificată greutatea pierdută?  ', 1, 0, 'Scene2_Slide11_1');
}

function Script61()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script62()
{
    window.summary.question.push('Ce fel de plan sugearează acest studiu?');
  window.summary.answer.push('diferențierile pe grupe');
  window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('6', 'diferențierile pe grupe', true, '', 'Ce fel de plan sugearează acest studiu? ', 1, 0, 'Scene2_Slide11_2');
}

function Script63()
{
    window.summary.question.push('Ce fel de plan sugearează acest studiu?');
  window.summary.answer.push('o asociere ȋntre variabile');
  window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('6', 'o asociere ȋntre variabile', false, '', 'Ce fel de plan sugearează acest studiu? ', 1, 0, 'Scene2_Slide11_2');
}

function Script64()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script65()
{
    window.summary.question.push('Care dintre seturile de date neprelucrate de mai jos este cel corect pentru a testa datele tale?');
  window.summary.answer.push('Dataset1');
  window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('10', 'Dataset1', true, '', 'Care dintre seturile de date neprelucrate de mai jos este cel corect pentru a testa datele tale? ', 1, 0, 'Scene2_Slide12');
}

function Script66()
{
    window.summary.question.push('Care dintre seturile de date neprelucrate de mai jos este cel corect pentru a testa datele tale?');
  window.summary.answer.push('Dataset2');
  window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('10', 'Dataset2', false, '', 'Care dintre seturile de date neprelucrate de mai jos este cel corect pentru a testa datele tale? ', 1, 0, 'Scene2_Slide12');
}

function Script67()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script68()
{
  window.summary.question.push('Ce fel de reprezentare grafica a datelor doresti sa vezi?');
window.summary.answer.push('Grafic box-plot');
window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('11', 'Grafic box-plot', true, '', 'Ce fel de reprezentare grafica a datelor doresti sa vezi? ', 1, 0, 'Scene2_Slide13');

}

function Script69()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script70()
{
  window.summary.question.push('Ce fel de reprezentare grafica a datelor doresti sa vezi?');
window.summary.answer.push('Histogramă de distribuți.e. a frecvențelor');
window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('11', 'Histogramă de distribuți.e. a frecvențelor', true, '', 'Ce fel de reprezentare grafica a datelor doresti sa vezi? ', 1, 0, 'Scene2_Slide13');
}

function Script71()
{
  window.summary.question.push('Ce fel de reprezentare grafica a datelor doresti sa vezi?');
window.summary.answer.push('Diagramă de ȋmprăștiere');
window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('11', 'Diagramă de ȋmprăștiere', false, '', 'Ce fel de reprezentare grafica a datelor doresti sa vezi? ', 1, 0, 'Scene2_Slide13');
}

function Script72()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script73()
{
  window.summary.question.push('Histograma arată că mediana legată de pierderea ȋn greutate a participanților aflați la dieta distrugatoare de grasimi are o frecvență mai mare decât a celor aflați la dieta bazată pe upțini carbohidrați.');
window.summary.answer.push('Adevărat');
window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('13', 'Adevărat', true, '', 'Histograma arată că mediana legată de pierderea ȋn greutate a participanților aflați la dieta distrugatoare de grasimi are o frecvență mai mare decât a celor aflați la dieta bazată pe upțini carbohidrați. ', 1, 0, 'Scene2_Slide14_1');
}

function Script74()
{
  window.summary.question.push('Histograma arată că mediana legată de pierderea ȋn greutate a participanților aflați la dieta distrugatoare de grasimi are o frecvență mai mare decât a celor aflați la dieta bazată pe upțini carbohidrați.');
window.summary.answer.push('Fals');
window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('13', 'Fals', false, '', 'Histograma arată că mediana legată de pierderea ȋn greutate a participanților aflați la dieta distrugatoare de grasimi are o frecvență mai mare decât a celor aflați la dieta bazată pe upțini carbohidrați. ', 1, 0, 'Scene2_Slide14_1');
}

function Script75()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script76()
{
  window.summary.question.push('Histograma arată că participanții care au ținut dieta distrugătoare de grăsimi au demonstrat o variabilitate mai mare legată de pierderea ȋn greutate față de cei care au ținut dieta bazată pe upțini carbohidrați.');
window.summary.answer.push('Fals');
window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('14', 'Fals', true, '', 'Histograma arată că participanții care au ținut dieta distrugătoare de grăsimi au demonstrat o variabilitate mai mare legată de pierderea ȋn greutate față de cei care au ținut dieta bazată pe upțini carbohidrați.', 1, 0, 'Scene2_Slide14_2');
}

function Script77()
{
  window.summary.question.push('Histograma arată că participanții care au ținut dieta distrugătoare de grăsimi au demonstrat o variabilitate mai mare legată de pierderea ȋn greutate față de cei care au ținut dieta bazată pe upțini carbohidrați.');
window.summary.answer.push('Adevărat');
window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('14', 'Adevărat', false, '', 'Histograma arată că participanții care au ținut dieta distrugătoare de grăsimi au demonstrat o variabilitate mai mare legată de pierderea ȋn greutate față de cei care au ținut dieta bazată pe upțini carbohidrați.', 1, 0, 'Scene2_Slide14_2');
}

function Script78()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script79()
{
  window.summary.question.push('Alege graficul boxplot potrivit acestei histograme');
window.summary.answer.push('Grafic1');
window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('15', 'Grafic1', true, '', 'Alege graficul boxplot potrivit acestei histograme', 1, 0, 'Scene2_Slide14_3');
}

function Script80()
{
  window.summary.question.push('Alege graficul boxplot potrivit acestei histograme');
window.summary.answer.push('Grafic2');
window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('15', 'Grafic2', false, '', 'Alege graficul boxplot potrivit acestei histograme', 1, 0, 'Scene2_Slide14_3');
}

function Script81()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script82()
{
  window.summary.question.push('Pentru a testa ipoteza nu va exista o diferență ȋntre cei aflați la dieta bazată pe upțini carbohidrați si cei aflați la dieta distrugătoare de grăsimi cu privire la pierderea ȋn greutate. Ce test statistic ar trebui folosit?');
window.summary.answer.push('Testul t pentru eșantioane independente');
window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('16', 'Testul t pentru eșantioane independente', true, '', 'To test the hypothesis that Pentru a testa ipoteza nu va exista o diferență ȋntre cei aflați la dieta bazată pe upțini carbohidrați si cei aflați la dieta distrugătoare de grăsimi cu privire la pierderea ȋn greutate.” Ce test statistic ar trebui folosit?', 1, 0, 'Scene2_Slide14_4');
}

function Script83()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script84()
{
  window.summary.question.push('Pentru a testa ipoteza nu va exista o diferență ȋntre cei aflați la dieta bazată pe upțini carbohidrați si cei aflați la dieta distrugătoare de grăsimi cu privire la pierderea ȋn greutate. Ce test statistic ar trebui folosit?');
window.summary.answer.push('Testul U Mann Whitney ');
window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('16', 'Testul U Mann Whitney ', true, '', 'Pentru a testa ipoteza nu va exista o diferență ȋntre cei aflați la dieta bazată pe upțini carbohidrați si cei aflați la dieta distrugătoare de grăsimi cu privire la pierderea ȋn greutate. Ce test statistic ar trebui folosit?', 1, 0, 'Scene2_Slide14_4');
}

function Script85()
{
  window.summary.question.push('Pentru a testa ipoteza nu va exista o diferență ȋntre cei aflați la dieta bazată pe upțini carbohidrați si cei aflați la dieta distrugătoare de grăsimi cu privire la pierderea ȋn greutate. Ce test statistic ar trebui folosit?');
window.summary.answer.push('Testul t cu măsuri repetate');
window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('16', 'Testul t cu măsuri repetate', false, '', 'Pentru a testa ipoteza nu va exista o diferență ȋntre cei aflați la dieta bazată pe upțini carbohidrați si cei aflați la dieta distrugătoare de grăsimi cu privire la pierderea ȋn greutate. Ce test statistic ar trebui folosit?', 1, 0, 'Scene2_Slide14_4');
}

function Script86()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script87()
{
  window.summary.question.push('Valorile din tabel de 4,303 și 0,9428 arată că:');
window.summary.answer.push('cei care au ținut dieta bazată pe upțini carbohidrați au demonstrat un o variabilitate mai mare față legată de pierderea ȋn greutate de cei care au ținut dieta distrugătoare de grăsimi.');
window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('17', 'cei care au ținut dieta bazată pe upțini carbohidrați au demonstrat un o variabilitate mai mare față legată de pierderea ȋn greutate de cei care au ținut dieta distrugătoare de grăsimi.', false, '', 'Valorile din tabel de 4,303 și 0,9428 arată că:', 1, 0, 'Scene2_Slide14_5');
}

function Script88()
{
  window.summary.question.push('Valorile din tabel de 4,303 și 0,9428 arată că:');
window.summary.answer.push('cei care au ținut dieta bazată pe upțini carbohidrați au pierdut mai mult ȋn greutate față de cei care au ținut dieta distrugătoare de grăsimi.');
window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('17', 'cei care au ținut dieta bazată pe upțini carbohidrați au pierdut mai mult ȋn greutate față de cei care au ținut dieta distrugătoare de grăsimi.', false, '', 'Valorile din tabel de 4,303 și 0,9428 arată că:', 1, 0, 'Scene2_Slide14_5');
}

function Script89()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script90()
{
  window.summary.question.push('Tabelul arată că, ȋn medie, cei care au ținut dieta distrugătoare de grăsimi au pierdut mai mult ȋn greutate față de cei care au ținut dieta bazată pe upțini carbohidrați..');
window.summary.answer.push('Adrevat');
window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('18', 'Adrevat', true, '', 'Tabelul arată că, ȋn medie, cei care au ținut dieta distrugătoare de grăsimi au pierdut mai mult ȋn greutate față de cei care au ținut dieta bazată pe upțini carbohidrați.', 1, 0, 'Scene2_Slide14_6');
}

function Script91()
{
  window.summary.question.push('Tabelul arată că, ȋn medie, cei care au ținut dieta distrugătoare de grăsimi au pierdut mai mult ȋn greutate față de cei care au ținut dieta bazată pe upțini carbohidrați.');
window.summary.answer.push('Fals');
window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('18', 'Fals', false, '', 'Tabelul arată că, ȋn medie, cei care au ținut dieta distrugătoare de grăsimi au pierdut mai mult ȋn greutate față de cei care au ținut dieta bazată pe upțini carbohidrați.', 1, 0, 'Scene2_Slide14_6');
}

function Script92()
{
  
/*
 *
 * TIC-TAC-TOE GAME
 *
 */

/*global GetPlayer:false */
var player = GetPlayer();
(function() {
	'use strict';
	var state = {
		READY: 0,
		RIGHT: 1,
		WRONG: 2
	};
	var validValues = [
		// Rows
		1  | 2   | 4,
		8  | 16  | 32,
		64 | 128 | 256,
		// Columns
		1  | 8   | 64,
		2  | 16  | 128,
		4  | 32  | 256
	];
	window.ttt = {
		questions: [
			{
				text: "Histograma ne arată că pierderea în greutate mediană a fost mai mare pentru participanţii la dieta Distrugătoare de grăsime decât pentru cei aflaţi la dieta bazată pe puţini carbohidraţi.",
				wrong: "Adevărat, histograma ne arată ca pierderea în greutate mediană a fost mai mare pentru participanţii la dieta Distrugătoare de grăsime decât pentru cei aflaţi la dieta bazată pe puţini carbohidraţi.",
				answer: true
			},
			{
				text: "Histograma ne arată că a existat un grad mai mare de variabilitate legat de scăderea în greutate pentru participanţii la dieta Distrugătoare de grăsime decât pentru cei aflaţi la dieta bazată pe puţini carbohidraţi.",
				wrong: "Fals, Histograma ne arata ca a existat un grad mai mare de variabilitate legat de scaderea in greutate pentru participantii la dieta Distrugatoarea de grasime decat pentru cei aflati la dieta bazata pe putini carbohidrati.",
				answer: false
			},
			{
				text: "Graficul B prezintă acelaşi set de date ca şi histograma.",
				wrong: "Fals, nu există valori negative pentru pierderea în greutate în graficul B sugerând că acest grafic este incorect.",
				answer: false
			},
			{
				text: "Histograma ne arată că unii participanţi la dieta Distrugătoare de grăsime chiar au luat in greutate.",
				wrong: "Fals, histograma ne arată că unii participanţi la dieta Distrugătoare de grăsime chiar au luat in greutate.",
				answer: false
			},
			{
				text: "Graficul A ne arată că a existat un grad mai mare de variabilitate legat de scăderea în greutate pentru participanţii  la dieta bazată pe puţini carbohidraţi decât pentru cei aflaţi la dieta Distrugătoare de grăsime",
				wrong: "Adevărat, graficul  ne arată că a existat un grad mai mare de variabilitate legată de scăderea în greutate pentru participanţii la dieta bazată pe puţini carbohidraţi decât pentru cei aflaţi la dieta Distrugătoare de grăsime",
				answer: true
			},
			{
				text: "Tabelul de rezultate ne arată că pierderea medie saptamânală de greutate a celor aflaţi la dieta bazată pe puţini carbohidraţi a fost de 4,303 kg",
				wrong: "Fals, valoarea de 4,30 ne arată deviaţia standard pentru cei aflaţi la dieta bazată pe puţini carbohidraţi ",
				answer: false
			},
			{
				text: "Tabelul de rezultate ne arată că în medie cei aflaţi la dieta Distrugătoare de grăsime au pierdut mai mult în greutate faţă de cei aflaţi la dieta bazată pe puţini carbohidraţi",
				wrong: "Adevărat, tabelul de rezultate ne arată că în medie cei aflaţi la dieta Distrugătoare de grăsime au pierdut mai mult in greutate(4,85kg) faţă de cei aflaţi la dieta bazată pe puţini carbohidraţi(3,22kg)",
				answer: true
			},
			{
				text: "Testul Levene pentru egalitatea dispersiilor sugerează că dispersiile celor două grupuri sunt egale",
				wrong: "Fals, testul Levene pentru egalitatea dispersiilor sugerează că deviaţia standard pentru cei aflaţi la dieta săraca în carbohidraţi era mai mare decât a indivizilor aflaţi la dieta Distrugătoare de grăsime (F=30,696, p=.000)",
				answer: false
			},
			{
				text: "Valoarea pragului de semnificaţie în cazul testului t ne arată că ar trebui respinsă ipoteza nulă",
				wrong: "Fals, valoarea pragului de semnificaţie ,051(variaţiile egale nu sunt luate în calcul) inseamnă că ar trebui sa acceptăm ipoteza nulă’",
				answer: false
			}
		],
		activeQuestion: -1,
		totalValue: 0,
		init: function()
		{
			if (this.questions.length !== 9) {
				alert("Question count missmatch! Got " + this.questions.length + " expected 9");
				return;
			}
			var value = 1;
			// Setup the Qs with redundant info

var length = this.questions.length,
element = null;
for (var i = 0; i < length; i++) {
element = this.questions[i];
element .id = i;
element .value = value;
element .state = state.READY;
value *= 2;
}
		},
		updateQState: function(question, state)
		{
			question.state = state;
			player.SetVar('tttQuestionState' + question.id, state);
		},
		/*
		 * Functions to be called from Storyline
		 */
		// Resets all the question vars to ready
		setupQuestions: function()
		{
			this.activeQuestion = null;
			this.totalValue = 0;
			player.SetVar('tttQuestionText', '');
			player.SetVar('tttSlideSolved', 0);
var length = this.questions.length,
element = null;
for (var i = 0; i < length; i++) {
element = this.questions[i];
this.updateQState(element , state.READY);
}

		},
		// For when the user picks a question
		chooseQuestion: function(quid)
		{
			var question = this.questions[quid];
			if (question.state !== state.READY)
				return;
			this.activeQuestion = question;
			player.SetVar('tttQuestionText', question.text);
		},
		// Check if the answer is correctus
		checkAnswer: function(choice)
		{
			// Get what we're talkin about
			var question = this.activeQuestion;
			// Hide the question window
var questionText = player.GetVar('tttQuestionText');
			player.SetVar('tttQuestionText', '');
			// Reset the wrong var so we can trigger it if necessary
			player.SetVar('tttQuestionWrong', '');
			// Determine failure
			var choice_ = (choice == 'true') ? true : false;
			// If you pass you're wrong and stupid
			if (choice === 'pass' || choice_ !== question.answer) {
				this.updateQState(question, state.WRONG);
				// Pop up the "no u stupid" box
				player.SetVar('tttQuestionWrong', question.wrong);

window.summary.question.push(questionText);
window.summary.answer.push(choice_);
window.summary.correct.push('Incorrect');

				return;
			}
			// success!
window.summary.question.push(questionText);
window.summary.answer.push(question.answer);
window.summary.correct.push('Correct');
			this.updateQState(question, state.RIGHT);
			this.totalValue |= question.value;
			// Check if we've won
var length = validValues.length,
value = null;
for (var i = 0; i < length; i++) {
value = validValues[i];
if  ( (this.totalValue & value) === value )
player.SetVar('tttSlideSolved', 1);
}
		}
	};
	window.ttt.init();
})();

/*
 *
 * END OF TIC-TAC-TOE GAME
 *
 */


}

function Script93()
{
  window.ttt.setupQuestions();
}

function Script94()
{
  window.ttt.setupQuestions();
}

function Script95()
{
  window.ttt.chooseQuestion(0);
}

function Script96()
{
  window.ttt.chooseQuestion(1);
}

function Script97()
{
  window.ttt.chooseQuestion(2);
}

function Script98()
{
  window.ttt.chooseQuestion(3);
}

function Script99()
{
  window.ttt.chooseQuestion(4);
}

function Script100()
{
  window.ttt.chooseQuestion(5);
}

function Script101()
{
  window.ttt.chooseQuestion(6);
}

function Script102()
{
  window.ttt.chooseQuestion(7);
}

function Script103()
{
  window.ttt.chooseQuestion(8);
}

function Script104()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}

lmsAPI.RecordFillInInteraction('12', 'Completed', true, '', 'Microscope Game ', 1, 0, 'Scene2_Slide15');







}

function Script105()
{
  lmsAPI.RecordFillInInteraction('12', '', false, '', 'Microscope Game ', 1, 0, 'Scene2_Slide15');
}

function Script106()
{
  var eyesshut = 100, eyesopen = 10000, inblink = false;
var player = GetPlayer();
function blink(){
  inblink = !inblink;
  if (inblink) {
    player.SetVar('blinkState', 'hide');
    setTimeout(blink, eyesshut + Math.random() * 40);
  } else {
    player.SetVar('blinkState', 'show');
    setTimeout(blink, eyesopen + Math.random() * 500);
  }
}

blink(); 
}

function Script107()
{
  window.ttt.checkAnswer('true');
}

function Script108()
{
  window.ttt.checkAnswer('false');
}

