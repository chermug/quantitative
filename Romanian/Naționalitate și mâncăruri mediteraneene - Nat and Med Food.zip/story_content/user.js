function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6MUJw3zbBta":
        Script1();
        break;
      case "5liVbXq2EjC":
        Script2();
        break;
      case "5nScrZVjTcP":
        Script3();
        break;
      case "63Np4AOKxsS":
        Script4();
        break;
      case "5s5FBtoVP0w":
        Script5();
        break;
      case "6UacGRcBYvG":
        Script6();
        break;
      case "5XcIdieenTq":
        Script7();
        break;
      case "5hBUhD6mE9T":
        Script8();
        break;
      case "5eRVlH8Go8z":
        Script9();
        break;
      case "5WCQIuS3Vnd":
        Script10();
        break;
      case "6H1ZqDm10yq":
        Script11();
        break;
      case "6rSGV0xSt0d":
        Script12();
        break;
      case "6r05L2iLtHA":
        Script13();
        break;
      case "5qIN1m9lXzK":
        Script14();
        break;
      case "6gjBoFDx792":
        Script15();
        break;
      case "65FOjTDi2Te":
        Script16();
        break;
      case "5d59qcxQ0Px":
        Script17();
        break;
      case "5mGCAHXWKT5":
        Script18();
        break;
      case "5qQLzNxu4hi":
        Script19();
        break;
      case "5zZGASaAQvv":
        Script20();
        break;
      case "5qMNm5OH4cu":
        Script21();
        break;
      case "6p5PWGZAEe4":
        Script22();
        break;
      case "6Kx1IxReKDb":
        Script23();
        break;
      case "5wV154vCB8Q":
        Script24();
        break;
      case "5uRyW29YUUA":
        Script25();
        break;
      case "6lLzhEEests":
        Script26();
        break;
      case "6cmzWvIbj0i":
        Script27();
        break;
      case "6A5PfDolIbg":
        Script28();
        break;
      case "6CASeLKskBT":
        Script29();
        break;
      case "6RBeQJZoGu3":
        Script30();
        break;
      case "5roFYSV9hsw":
        Script31();
        break;
      case "6D9ysmMJTkw":
        Script32();
        break;
      case "68jFLJzmA7H":
        Script33();
        break;
      case "5phNVwCqeE2":
        Script34();
        break;
      case "6h44NSyNG1d":
        Script35();
        break;
      case "5VMvdOSIcKF":
        Script36();
        break;
      case "658Cj4KBNEt":
        Script37();
        break;
      case "6OkoFShyxO1":
        Script38();
        break;
      case "6BaCal49md0":
        Script39();
        break;
      case "6Am86UAc6gZ":
        Script40();
        break;
      case "6MhX7xKoHkC":
        Script41();
        break;
      case "64Hia8GdnyK":
        Script42();
        break;
      case "6Yfp2vfr6mT":
        Script43();
        break;
      case "5ePhGpE7E2b":
        Script44();
        break;
      case "6CSSrlPTQrP":
        Script45();
        break;
      case "5omTiAgomkX":
        Script46();
        break;
      case "6GaKae0EaH3":
        Script47();
        break;
      case "681KODeerAh":
        Script48();
        break;
      case "6nU6hZyUAi2":
        Script49();
        break;
      case "6ZSowU4glOd":
        Script50();
        break;
      case "6J4QrXblAmi":
        Script51();
        break;
      case "6QLmkUvjzbG":
        Script52();
        break;
      case "5YdtmMipVRp":
        Script53();
        break;
      case "6HQ4Sah4WeW":
        Script54();
        break;
      case "6KOGM6JukU7":
        Script55();
        break;
      case "61eBGytAyOx":
        Script56();
        break;
      case "6l8WWxRBkso":
        Script57();
        break;
      case "5ghVsNHPRRE":
        Script58();
        break;
      case "6a7dRxgGRA1":
        Script59();
        break;
      case "6RtbFfuJg0X":
        Script60();
        break;
      case "5jNF4nVvyFK":
        Script61();
        break;
      case "6TXy5CQZjKV":
        Script62();
        break;
      case "61t1wN5VetX":
        Script63();
        break;
      case "6iUOBAg2gih":
        Script64();
        break;
      case "5XR7UiZBPA0":
        Script65();
        break;
      case "5gYvwVouDoU":
        Script66();
        break;
      case "6hKfblZFeMy":
        Script67();
        break;
      case "5uEJQfRPpXU":
        Script68();
        break;
      case "68m7IMIkX07":
        Script69();
        break;
      case "6BFnVO8qWMG":
        Script70();
        break;
      case "5vNGOqUeVJi":
        Script71();
        break;
      case "6LV46Y2aAv8":
        Script72();
        break;
      case "5l3uAGl1Gh9":
        Script73();
        break;
      case "6Dbf0M92mos":
        Script74();
        break;
      case "6ToFSTnBM7c":
        Script75();
        break;
      case "67HkkVJJmSP":
        Script76();
        break;
      case "6Ao563XNKXa":
        Script77();
        break;
      case "6oplbm9ag6l":
        Script78();
        break;
      case "634Sc2J8Vql":
        Script79();
        break;
      case "5b1Ay4cocDb":
        Script80();
        break;
      case "6JsrNgW4gCW":
        Script81();
        break;
      case "5yvM71jYRNS":
        Script82();
        break;
      case "5r4NAPtPAUb":
        Script83();
        break;
      case "6M6QY22QJ4R":
        Script84();
        break;
      case "6IEomJr2SVY":
        Script85();
        break;
      case "6BK0UfT2KFh":
        Script86();
        break;
      case "6bsupiMZKfN":
        Script87();
        break;
      case "6r7zeliybG7":
        Script88();
        break;
      case "5xD9mm5FA0h":
        Script89();
        break;
      case "5mn6hTZ9E5o":
        Script90();
        break;
      case "6VScGb42VIc":
        Script91();
        break;
      case "5u8oVxj6jv8":
        Script92();
        break;
      case "65OgCs5NDRQ":
        Script93();
        break;
      case "5mD0VXwHcRI":
        Script94();
        break;
      case "6nFhkrqgPyq":
        Script95();
        break;
      case "6S2UIWQCkBf":
        Script96();
        break;
      case "6hRKBur8xVJ":
        Script97();
        break;
      case "5lskrPt2qMG":
        Script98();
        break;
      case "5WTKcReYDnB":
        Script99();
        break;
      case "6qpV7goJwDb":
        Script100();
        break;
      case "5jsvzb8XeX9":
        Script101();
        break;
      case "5qmBaHEZXuM":
        Script102();
        break;
      case "6TBdwosjPKl":
        Script103();
        break;
      case "6m71PfudHLy":
        Script104();
        break;
  }
}

function Script1()
{
  
/*
 *
 *   ACHIEVEMENTS
 *
 */

/*global GetPlayer:false */
var player = GetPlayer();
(function() {
	'use strict';
	window.achievements = {
		achievements: [
			{
				name: "First Question",
				desc: "You have successfully answered first question correctly.",
				advance: function()
				{
					this.completed = true;
				}
			},
			{
				name: "Three in a row",
				desc: "You have successfully answered three questions correctly in a row.",
				rowCounter: 0,
				advance: function()
				{
					var rowCounter = player.GetVar('ach3Question');
					if (rowCounter  == 3)
						this.completed = true;
				}
			},
			{
				name: "Hypothesis",
				desc: "You have successfully answered all hypothesis questions without any wrong answer.",
				rowCounter: 0,
				advance: function()
				{
					var isHypothesis = player.GetVar('achHypothesis');
					console.log(isHypothesis);
					if (isHypothesis  == 1)
						this.completed = true;
				}
			},
			{
				name: "All",
				desc: "You have successfully answered all of the questions correct.",
				rowCounter: 0,
				advance: function()
				{
					var isAll = player.GetVar('achAll');
					console.log(isAll);
					if (isAll  == 1)
						this.completed = true;
				}
			},
			{
				name: "",
				desc: "",
				rowCounter: 0,
				advance: function()
				{
					//In each case it will earn something
					this.completed = true;
				}
			},

		],
		completedThisRound: [],

		init: function()
		{
			for (var i = 0; i < this.achievements.length; ++i) {
				this.achievements[i].id = i;
			}
		},
		// public
		advanceAchievement: function(achid)
		{
			var ach = this.achievements[achid];
			if (!ach)
				return;
			if (ach.completed)
				return;
			ach.advance();
			if (!ach.completed)
				return;
			this.completedThisRound.push(ach);
		},
		checkForAchievements: function()
		{
			return this.completedThisRound.length > 0;
		},
		resetAchievementVars: function()
		{
			player.SetVar('achievementActive', 0);
			player.SetVar('achievementName', '');
			player.SetVar('achievementDesc', '');
			player.SetVar('achivementId', -1);
		},
		setupAchievementVars: function()
		{
			var ach = this.completedThisRound.shift();
			player.SetVar('achievementActive', 1);
			player.SetVar('achievementName', ach.name);
			player.SetVar('achievementDesc', ach.desc);
			player.SetVar('achivementId', ach.id);
			player.SetVar('achievementUnlocked' + ach.id, 1);
		},
		// public
		doEverythingAtOnce: function()
		{
			this.resetAchievementVars();
			if (this.checkForAchievements())
				this.setupAchievementVars();

		}
	};
	window.achievements.init();
})();

/*
 *
 *  END OF ACHIEVEMENTS 
 *
 */

}

function Script2()
{
  var eyesshut = 100, eyesopen = 10000, inblink = false;
var player = GetPlayer();
var isPopUp = player.GetVar("isPopUp");
function blink(){
  inblink = !inblink;
 if (isPopUp == 1) {
 setTimeout(blink, 100);
}
  else if (inblink) {
    player.SetVar('blinkState', 'hide');
    setTimeout(blink, eyesshut + Math.random() * 100);
  } else {
    player.SetVar('blinkState', 'show');
    setTimeout(blink, eyesopen + Math.random() * 1000);
  }
}

blink(); 

window.summary = {question: [], answer: [], correct: []}; 
}

function Script3()
{
  var player = GetPlayer();
player.SetVar("answerM1", "");
player.SetVar("answerM2", "");
player.SetVar("answerM3", "");
player.SetVar("answerM4", "");
player.SetVar("answerM5", "");
player.SetVar("answerM6", "");
}

function Script4()
{
   window.summary.question.push('Formulate the null-hypothesis - Part1');
  window.summary.answer.push('va exista o diferență');
  window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('7', 'va exista o diferență', false, '', 'Null-hypothesis Part 1 ', 1, 0, 'Scene2_Slide7_1');
}

function Script5()
{
  player = GetPlayer();
answer1 = player.GetVar("answerM4");
answer2 = player.GetVar("answerM3");

 window.summary.question.push('Formulate the null-hypothesis - Part2');
  window.summary.answer.push(answer1 + answer2);
  window.summary.correct.push('Incorrect');


var answer = answer1+answer2;
lmsAPI.RecordFillInInteraction('8', answer, false, '', 'Null-hypothesis Part 2 ', 1, 0, 'Scene2_Slide7_2');
}

function Script6()
{
  player = GetPlayer();
answer1 = player.GetVar("answerM5");
answer2 = player.GetVar("answerM6");

 window.summary.question.push('Formulate the null-hypothesis  - Part3');
  window.summary.answer.push(answer1 + answer2);
  window.summary.correct.push('Incorrect');

var answer = answer1+answer2;
lmsAPI.RecordFillInInteraction('9', answer, false, '', 'Null-hypothesis Part 3 ', 1, 0, 'Scene2_Slide7_3');
}

function Script7()
{
    window.summary.question.push('Formulate the null-hypothesis by selecting the correct sentence parts - Part1');
  window.summary.answer.push('nu va exista o diferență');
  window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('7', 'nu va exista o diferență', true, '', 'Null-hypothesis Part 1 ', 1, 0, 'Scene2_Slide7_1');
}

function Script8()
{
    window.summary.question.push('Formulate the null-hypothesis by selecting the correct sentence parts - Part2');
  window.summary.answer.push('ȋntre copiii spanioli și cei britanici');
  window.summary.correct.push('Correct');


lmsAPI.RecordFillInInteraction('8', 'ȋntre copiii spanioli și cei britanici', true, '', 'Null-hypothesis Part 2 ', 1, 0, 'Scene2_Slide7_2');
}

function Script9()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script10()
{
    window.summary.question.push('Formulate the null-hypothesis - Part3');
  window.summary.answer.push('ȋn numărul de mâncăruri mediteraneene consumate');
  window.summary.correct.push('Correct');

var answer = 'ȋn numărul de mâncăruri mediteraneene consumate';
lmsAPI.RecordFillInInteraction('9', answer, true, '', 'Null-hypothesis Part 3 ', 1, 0, 'Scene2_Slide7_3');
}

function Script11()
{
  var player = GetPlayer();
var score = player.GetVar('score');
var rank;
window.clearTimeout(timeVar);

//Score
if( score >= 1500 )
 rank = "A";
else if( score >= 1400 )
 rank = "B";
else if( score >= 1300 )
 rank = "C";
else if( score >= 1200 )
 rank = "D";
else 
 rank = "E";

player.SetVar('rank', rank);

//Time
function zeroPad(num, places) {
  var zero = places - num.toString().length + 1;
  return Array(+(zero > 0 && zero)).join("0") + num;
}

var time = player.GetVar('time');

var minutes = Math.floor(time / 60);
var seconds = time - minutes * 60;

minutes  = zeroPad(minutes, 2);
seconds  = zeroPad(seconds, 2);

var NewTime = minutes+":"+seconds;
player.SetVar('timeLast', NewTime );


player.SetVar("answerM1", "");
player.SetVar("answerM2", "");
player.SetVar("answerM3", "");
player.SetVar("answerM4", "");
player.SetVar("answerM5", "");
player.SetVar("answerM6", "");

lmsAPI.RecordFillInInteraction('17', score, true, '', 'Score ', 1, 0, 'Scene2_Slide8');
lmsAPI.RecordFillInInteraction('18', NewTime, true, '', 'Playing Time ', 1, 0, 'Scene2_Slide8');

lmsAPI.SetPassed();
player = GetPlayer();
var correct = player.GetVar("correctcounter");
var question = player.GetVar("questioncounter");

var score = ( correct / question ) * 100;
score =  Math.round( Number(score));
player.SetVar("calculatedscore", score);
player.SetVar("calculatedcorrect",correct);
player.SetVar("calculatedquestion",question);

lmsAPI.SetScore(score,100,0);

lmsAPI.RecordFillInInteraction('19', playerName, true, '', 'Player Name ', 1, 0, 'Scene2_Slide8');

lmsAPI.RecordFillInInteraction('20', rank, true, '', 'Rank ', 1, 0, 'Scene2_Slide8');



}

function Script12()
{
  var answersum = "";

if ( player.GetVar('answerM1') !== "")
   answersum +=  player.GetVar('answerM1') + ", ";
if ( player.GetVar('answerM2') !== "")
   answersum +=  player.GetVar('answerM2') + ", ";
if ( player.GetVar('answerM3') !== "")
   answersum +=  player.GetVar('answerM3') + ", ";
if ( player.GetVar('answerM4') !== "")
   answersum +=  player.GetVar('answerM4') + ", ";

lmsAPI.RecordFillInInteraction('21', answersum, true, '', 'Achievements ', 1, 0, 'Scene2_Slide8');
}

function Script13()
{
  var player = GetPlayer();
var formHTML = "<style>table {border-collapse:collapse;margin-top:20px;color:#373737} table, tr, td {padding: 10px;}tr:nth-child(even) {background:#E3F3EF; }tr:nth-child(odd) {background:#C7F1E6; }tr.header{background:#008A6E;color:white;font-weight:bold; }.logo { margin-bottom:10px;} .name {text-transform:uppercase;font-size:24px;font-weight:bold;color:#008A6E;}.label {font-weight:bold;}.logo span {font-size:27px; font-weight: bold; text-decoration:underline; color:#373737 } .logo img {float:right;}</style>";

var answersum = "";

if ( player.GetVar('answerM1') !== "")
   answersum +=  player.GetVar('answerM1') + ", ";
if ( player.GetVar('answerM2') !== "")
   answersum +=  player.GetVar('answerM2') + ", ";
if ( player.GetVar('answerM3') !== "")
   answersum +=  player.GetVar('answerM3') + ", ";
if ( player.GetVar('answerM4') !== "")
   answersum +=  player.GetVar('answerM4') + ", ";

formHTML += "<div class='logo'><span>Nationality and Mediterranean Foods</span><img src='http://www.playgen.com/chermug/chermug_logo.jpg'></div>";
formHTML += "<span class='name'>" +  player.GetVar('playerName')+ "</span><br/>";
formHTML += "<span class='label'>Score:</span> " + player.GetVar('score') + "<br/>";
formHTML += "<span class='label'>Rank:</span> " + player.GetVar('rank') + "<br/>";
formHTML += "<span class='label'>Time:</span> " + player.GetVar('timeLast') + "<br/>";
formHTML += "<span class='label'>Achievements:</span> " + answersum + "<br/>";

formHTML += "<table><tr class='header'><td>ID</td><td>Question</td><td>Answered</td><td>Correct/Incorrect</td></tr>";

var length = window.summary.question.length;
var question = null;
var answer = null;
var correct = null;

for (var i = 0; i < length; i++) {
question = window.summary.question[i];
answer = window.summary.answer[i];
correct = window.summary.correct[i];
id = i + 1;

formHTML += "<tr><td>" + id + "</td><td>" + question + "</td><td>" + answer + "</td><td>" + correct + "</td></tr>";

}

formHTML += "</table>";

formHTML += "<script>window.print();</script>";

var preview = window.open("about:blank");
preview.document.open();
preview.document.write(formHTML);
preview.document.close();
preview.print();
}

function Script14()
{
  var seconds=0;
timeVar = setTimeout(startTime,1000);

 
function startTime(){
seconds=seconds+1;
var player = GetPlayer();
player.SetVar("time",seconds);
timeVar = setTimeout(startTime,1000);
}
 
}

function Script15()
{
  var player = GetPlayer();
var answer1 = player.GetVar("answerM1");
var answer2 = player.GetVar("answerM2");
var answer3 = player.GetVar("answerM3");
var answer4 = player.GetVar("answerM4");
var answer5 = player.GetVar("answerM5");
var answer6 = player.GetVar("answerM6");
var answer7 = player.GetVar("answerM7");

var answersum = "";

if ( answer1 !== "")
   answersum += answer1 + ", ";
if ( answer2 !== "")
   answersum += answer2 + ", ";
if ( answer3 !== "")
   answersum += answer3 + ", ";
if ( answer4 !== "")
   answersum += answer4 + ", ";
if ( answer5 !== "")
   answersum += answer5 + ", ";
if ( answer6 !== "")
   answersum += answer6;
if ( answer7 !== "")
   answersum += answer7 + ", ";


 window.summary.question.push('Care sunt variabilele din studiu?');
  window.summary.answer.push(answersum);
  window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('1', answersum, false, '', 'Care sunt variabilele din studiu?', 1, 0, 'Scene2_Slide9_1');
}

function Script16()
{
  window.achievements.advanceAchievement(0);
window.achievements.doEverythingAtOnce();
}

function Script17()
{
  var player = GetPlayer();
var answer1 = player.GetVar("answerM1");
var answer2 = player.GetVar("answerM2");
var answer3 = player.GetVar("answerM3");
var answer4 = player.GetVar("answerM4");
var answer5 = player.GetVar("answerM5");
var answer6 = player.GetVar("answerM6");
var answer7 = player.GetVar("answerM7");

var answersum = "";

if ( answer1 !== "")
   answersum += answer1 + ", ";
if ( answer2 !== "")
   answersum += answer2 + ", ";
if ( answer3 !== "")
   answersum += answer3 + ", ";
if ( answer4 !== "")
   answersum += answer4 + ", ";
if ( answer5 !== "")
   answersum += answer5 + ", ";
if ( answer6 !== "")
   answersum += answer6;
if ( answer7 !== "")
   answersum += answer7 + ", ";


 window.summary.question.push('Care sunt variabilele din studiu?');
  window.summary.answer.push(answersum);
  window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('1', answersum, true, '', 'Care sunt variabilele din studiu?', 1, 0, 'Scene2_Slide9_1');
}

function Script18()
{
  player = GetPlayer();
answer1 = player.GetVar("answerM1");
answer2 = player.GetVar("answerM2");
answer3 = player.GetVar("answerM3");
answer4 = player.GetVar("answerM4");
answer5 = player.GetVar("answerM5");
answer6 = player.GetVar("answerM6");
answer7 = player.GetVar("answerM7");

var answersum = "";

if ( answer1 !== "")
   answersum += answer1 + ", ";
if ( answer2 !== "")
   answersum += answer2 + ", ";
if ( answer3 !== "")
   answersum += answer3 + ", ";
if ( answer4 !== "")
   answersum += answer4 + ", ";
if ( answer5 !== "")
   answersum += answer5 + ", ";
if ( answer6 !== "")
   answersum += answer6;
if ( answer7 !== "")
   answersum += answer7 + ", ";


 window.summary.question.push('Care este variabila independentă ȋn cadrul aceluiași studiu?');
  window.summary.answer.push(answersum);
  window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('2', answersum, true, '', 'Care este variabila independentă ȋn cadrul aceluiași studiu?', 1, 0, 'Scene2_Slide9_2');
}

function Script19()
{
  player = GetPlayer();
answer1 = player.GetVar("answerM1");
answer2 = player.GetVar("answerM2");
answer3 = player.GetVar("answerM3");
answer4 = player.GetVar("answerM4");
answer5 = player.GetVar("answerM5");
answer6 = player.GetVar("answerM6");
answer7 = player.GetVar("answerM7");

var answersum = "";

if ( answer1 !== "")
   answersum += answer1 + ", ";
if ( answer2 !== "")
   answersum += answer2 + ", ";
if ( answer3 !== "")
   answersum += answer3 + ", ";
if ( answer4 !== "")
   answersum += answer4 + ", ";
if ( answer5 !== "")
   answersum += answer5 + ", ";
if ( answer6 !== "")
   answersum += answer6;
if ( answer7 !== "")
   answersum += answer7 + ", ";


 window.summary.question.push('Care este variabila independentă ȋn cadrul aceluiași studiu?');
  window.summary.answer.push(answersum);
  window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('2', answersum, false, '', 'Care este variabila independentă ȋn cadrul aceluiași studiu?', 1, 0, 'Scene2_Slide9_2');
}

function Script20()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script21()
{
  player = GetPlayer();
answer1 = player.GetVar("answerM1");
answer2 = player.GetVar("answerM2");
answer3 = player.GetVar("answerM3");
answer4 = player.GetVar("answerM4");
answer5 = player.GetVar("answerM5");
answer6 = player.GetVar("answerM6");
answer7 = player.GetVar("answerM7");

var answersum = "";

if ( answer1 !== "")
   answersum += answer1 + ", ";
if ( answer2 !== "")
   answersum += answer2 + ", ";
if ( answer3 !== "")
   answersum += answer3 + ", ";
if ( answer4 !== "")
   answersum += answer4 + ", ";
if ( answer5 !== "")
   answersum += answer5 + ", ";
if ( answer6 !== "")
   answersum += answer6;
if ( answer7 !== "")
   answersum += answer7 + ", ";


 window.summary.question.push('Care este variabila independentă ȋn cadrul aceluiași studiu?');
  window.summary.answer.push(answersum);
  window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('3', answersum, true, '', 'Care este variabila independentă ȋn cadrul aceluiași studiu?', 1, 0, 'Scene2_Slide9_3');
}

function Script22()
{
  player = GetPlayer();
answer1 = player.GetVar("answerM1");
answer2 = player.GetVar("answerM2");
answer3 = player.GetVar("answerM3");
answer4 = player.GetVar("answerM4");
answer5 = player.GetVar("answerM5");
answer6 = player.GetVar("answerM6");
answer7 = player.GetVar("answerM7");

var answersum = "";

if ( answer1 !== "")
   answersum += answer1 + ", ";
if ( answer2 !== "")
   answersum += answer2 + ", ";
if ( answer3 !== "")
   answersum += answer3 + ", ";
if ( answer4 !== "")
   answersum += answer4 + ", ";
if ( answer5 !== "")
   answersum += answer5 + ", ";
if ( answer6 !== "")
   answersum += answer6;
if ( answer7 !== "")
   answersum += answer7 + ", ";


 window.summary.question.push('Care este variabila independentă ȋn cadrul aceluiași studiu?');
  window.summary.answer.push(answersum);
  window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('3', answersum, false, '', 'Care este variabila independentă ȋn cadrul aceluiași studiu?', 1, 0, 'Scene2_Slide9_3');
}

function Script23()
{
  
/*
 *
 * HANGMAN GAME
 *
 */

/*global GetPlayer:false */
var player = GetPlayer();
(function() {
	'use strict';
	window.hangman = {
		//Use capital letters
		questions: ["RATIE"],
		activeQuestion: -1,
		question: '',
		chars: [],
		foundChars: {},
		foundLetters: 0,
		alphabet: ["A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z", "Ex"],
		init: function()
		{
			//console.log("init");

		},
		/*
		 * Functions to be called from Storyline
		 */
		// Setup question and the word into letters
		setupQuestions: function(questionnumber)
		{
			this.foundLetters = 0;
			this.activeQuestion = questionnumber;
			this.question = this.questions[this.activeQuestion-1];
			this.chars = this.question.split('');
			this.foundChars = {};
			for (var i = this.alphabet.length - 1; i >= 0; i--)
				player.SetVar("hmChange"+ this.alphabet[i], 0);


		},
		// Check if any letter or the answer is found
		letterPressed: function(letter)
		{
			if (this.foundChars[letter])
				return;
			player.SetVar("hmChangeSet", 0);
			var found = 0;
			for (var i = this.chars.length - 1; i >= 0; i--) {
				var pos = i+1;
				if(this.chars[i] == letter) {
					player.SetVar("hml"  + pos, letter);
					found = 1;
					this.foundLetters++;
					this.foundChars[letter] = true;
					if (this.foundLetters >= this.chars.length) {
						player.SetVar("hmAnswerFound", 1);
					}	
				}
			}
			if( found != 1) {
				//cant put ! in the stroyline var
				if (letter == "!")
					letter = "Ex";

				var isPressed = player.GetVar("hmChange"+letter);
				if( isPressed == 0) {
				var tleft = player.GetVar("hmtleft");
				tleft = tleft -1;
				player.SetVar("hmtleft", tleft);
				player.SetVar("hmChange"+ letter, 1);
				}
			}
		 

			return;
		}
	};
	window.hangman.init();
})();

/*
 *
 * END OF HANGMAN GAME
 *
 */


}

function Script24()
{
  var seconds=3000;
// display();
var blinkTimer = setTimeout(display,400);
var flag = 0;
 
function display(){
	seconds=seconds-1;
	var player = GetPlayer();
	var tleft = player.GetVar("hmtleft");
	player.SetVar("hmtimer",seconds);
	if( tleft != 9) {
		if(flag == 0) {
			player.SetVar("hmBlink","hide");
			flag = 1;
		}
		else {
		player.SetVar("hmBlink","show");
		flag = 0;
		}
		var blinkTimer = setTimeout(display,400);
	}
	else 
	player.SetVar("hmBlink","show");
}
 
}

function Script25()
{
  window.hangman.setupQuestions(1);
}

function Script26()
{
  window.hangman.letterPressed("B");
}

function Script27()
{
  window.hangman.letterPressed("C");
}

function Script28()
{
  window.hangman.letterPressed("D");
}

function Script29()
{
  window.hangman.letterPressed("E");
}

function Script30()
{
  window.hangman.letterPressed("F");
}

function Script31()
{
  window.hangman.letterPressed("G");
}

function Script32()
{
  window.hangman.letterPressed("H");
}

function Script33()
{
  window.hangman.letterPressed("I");
}

function Script34()
{
  window.hangman.letterPressed("J");
}

function Script35()
{
  window.hangman.letterPressed("K");
}

function Script36()
{
  window.hangman.letterPressed("L");
}

function Script37()
{
  window.hangman.letterPressed("M");
}

function Script38()
{
  window.hangman.letterPressed("N");
}

function Script39()
{
  window.hangman.letterPressed("O");
}

function Script40()
{
  window.hangman.letterPressed("P");
}

function Script41()
{
  window.hangman.letterPressed("Q");
}

function Script42()
{
  window.hangman.letterPressed("R");
}

function Script43()
{
  window.hangman.letterPressed("S");
}

function Script44()
{
  window.hangman.letterPressed("T");
}

function Script45()
{
  window.hangman.letterPressed("U");
}

function Script46()
{
  window.hangman.letterPressed("V");
}

function Script47()
{
  window.hangman.letterPressed("W");
}

function Script48()
{
  window.hangman.letterPressed("X");
}

function Script49()
{
  window.hangman.letterPressed("Y");
}

function Script50()
{
  window.hangman.letterPressed("Z");
}

function Script51()
{
  window.hangman.letterPressed("!");
}

function Script52()
{
  window.hangman.letterPressed("A");
}

function Script53()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script54()
{
    window.summary.question.push('Ȋn acest studiu, care nivel de măsurare este cel potrivit pentru tipul de dietă?');
  window.summary.answer.push('Ratie');
  window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('4', 'Ratie', true, '', 'Ȋn acest studiu, care nivel de măsurare este cel potrivit pentru tipul de dietă?', 1, 0, 'Scene2_Slide10');
}

function Script55()
{
    window.summary.question.push('Ȋn acest studiu, care nivel de măsurare este cel potrivit pentru tipul de dietă?');
  window.summary.answer.push('');
  window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('4', '', false, '', 'Ȋn acest studiu, care nivel de măsurare este cel potrivit pentru tipul de dietă?', 1, 0, 'Scene2_Slide10');
}

function Script56()
{
  var seconds=4;
//setTimeout(display,1000);
display();
 
function display(){
seconds=seconds-1;
var player = GetPlayer();
player.SetVar("hmcready",seconds);
var cready = player.GetVar("hmcready");
if ( cready == 0) {
player.SetVar("hmcready", "Go!");
setTimeout(display,1000);
}
else if ( cready == -1) {
player.SetVar("hmcready", "next");
}
else {
setTimeout(display,1000);
}
}
}

function Script57()
{
  window.hangman.setupQuestions(1);
var seconds=4;
//setTimeout(display,1000);
display();
 
function display(){
seconds=seconds-1;
var player = GetPlayer();
player.SetVar("hmcready",seconds);
var cready = player.GetVar("hmcready");
if ( cready == 0) {
player.SetVar("hmcready", "Go!");
setTimeout(display,1000);
}
else if ( cready == -1) {
player.SetVar("hmcready", "next");
setTimeout(display,1000);
}
else {
setTimeout(display,1000);
}
}
}

function Script58()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script59()
{
  var player = GetPlayer();  
var answer = player.GetVar('answer');
window.summary.question.push('Ce nivel de măsurare este potrivit pentru naționalitate ȋn acest studiu? ');
window.summary.answer.push(answer);
window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('5', answer, true, '', 'Ce nivel de măsurare este potrivit pentru naționalitate ȋn acest studiu? ', 1, 0, 'Scene2_Slide11_1');
}

function Script60()
{
  var player = GetPlayer();  
var answer = player.GetVar('answer');
window.summary.question.push('Ce nivel de măsurare este potrivit pentru naționalitate ȋn acest studiu? ');
window.summary.answer.push(answer);
window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('5', answer, false, '', 'Ce nivel de măsurare este potrivit pentru naționalitate ȋn acest studiu? ', 1, 0, 'Scene2_Slide11_1');
}

function Script61()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script62()
{
    window.summary.question.push('Ce fel de plan sugerează acest studiu?');
  window.summary.answer.push('diferențe ȋntre grupuri');
  window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('6', 'diferențe ȋntre grupuri', true, '', 'Ce fel de plan sugerează acest studiu?', 1, 0, 'Scene2_Slide11_2');
}

function Script63()
{
    window.summary.question.push('Ce fel de plan sugerează acest studiu?');
  window.summary.answer.push('o asociere ȋntre variabile.');
  window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('6', 'o asociere ȋntre variabile.', false, '', 'Ce fel de plan sugerează acest studiu? ', 1, 0, 'Scene2_Slide11_2');
}

function Script64()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script65()
{
    window.summary.question.push('Care dintre seturile de date neprelucrate de mai jos este cel corect pentru a testa datele tale?');
  window.summary.answer.push('Dataset1');
  window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('10', 'Dataset1', true, '', 'Care dintre seturile de date neprelucrate de mai jos este cel corect pentru a testa datele tale? ', 1, 0, 'Scene2_Slide12');
}

function Script66()
{
    window.summary.question.push('Care dintre seturile de date neprelucrate de mai jos este cel corect pentru a testa datele tale?');
  window.summary.answer.push('Dataset2');
  window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('10', 'Dataset2', true, '', 'Care dintre seturile de date neprelucrate de mai jos este cel corect pentru a testa datele tale? ', 1, 0, 'Scene2_Slide12');
}

function Script67()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script68()
{
  player = GetPlayer();  
var answer = player.GetVar('answer');

window.summary.question.push('Ce fel de reprezentare grafica a datelor doresti sa vezi?');
window.summary.answer.push(answer);
window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('11', answer, true, '', 'Ce fel de reprezentare grafica a datelor doresti sa vezi? ', 1, 0, 'Scene2_Slide13');
}

function Script69()
{
  player = GetPlayer();  
var answer = player.GetVar('answer');

window.summary.question.push('Ce fel de reprezentare grafica a datelor doresti sa vezi?');
window.summary.answer.push(answer);
window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('11', answer, false, '', 'Ce fel de reprezentare grafica a datelor doresti sa vezi? ', 1, 0, 'Scene2_Slide13');
}

function Script70()
{
  player = GetPlayer();  
var answer = player.GetVar('answer');

window.summary.question.push('Ce fel de reprezentare grafica a datelor doresti sa vezi?');
window.summary.answer.push(answer);
window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('11', answer, false, '', 'Ce fel de reprezentare grafica a datelor doresti sa vezi? ', 1, 0, 'Scene2_Slide13');
}

function Script71()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script72()
{
  player = GetPlayer();  
var answer = player.GetVar('answer');

window.summary.question.push('Ce fel de reprezentare grafica a datelor doresti sa vezi?');
window.summary.answer.push(answer);
window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('11', answer, true, '', 'Ce fel de reprezentare grafica a datelor doresti sa vezi? ', 1, 0, 'Scene2_Slide13');
}

function Script73()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script74()
{
  window.summary.question.push("Pentru a testa ipoteza conform căreia, Nu va exista nicio diferență ȋntre copiii spanioli și cei britanici legat de numărul de mâncăruri mediteraneene consumate, ce test statistic trebuie folosit? ");
window.summary.answer.push('Pentru a testa ipoteza conform căreia, Nu va exista nicio diferență ȋntre copiii spanioli și cei britanici legat de numărul de mâncăruri mediteraneene consumate, ce test statistic trebuie folosit? ');
window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('13', 'Pentru a testa ipoteza conform căreia, Nu va exista nicio diferență ȋntre copiii spanioli și cei britanici legat de numărul de mâncăruri mediteraneene consumate, ce test statistic trebuie folosit? ', true, '', 'Pentru a testa ipoteza conform căreia, Nu va exista nicio diferență ȋntre copiii spanioli și cei britanici legat de numărul de mâncăruri mediteraneene consumate, ce test statistic trebuie folosit?  ', 1, 0, 'Scene2_Slide14_1');
}

function Script75()
{
  window.summary.question.push("Pentru a testa ipoteza conform căreia, Nu va exista nicio diferență ȋntre copiii spanioli și cei britanici legat de numărul de mâncăruri mediteraneene consumate, ce test statistic trebuie folosit?  ");
window.summary.answer.push('Chi pătrat');
window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('13', 'Chi pătrat', false, '', 'Pentru a testa ipoteza conform căreia, Nu va exista nicio diferență ȋntre copiii spanioli și cei britanici legat de numărul de mâncăruri mediteraneene consumate, ce test statistic trebuie folosit?  ', 1, 0, 'Scene2_Slide14_1');
}

function Script76()
{
  window.summary.question.push('Pentru a testa ipoteza conform căreia, Nu va exista nicio diferență ȋntre copiii spanioli și cei britanici legat de numărul de mâncăruri mediteraneene consumate, ce test statistic trebuie folosit?  ');
window.summary.answer.push('Pearsons r');
window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('13', 'Pearsons r', false, '', 'Pentru a testa ipoteza conform căreia, Nu va exista nicio diferență ȋntre copiii spanioli și cei britanici legat de numărul de mâncăruri mediteraneene consumate, ce test statistic trebuie folosit?  ', 1, 0, 'Scene2_Slide14_1');
}

function Script77()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script78()
{
  window.summary.question.push("Interpretation of table ");
window.summary.answer.push('Tabelul arată că, ȋn medie, copiii britanici consumă săptămânal 18,83 mâncăruri mediteraneene..');
window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('14', 'Tabelul arată că, ȋn medie, copiii britanici consumă săptămânal 18,83 mâncăruri mediteraneene.', true, '', 'Interpretation of table ', 1, 0, 'Scene2_Slide14_2');
}

function Script79()
{
  window.summary.question.push('Interpretation of table ');
window.summary.answer.push('Tabelul arată că, ȋn medie, copiii britanici consumă săptămânal 2,781 mâncăruri mediteraneene.');
window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('14', 'Tabelul arată că, ȋn medie, copiii britanici consumă săptămânal 2,781 mâncăruri mediteraneene.', false, '', 'Interpretation of table ', 1, 0, 'Scene2_Slide14_2');
}

function Script80()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script81()
{
  window.summary.question.push('Interpretation of table ');
window.summary.answer.push('Tabelul arată că numărul de produse alimentare mediteraneene consumate de copiii spanioli este mai mare decât numărul de produse consumate de copiii britanici.');
window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('15', 'Tabelul arată că numărul de produse alimentare mediteraneene consumate de copiii spanioli este mai mare decât numărul de produse consumate de copiii britanici', true, '', 'Interpretation of table ', 1, 0, 'Scene2_Slide14_3');
}

function Script82()
{
  window.summary.question.push('Interpretation of table ');
window.summary.answer.push('Tabelul arată că numărul de produse alimentare mediteraneene consumate săptămânal de copiii britanici este mai mare decât numărul de produse consumate de copiii spanioli.');
window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('15', 'Tabelul arată că numărul de produse alimentare mediteraneene consumate săptămânal de copiii britanici este mai mare decât numărul de produse consumate de copiii spanioli.', false, '', 'Interpretation of table ', 1, 0, 'Scene2_Slide14_3');
}

function Script83()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}

var time = player.GetVar('time');
//Bronze Gold Silver
if( time <= 15000 && time > 12000 ) {
player.SetVar("achQuestionBronze",1);
}
if( time>= 10000 &&  time <= 12000) {
player.SetVar("achQuestionBronze",0);
player.SetVar("achQuestionSilver",1);
}
if( time < 10000 ) {
player.SetVar("achQuestionSilver",0);
player.SetVar("achQuestionGold",1);
}

}

function Script84()
{
  window.achievements.advanceAchievement(3);
window.achievements.doEverythingAtOnce();

window.achievements.advanceAchievement(4);
window.achievements.doEverythingAtOnce();




}

function Script85()
{
  window.summary.question.push('Interpretation of table ');
window.summary.answer.push('Valoarea semnificativă 0,005 arată că a existat o diferență semnificativă ');
window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('16', 'Valoarea semnificativă 0,005 arată că a existat o diferență semnificativă ', true, '', 'Interpretation of table ', 1, 0, 'Scene2_Slide14_4');
}

function Script86()
{
  var player = GetPlayer();
var time = player.GetVar('time');
//Bronze Gold Silver
if( time <= 15000 && time > 12000 ) {
player.SetVar("achQuestionBronze",1);
}
if( time>= 10000 &&  time <= 12000) {
player.SetVar("achQuestionBronze",0);
player.SetVar("achQuestionSilver",1);
}
if( time < 10000 ) {
player.SetVar("achQuestionSilver",0);
player.SetVar("achQuestionGold",1);
}

window.achievements.advanceAchievement(4);
window.achievements.doEverythingAtOnce();
}

function Script87()
{
  window.summary.question.push('Interpretation of table ');
window.summary.answer.push('Valoarea semnificativă 0,005 arată că nu a existat o diferență semnificativă ');
window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('16', 'Valoarea semnificativă 0,005 arată că nu a existat o diferență semnificativă ', false, '', 'Interpretation of table ', 1, 0, 'Scene2_Slide14_4');
}

function Script88()
{
  
/*
 *
 * TIC-TAC-TOE GAME
 *
 */

/*global GetPlayer:false */
var player = GetPlayer();
(function() {
	'use strict';
	var state = {
		READY: 0,
		RIGHT: 1,
		WRONG: 2
	};
	var validValues = [
		// Rows
		1  | 2   | 4,
		8  | 16  | 32,
		64 | 128 | 256,
		// Columns
		1  | 8   | 64,
		2  | 16  | 128,
		4  | 32  | 256
	];
	window.ttt = {
		questions: [
			{
				text: "Graficul sugerează că numărul mediu de produse alimentare mediteraneene consumate de copiii spanioli este mai mare decât numărul mediu de produse consumate de copiii britanici. ",
				wrong: "Fals, graficul nu afișează numărul mediu de produse alimentare mediteraneene consumate, ci numărul median de produse alimentare mediteraneene consumate.",
				answer: false
			},
			{
				text: "Graficul sugerează că numărul mediu de produse alimentare mediteraneene consumate de copiii spanioli este ușor mai mare decât numărul mediu de produse consumate de copiii britanici.",
				wrong: "Adevărat , graficul sugerează că numărul median de produse alimentare mediteraneene consumate de copiii spanioli este mai mare decât numărul median de produse consumate de copiii britanici.",
				answer: true
			},
			{
				text: "Graficul arată că există o variabilitate mai mare în numărul de produse alimentare mediteraneene consumate de copiii spanioli decât de copiii britanici.",
				wrong: "Fals ,graficul arată că există o variabilitate ceva mai mare în numărul de produse alimentare mediteraneene consumate de către copiii britanici decât cei spanioli.",
				answer: false
			},
			{
				text: "Tabelul de rezultate arată că ȋn medie, copiii britanici consumă 2,781 de produse alimentare mediteraneene pe săptămână.",
				wrong: "Fals , tabelul de rezultate arată că ȋn medie, copiii britanici consumă 18,83 alimente mediteraneene pe săptămână. 2,781 este deviația standard.",
				answer: false
			},
			{
				text: "Tabelul de rezultate arată că ȋn medie, copiii spanioli consumă 20,20 alimente mediteraneene pe săptămână.",
				wrong: "Adevărat, tabelul de rezultate arată că ȋn medie, copiii spanioli consumă 20,20 alimente mediteraneene pe săptămână.",
				answer: true
			},
			{
				text: "Tabelul de rezultate ȋnregistrează un consum săptămânal mai mare de produse alimentare mediteraneene al copiilor spanioli față de cel al copiilor britanici.",
				wrong: "Adevărat, tabelul de rezultate ȋnregistrează un consum săptămânal mai mare de produse alimentare mediteraneene al copiilor spanioli (20,20), față de cel al copiilor britanici (18,83).",
				answer: true
			},
			{
				text: "Pragul de semnificație de 0,005 arată că a existat o diferență statistică semnificativă a consumului de alimente mediteraneene de către copii britanici și copiii spanioli.",
				wrong: "Adevărat , pragul de semnificație de 0,005 arată că a existat o diferență statistică semnificativă a consumului e alimente mediteraneene de către copii britanici și copiii spanioli.",
				answer: true
			},
			{
				text: "Ȋn total, conform tabelulului de rezultate, consumul săptămânal de alimente mediteraneene al copiilor spanioli nu este ȋn mod semnificativ mai mare  decât cel al copiilor britanici..",
				wrong: "Fals,  conform tabelului de rezultate, putem concluziona că, ȋn total, copiii spanioli consumă săptămânal un număr de alimente mediteraneene semnificativ mai mare decât cel al copiilor britanici.",
				answer: false
			},
			{
				text: "Pragul de semnificație ne arată că putem respinge ipoteza nulă..",
				wrong: "Adevărat, pragul de semnificație (0,005) ne arată că putem respinge ipoteza nulă atâta timp cât au existat diferențe semnificative ȋntre consumul de alimente mediteraneene  al copiilor britanici si cel al copiilor spanioli.",
				answer: true
			}
		],
		activeQuestion: -1,
		totalValue: 0,
		init: function()
		{
			if (this.questions.length !== 9) {
				alert("Question count missmatch! Got " + this.questions.length + " expected 9");
				return;
			}
			var value = 1;
			// Setup the Qs with redundant info

var length = this.questions.length,
element = null;
for (var i = 0; i < length; i++) {
element = this.questions[i];
element .id = i;
element .value = value;
element .state = state.READY;
value *= 2;
}
		},
		updateQState: function(question, state)
		{
			question.state = state;
			player.SetVar('tttQuestionState' + question.id, state);
		},
		/*
		 * Functions to be called from Storyline
		 */
		// Resets all the question vars to ready
		setupQuestions: function()
		{
			this.activeQuestion = null;
			this.totalValue = 0;
			player.SetVar('tttQuestionText', '');
			player.SetVar('tttSlideSolved', 0);
var length = this.questions.length,
element = null;
for (var i = 0; i < length; i++) {
element = this.questions[i];
this.updateQState(element , state.READY);
}

		},
		// For when the user picks a question
		chooseQuestion: function(quid)
		{
			var question = this.questions[quid];
			if (question.state !== state.READY)
				return;
			this.activeQuestion = question;
			player.SetVar('tttQuestionText', question.text);
		},
		// Check if the answer is correctus
		checkAnswer: function(choice)
		{
			// Get what we're talkin about
			var question = this.activeQuestion;
			// Hide the question window
var questionText = player.GetVar('tttQuestionText');
			player.SetVar('tttQuestionText', '');
			// Reset the wrong var so we can trigger it if necessary
			player.SetVar('tttQuestionWrong', '');
			// Determine failure
			var choice_ = (choice == 'true') ? true : false;
			// If you pass you're wrong and stupid
			if (choice === 'pass' || choice_ !== question.answer) {
				this.updateQState(question, state.WRONG);
				// Pop up the "no u stupid" box
				player.SetVar('tttQuestionWrong', question.wrong);

window.summary.question.push(questionText);
window.summary.answer.push(choice_);
window.summary.correct.push('Incorrect');

				return;
			}
			// success!
window.summary.question.push(questionText);
window.summary.answer.push(question.answer);
window.summary.correct.push('Correct');
			this.updateQState(question, state.RIGHT);
			this.totalValue |= question.value;
			// Check if we've won
var length = validValues.length,
value = null;
for (var i = 0; i < length; i++) {
value = validValues[i];
if  ( (this.totalValue & value) === value )
player.SetVar('tttSlideSolved', 1);
}
		}
	};
	window.ttt.init();
})();

/*
 *
 * END OF TIC-TAC-TOE GAME
 *
 */


}

function Script89()
{
  window.ttt.setupQuestions();
}

function Script90()
{
  window.ttt.setupQuestions();
}

function Script91()
{
  window.ttt.chooseQuestion(0);
}

function Script92()
{
  window.ttt.chooseQuestion(1);
}

function Script93()
{
  window.ttt.chooseQuestion(2);
}

function Script94()
{
  window.ttt.chooseQuestion(3);
}

function Script95()
{
  window.ttt.chooseQuestion(4);
}

function Script96()
{
  window.ttt.chooseQuestion(5);
}

function Script97()
{
  window.ttt.chooseQuestion(6);
}

function Script98()
{
  window.ttt.chooseQuestion(7);
}

function Script99()
{
  window.ttt.chooseQuestion(8);
}

function Script100()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


lmsAPI.RecordFillInInteraction('12', 'Completed', true, '', 'Microscope Game ', 1, 0, 'Scene2_Slide15');



}

function Script101()
{
  lmsAPI.RecordFillInInteraction('12', '', false, '', 'Microscope Game ', 1, 0, 'Scene2_Slide15');
}

function Script102()
{
  var eyesshut = 100, eyesopen = 10000, inblink = false;
var player = GetPlayer();
function blink(){
  inblink = !inblink;
  if (inblink) {
    player.SetVar('blinkState', 'hide');
    setTimeout(blink, eyesshut + Math.random() * 40);
  } else {
    player.SetVar('blinkState', 'show');
    setTimeout(blink, eyesopen + Math.random() * 500);
  }
}

blink(); 
}

function Script103()
{
  window.ttt.checkAnswer('true');
}

function Script104()
{
  window.ttt.checkAnswer('false');
}

