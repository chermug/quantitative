function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6CUilSogXAA":
        Script1();
        break;
      case "5k6HbQpXtFA":
        Script2();
        break;
      case "5uehTvGYwRc":
        Script3();
        break;
      case "60jrSkTkNVt":
        Script4();
        break;
      case "6GfiM8UZkhq":
        Script5();
        break;
      case "62fUza1LkPP":
        Script6();
        break;
      case "5WsApM0WDBW":
        Script7();
        break;
      case "5tRac1wAC8D":
        Script8();
        break;
      case "5qwiXJ1B522":
        Script9();
        break;
      case "64b3TMtb9ll":
        Script10();
        break;
      case "6naoHJ9yydn":
        Script11();
        break;
      case "6V62TrW3VNW":
        Script12();
        break;
      case "6PBrVs2ljsK":
        Script13();
        break;
      case "6IaqPVWsl2c":
        Script14();
        break;
      case "6U01hqyndqc":
        Script15();
        break;
      case "6LqMwNs0d5R":
        Script16();
        break;
      case "5gTlzHwo6D5":
        Script17();
        break;
      case "5YEm2gb8AxJ":
        Script18();
        break;
      case "5ybbMrpHDJV":
        Script19();
        break;
      case "6GIigjD4442":
        Script20();
        break;
      case "6SDGk57V83B":
        Script21();
        break;
      case "6TRn8D70z98":
        Script22();
        break;
      case "6eBBDxnV0aa":
        Script23();
        break;
      case "66pv8326lzq":
        Script24();
        break;
      case "6489FeT3dNO":
        Script25();
        break;
      case "6jPAxPWxaEi":
        Script26();
        break;
      case "5nV5ji0NdPc":
        Script27();
        break;
      case "6q5WzHxchPY":
        Script28();
        break;
      case "6A5NYBYX8qx":
        Script29();
        break;
      case "6NiQHcNymHO":
        Script30();
        break;
      case "5ujqOGnbYIm":
        Script31();
        break;
      case "5WaAAw5ZrhQ":
        Script32();
        break;
      case "5hOY9A88nm7":
        Script33();
        break;
      case "5x7sbiXuYBM":
        Script34();
        break;
      case "6XqVYrSqVD2":
        Script35();
        break;
      case "5sToMM78UK3":
        Script36();
        break;
      case "6MhxkllyNsV":
        Script37();
        break;
      case "6h6NEtEifez":
        Script38();
        break;
      case "6A16iK3q6o3":
        Script39();
        break;
      case "5dsffZY58LT":
        Script40();
        break;
      case "6Uz5HBSuBzn":
        Script41();
        break;
      case "6BaisTQCz8j":
        Script42();
        break;
      case "5mWb72VS3c0":
        Script43();
        break;
      case "625KLAKsJBr":
        Script44();
        break;
      case "6FTAPSsvPp5":
        Script45();
        break;
      case "6ICKhYoUb60":
        Script46();
        break;
      case "5bZUSXUDWGm":
        Script47();
        break;
      case "6onssXN3Wxl":
        Script48();
        break;
      case "5mwgmdXlUDQ":
        Script49();
        break;
      case "5qu2oKuARTA":
        Script50();
        break;
      case "6CqETSAcVEc":
        Script51();
        break;
      case "6eNfHnGduG4":
        Script52();
        break;
      case "5gm4oClYnxb":
        Script53();
        break;
      case "696Y5Ul7nXB":
        Script54();
        break;
      case "5hKlQu9K19H":
        Script55();
        break;
      case "6D8xojLK9JQ":
        Script56();
        break;
      case "6D6G7XuBKHI":
        Script57();
        break;
      case "5yZ3BZqus9M":
        Script58();
        break;
      case "6qjMrYfbhhW":
        Script59();
        break;
      case "6YvXOgn1L8S":
        Script60();
        break;
      case "6duvnpK2UUv":
        Script61();
        break;
      case "5bEej8gmeah":
        Script62();
        break;
      case "6CbpLu4Oopt":
        Script63();
        break;
      case "69OIiFQu5qw":
        Script64();
        break;
      case "6nAgVffkp8Z":
        Script65();
        break;
      case "6npJcdUZBP0":
        Script66();
        break;
      case "6ivSeLkaHgS":
        Script67();
        break;
      case "6FuKAtV9NuF":
        Script68();
        break;
      case "6iKiCFnN86K":
        Script69();
        break;
      case "64NyaBw7ecv":
        Script70();
        break;
      case "6nPImslEA2S":
        Script71();
        break;
      case "61EEBjGQWgO":
        Script72();
        break;
      case "6GtTXqG21Vg":
        Script73();
        break;
      case "6iHdl9aLXiW":
        Script74();
        break;
      case "5zaCfzrs8mV":
        Script75();
        break;
      case "6M69At9z5S5":
        Script76();
        break;
      case "6qmls6MSjWs":
        Script77();
        break;
      case "5qxvH88EFW7":
        Script78();
        break;
      case "6IuUgP4Nw64":
        Script79();
        break;
      case "6Tr2Yq3oW8V":
        Script80();
        break;
      case "5ziBOHzzYrm":
        Script81();
        break;
      case "5rnRnRJe4ju":
        Script82();
        break;
      case "6PKLzzIZq8Y":
        Script83();
        break;
      case "6HJPGMMNb6l":
        Script84();
        break;
      case "6llw0pnmbI6":
        Script85();
        break;
      case "6PYDV67Vhz6":
        Script86();
        break;
      case "5qCsqp5Ow7S":
        Script87();
        break;
      case "5svkTXwclch":
        Script88();
        break;
      case "5th3IBrZEhA":
        Script89();
        break;
      case "6U9fcJ6dZbL":
        Script90();
        break;
      case "6ZgHpNpCh85":
        Script91();
        break;
      case "5zkkMuQR529":
        Script92();
        break;
      case "6MIlXunuqnt":
        Script93();
        break;
      case "69QAvNFk8Nq":
        Script94();
        break;
      case "6XUego37Kab":
        Script95();
        break;
      case "5oXl7ZvWEPa":
        Script96();
        break;
      case "6Sq5gpM6xmw":
        Script97();
        break;
      case "6kiaHCgo3kl":
        Script98();
        break;
      case "64Eg7M1JCio":
        Script99();
        break;
  }
}

function Script1()
{
  
/*
 *
 *   ACHIEVEMENTS
 *
 */

/*global GetPlayer:false */
var player = GetPlayer();
(function() {
	'use strict';
	window.achievements = {
		achievements: [
			{
				name: "De eerste vraag",
				desc: "U hebt de eerst vraag goed beantwoord.",
				advance: function()
				{
					this.completed = true;
				}
			},
			{
				name: "Drie in een rij",
				desc: "U hebt drie vragen op rij goed beantwoord.",
				rowCounter: 0,
				advance: function()
				{
					var rowCounter = player.GetVar('ach3Question');
					console.log("in a row: "+rowCounter);
					if (rowCounter  == 3)
						this.completed = true;
				}
			},
			{
				name: "Hypothese",
				desc: "U hebt alle hypothese vragen goed beantwoord.",
				rowCounter: 0,
				advance: function()
				{
					var isHypothesis = player.GetVar('achHypothesis');
					console.log(isHypothesis);
					if (isHypothesis  == 1)
						this.completed = true;
				}
			},
			{
				name: "Alle",
				desc: "U hebt alle vragen goed beantwoord.",
				rowCounter: 0,
				advance: function()
				{
					var isAll = player.GetVar('achAll');
					console.log(isAll);
					if (isAll  == 1)
						this.completed = true;
				}
			},
			{
				name: "",
				desc: "",
				rowCounter: 0,
				advance: function()
				{
					//In each case it will earn something
					this.completed = true;
				}
			},

		],
		completedThisRound: [],

		init: function()
		{
			for (var i = 0; i < this.achievements.length; ++i) {
				this.achievements[i].id = i;
			}
		},
		// public
		advanceAchievement: function(achid)
		{
			var ach = this.achievements[achid];
			if (!ach)
				return;
			if (ach.completed)
				return;
			ach.advance();
			if (!ach.completed)
				return;
			this.completedThisRound.push(ach);
		},
		checkForAchievements: function()
		{
			return this.completedThisRound.length > 0;
		},
		resetAchievementVars: function()
		{
			player.SetVar('achievementActive', 0);
			player.SetVar('achievementName', '');
			player.SetVar('achievementDesc', '');
			player.SetVar('achivementId', -1);
		},
		setupAchievementVars: function()
		{
			var ach = this.completedThisRound.shift();
			player.SetVar('achievementActive', 1);
			player.SetVar('achievementName', ach.name);
			player.SetVar('achievementDesc', ach.desc);
			player.SetVar('achivementId', ach.id);
			player.SetVar('achievementUnlocked' + ach.id, 1);
		},
		// public
		doEverythingAtOnce: function()
		{
			this.resetAchievementVars();
			if (this.checkForAchievements())
				this.setupAchievementVars();

		}
	};
	window.achievements.init();
})();

/*
 *
 *  END OF ACHIEVEMENTS 
 *
 */

}

function Script2()
{
  var eyesshut = 100, eyesopen = 10000, inblink = false;
var player = GetPlayer();
var isPopUp = player.GetVar("isPopUp");
function blink(){
  inblink = !inblink;
 if (isPopUp == 1) {
 setTimeout(blink, 100);
}
  else if (inblink) {
    player.SetVar('blinkState', 'hide');
    setTimeout(blink, eyesshut + Math.random() * 100);
  } else {
    player.SetVar('blinkState', 'show');
    setTimeout(blink, eyesopen + Math.random() * 1000);
  }
}

blink(); 

window.summary = {question: [], answer: [], correct: []}; 
}

function Script3()
{
  var player = GetPlayer();
player.SetVar("answerM1", "");
player.SetVar("answerM2", "");
player.SetVar("answerM3", "");
player.SetVar("answerM4", "");
player.SetVar("answerM5", "");
player.SetVar("answerM6", "");
}

function Script4()
{
   window.summary.question.push('Null-hypothesis - Part1');
  window.summary.answer.push('Er is een verband');
  window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('6', 'Er is een verband', false, '', 'Null-hypothesis Part 1 ', 1, 0, 'Scene2_Slide6_1');
}

function Script5()
{
  player = GetPlayer();
answer1 = player.GetVar("answerM4");
answer2 = player.GetVar("answerM3");

 window.summary.question.push('Null-hypothesis - Part2');
  window.summary.answer.push(answer1 + answer2);
  window.summary.correct.push('Incorrect');

var answersum = answer1 + answer2;

lmsAPI.RecordFillInInteraction('7', answersum, false, '', 'Null-hypothesis Part 2 ', 1, 0, 'Scene2_Slide6_2');
}

function Script6()
{
  player = GetPlayer();
answer1 = player.GetVar("answerM5");
answer2 = player.GetVar("answerM6");

 window.summary.question.push('Null-hypothesis - Part3');
  window.summary.answer.push(answer1 + answer2);
  window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('8', answersum, false, '', 'Null-hypothesis Part 3 ', 1, 0, 'Scene2_Slide6_3');
}

function Script7()
{
    window.summary.question.push('Null-hypothesis - Part1');
  window.summary.answer.push('Er is geen verband');
  window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('6', 'Er is geen verband', true, '', 'Null-hypothesis Part 2 ', 1, 0, 'Scene2_Slide6_1');
}

function Script8()
{
    window.summary.question.push('Null-hypothesis - Part2');
  window.summary.answer.push('tussen de mate van mediaconsumptie');
  window.summary.correct.push('Correct');


lmsAPI.RecordFillInInteraction('7', 'tussen de mate van mediaconsumptie', true, '', 'Null-hypothesis Part 2 ', 1, 0, 'Scene2_Slide6_2');
}

function Script9()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script10()
{
    window.summary.question.push('Null-hypothesis - Part3');
  window.summary.answer.push('en de mate van zwaarlijvigheid');
  window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('8', 'en de mate van zwaarlijvigheid', true, '', 'Null-hypothesis Part 3 ', 1, 0, 'Scene2_Slide6_3');
}

function Script11()
{
  var player = GetPlayer();
var score = player.GetVar('score');
var rank;
window.clearTimeout(timeVar);

//Score
if( score >= 1500 )
 rank = "A";
else if( score >= 1400 )
 rank = "B";
else if( score >= 1300 )
 rank = "C";
else if( score >= 1200 )
 rank = "D";
else 
 rank = "E";

player.SetVar('rank', rank);

//Time
function zeroPad(num, places) {
  var zero = places - num.toString().length + 1;
  return Array(+(zero > 0 && zero)).join("0") + num;
}

var time = player.GetVar('time');

var minutes = Math.floor(time / 60);
var seconds = time - minutes * 60;

minutes  = zeroPad(minutes, 2);
seconds  = zeroPad(seconds, 2);

var NewTime = minutes+":"+seconds;
player.SetVar('timeLast', NewTime );

player.SetVar("answerM1", "");
player.SetVar("answerM2", "");
player.SetVar("answerM3", "");
player.SetVar("answerM4", "");
player.SetVar("answerM5", "");
player.SetVar("answerM6", "");

lmsAPI.RecordFillInInteraction('14', score, true, '', 'Score ', 1, 0, 'Scene2_Slide8');
lmsAPI.RecordFillInInteraction('15', NewTime, true, '', 'Playing Time ', 1, 0, 'Scene2_Slide8');

lmsAPI.SetPassed();
player = GetPlayer();
var correct = player.GetVar("correctcounter");
var question = player.GetVar("questioncounter");

var score = ( correct / question ) * 100;
score =  Math.round( Number(score));
player.SetVar("calculatedscore", score);
player.SetVar("calculatedcorrect",correct);
player.SetVar("calculatedquestion",question);

lmsAPI.SetScore(score,100,0);

lmsAPI.RecordFillInInteraction('16', playerName, true, '', 'Player Name ', 1, 0, 'Scene2_Slide8');

lmsAPI.RecordFillInInteraction('17', rank, true, '', 'Rank ', 1, 0, 'Scene2_Slide8');


}

function Script12()
{
  var answersum = "";

if ( player.GetVar('answerM1') !== "")
   answersum +=  player.GetVar('answerM1') + ", ";
if ( player.GetVar('answerM2') !== "")
   answersum +=  player.GetVar('answerM2') + ", ";
if ( player.GetVar('answerM3') !== "")
   answersum +=  player.GetVar('answerM3') + ", ";
if ( player.GetVar('answerM4') !== "")
   answersum +=  player.GetVar('answerM4') + ", ";

lmsAPI.RecordFillInInteraction('18', answersum, true, '', 'Achievements ', 1, 0, 'Scene2_Slide8');
}

function Script13()
{
  var player = GetPlayer();
var formHTML = "<style>table {border-collapse:collapse;margin-top:20px;color:#373737} table, tr, td {padding: 10px;}tr:nth-child(even) {background:#E3F3EF; }tr:nth-child(odd) {background:#C7F1E6; }tr.header{background:#008A6E;color:white;font-weight:bold; }.logo { margin-bottom:10px;} .name {text-transform:uppercase;font-size:24px;font-weight:bold;color:#008A6E;}.label {font-weight:bold;}.logo span {font-size:27px; font-weight: bold; text-decoration:underline; color:#373737 } .logo img {float:right;}</style>";

var answersum = "";

if ( player.GetVar('answerM1') !== "")
   answersum +=  player.GetVar('answerM1') + ", ";
if ( player.GetVar('answerM2') !== "")
   answersum +=  player.GetVar('answerM2') + ", ";
if ( player.GetVar('answerM3') !== "")
   answersum +=  player.GetVar('answerM3') + ", ";
if ( player.GetVar('answerM4') !== "")
   answersum +=  player.GetVar('answerM4') + ", ";

formHTML += "<div class='logo'><span>Media Consumption and Obesity</span><img src='http://www.playgen.com/chermug/chermug_logo.jpg'></div>";
formHTML += "<span class='name'>" +  player.GetVar('playerName')+ "</span><br/>";
formHTML += "<span class='label'>Score:</span> " + player.GetVar('score') + "<br/>";
formHTML += "<span class='label'>Rank:</span> " + player.GetVar('rank') + "<br/>";
formHTML += "<span class='label'>Time:</span> " + player.GetVar('timeLast') + "<br/>";
formHTML += "<span class='label'>Achievements:</span> " + answersum + "<br/>";

formHTML += "<table><tr class='header'><td>ID</td><td>Question</td><td>Answered</td><td>Correct/Incorrect</td></tr>";

var length = window.summary.question.length;
var question = null;
var answer = null;
var correct = null;

for (var i = 0; i < length; i++) {
question = window.summary.question[i];
answer = window.summary.answer[i];
correct = window.summary.correct[i];
id = i + 1;

formHTML += "<tr><td>" + id + "</td><td>" + question + "</td><td>" + answer + "</td><td>" + correct + "</td></tr>";

}

formHTML += "</table>";

formHTML += "<script>window.print();</script>";

var preview = window.open("about:blank");
preview.document.open();
preview.document.write(formHTML);
preview.document.close();
preview.print();
}

function Script14()
{
  var seconds=0;
timeVar = setTimeout(startTime,1000);

 
function startTime(){
seconds=seconds+1;
var player = GetPlayer();
player.SetVar("time",seconds);
timeVar = setTimeout(startTime,1000);
}
 
}

function Script15()
{
  player = GetPlayer();
answer1 = player.GetVar("answerM1");
answer2 = player.GetVar("answerM2");
answer3 = player.GetVar("answerM3");
answer4 = player.GetVar("answerM4");
answer5 = player.GetVar("answerM5");
answer6 = player.GetVar("answerM6");
answer7 = player.GetVar("answerM7");
answer8 = player.GetVar("answerM8");

var answersum = "";

if ( answer1 !== "")
   answersum += answer1 + ", ";
if ( answer2 !== "")
   answersum += answer2 + ", ";
if ( answer3 !== "")
   answersum += answer3 + ", ";
if ( answer4 !== "")
   answersum += answer4 + ", ";
if ( answer5 !== "")
   answersum += answer5 + ", ";
if ( answer6 !== "")
   answersum += answer6;
if ( answer7 !== "")
   answersum += answer7 + ", ";
if ( answer8 !== "")
   answersum += answer8;


 window.summary.question.push('Wat zijn in de studie de hoofdvariabelen?');
  window.summary.answer.push(answersum);
  window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('1', answersum, false, '', 'Wat zijn in de studie de hoofdvariabelen?', 1, 0, 'Scene2_Slide9_1');
}

function Script16()
{
  window.achievements.advanceAchievement(0);
window.achievements.doEverythingAtOnce();
}

function Script17()
{
  player = GetPlayer();
answer1 = player.GetVar("answerM1");
answer2 = player.GetVar("answerM2");
answer3 = player.GetVar("answerM3");
answer4 = player.GetVar("answerM4");
answer5 = player.GetVar("answerM5");
answer6 = player.GetVar("answerM6");
answer7 = player.GetVar("answerM7");
answer8 = player.GetVar("answerM8");

var answersum = "";

if ( answer1 !== "")
   answersum += answer1 + ", ";
if ( answer2 !== "")
   answersum += answer2 + ", ";
if ( answer3 !== "")
   answersum += answer3 + ", ";
if ( answer4 !== "")
   answersum += answer4 + ", ";
if ( answer5 !== "")
   answersum += answer5 + ", ";
if ( answer6 !== "")
   answersum += answer6;
if ( answer7 !== "")
   answersum += answer7 + ", ";
if ( answer8 !== "")
   answersum += answer8;


 window.summary.question.push('Wat zijn in de studie de hoofdvariabelen?');
  window.summary.answer.push(answersum);
  window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('1', answersum, true, '', 'Wat zijn in de studie de hoofdvariabelen?', 1, 0, 'Scene2_Slide9_1');
}

function Script18()
{
  var player = GetPlayer();
player.SetVar("answerM1", "");
player.SetVar("answerM2", "");
player.SetVar("answerM3", "");
player.SetVar("answerM4", "");
player.SetVar("answerM5", "");
player.SetVar("answerM6", "");
player.SetVar("answerM7", "");
player.SetVar("answerM8", "");
}

function Script19()
{
  player = GetPlayer();
answer1 = player.GetVar("answerM1");
answer2 = player.GetVar("answerM2");
answer3 = player.GetVar("answerM3");
answer4 = player.GetVar("answerM4");
answer5 = player.GetVar("answerM5");
answer6 = player.GetVar("answerM6");
answer7 = player.GetVar("answerM7");
answer8 = player.GetVar("answerM8");

var answersum = "";

if ( answer1 !== "")
   answersum += answer1 + ", ";
if ( answer2 !== "")
   answersum += answer2 + ", ";
if ( answer3 !== "")
   answersum += answer3 + ", ";
if ( answer4 !== "")
   answersum += answer4 + ", ";
if ( answer5 !== "")
   answersum += answer5 + ", ";
if ( answer6 !== "")
   answersum += answer6;
if ( answer7 !== "")
   answersum += answer7 + ", ";
if ( answer8 !== "")
   answersum += answer8;


 window.summary.question.push('Wat zijn in deze studie de niveaus van de twee variabelen, mediaconsumptie en zwaarlijvigheid?');
  window.summary.answer.push(answersum);
  window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('2', answersum, true, '', 'Wat zijn in deze studie de niveaus van de twee variabelen, mediaconsumptie en zwaarlijvigheid?', 1, 0, 'Scene2_Slide9_2');
}

function Script20()
{
  player = GetPlayer();
answer1 = player.GetVar("answerM1");
answer2 = player.GetVar("answerM2");
answer3 = player.GetVar("answerM3");
answer4 = player.GetVar("answerM4");
answer5 = player.GetVar("answerM5");
answer6 = player.GetVar("answerM6");
answer7 = player.GetVar("answerM7");
answer8 = player.GetVar("answerM8");

var answersum = "";

if ( answer1 !== "")
   answersum += answer1 + ", ";
if ( answer2 !== "")
   answersum += answer2 + ", ";
if ( answer3 !== "")
   answersum += answer3 + ", ";
if ( answer4 !== "")
   answersum += answer4 + ", ";
if ( answer5 !== "")
   answersum += answer5 + ", ";
if ( answer6 !== "")
   answersum += answer6;
if ( answer7 !== "")
   answersum += answer7 + ", ";
if ( answer8 !== "")
   answersum += answer8;


 window.summary.question.push('Wat zijn in deze studie de niveaus van de twee variabelen, mediaconsumptie en zwaarlijvigheid?');
  window.summary.answer.push(answersum);
  window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('2', answersum, false, '', 'Wat zijn in deze studie de niveaus van de twee variabelen, mediaconsumptie en zwaarlijvigheid?', 1, 0, 'Scene2_Slide9_2');
}

function Script21()
{
  
/*
 *
 * HANGMAN GAME
 *
 */

/*global GetPlayer:false */
var player = GetPlayer();
(function() {
	'use strict';
	window.hangman = {
		//Use capital letters
		questions: ["NOMINAL"],
		activeQuestion: -1,
		question: '',
		chars: [],
		foundChars: {},
		foundLetters: 0,
		alphabet: ["A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z", "Ex"],
		init: function()
		{
			//console.log("init");

		},
		/*
		 * Functions to be called from Storyline
		 */
		// Setup question and the word into letters
		setupQuestions: function(questionnumber)
		{
			this.foundLetters = 0;
			this.activeQuestion = questionnumber;
			this.question = this.questions[this.activeQuestion-1];
			this.chars = this.question.split('');
			this.foundChars = {};
			for (var i = this.alphabet.length - 1; i >= 0; i--)
				player.SetVar("hmChange"+ this.alphabet[i], 0);


		},
		// Check if any letter or the answer is found
		letterPressed: function(letter)
		{
			if (this.foundChars[letter])
				return;
			player.SetVar("hmChangeSet", 0);
			var found = 0;
			for (var i = this.chars.length - 1; i >= 0; i--) {
				var pos = i+1;
				if(this.chars[i] == letter) {
					player.SetVar("hml"  + pos, letter);
					found = 1;
					this.foundLetters++;
					this.foundChars[letter] = true;
					if (this.foundLetters >= this.chars.length) {
						player.SetVar("hmAnswerFound", 1);
					}	
				}
			}
			if( found != 1) {
				//cant put ! in the stroyline var
				if (letter == "!")
					letter = "Ex";

				var isPressed = player.GetVar("hmChange"+letter);
				if( isPressed == 0) {
				var tleft = player.GetVar("hmtleft");
				tleft = tleft -1;
				player.SetVar("hmtleft", tleft);
				player.SetVar("hmChange"+ letter, 1);
				}
			}
		 

			return;
		}
	};
	window.hangman.init();
})();

/*
 *
 * END OF HANGMAN GAME
 *
 */


}

function Script22()
{
  var seconds=3000;
// display();
var blinkTimer = setTimeout(display,400);
var flag = 0;
 
function display(){
	seconds=seconds-1;
	var player = GetPlayer();
	var tleft = player.GetVar("hmtleft");
	player.SetVar("hmtimer",seconds);
	if( tleft != 9) {
		if(flag == 0) {
			player.SetVar("hmBlink","hide");
			flag = 1;
		}
		else {
		player.SetVar("hmBlink","show");
		flag = 0;
		}
		var blinkTimer = setTimeout(display,400);
	}
	else 
	player.SetVar("hmBlink","show");
}
 
}

function Script23()
{
  window.hangman.setupQuestions(1);
}

function Script24()
{
  window.hangman.letterPressed("B");
}

function Script25()
{
  window.hangman.letterPressed("C");
}

function Script26()
{
  window.hangman.letterPressed("D");
}

function Script27()
{
  window.hangman.letterPressed("E");
}

function Script28()
{
  window.hangman.letterPressed("F");
}

function Script29()
{
  window.hangman.letterPressed("G");
}

function Script30()
{
  window.hangman.letterPressed("H");
}

function Script31()
{
  window.hangman.letterPressed("I");
}

function Script32()
{
  window.hangman.letterPressed("J");
}

function Script33()
{
  window.hangman.letterPressed("K");
}

function Script34()
{
  window.hangman.letterPressed("L");
}

function Script35()
{
  window.hangman.letterPressed("M");
}

function Script36()
{
  window.hangman.letterPressed("N");
}

function Script37()
{
  window.hangman.letterPressed("O");
}

function Script38()
{
  window.hangman.letterPressed("P");
}

function Script39()
{
  window.hangman.letterPressed("Q");
}

function Script40()
{
  window.hangman.letterPressed("R");
}

function Script41()
{
  window.hangman.letterPressed("S");
}

function Script42()
{
  window.hangman.letterPressed("T");
}

function Script43()
{
  window.hangman.letterPressed("U");
}

function Script44()
{
  window.hangman.letterPressed("V");
}

function Script45()
{
  window.hangman.letterPressed("W");
}

function Script46()
{
  window.hangman.letterPressed("X");
}

function Script47()
{
  window.hangman.letterPressed("Y");
}

function Script48()
{
  window.hangman.letterPressed("Z");
}

function Script49()
{
  window.hangman.letterPressed("!");
}

function Script50()
{
  window.hangman.letterPressed("A");
}

function Script51()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script52()
{
    window.summary.question.push('Welk meetniveau is in deze studie geschikt voor mediaconsumptie?');
  window.summary.answer.push('Nominal');
  window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('3', 'Nominal', true, '', 'Welk meetniveau is in deze studie geschikt voor mediaconsumptie?', 1, 0, 'Scene2_Slide10');
}

function Script53()
{
    window.summary.question.push('Welk meetniveau is in deze studie geschikt voor mediaconsumptie?');
  window.summary.answer.push('');
  window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('3', '', false, '', 'Welk meetniveau is in deze studie geschikt voor mediaconsumptie?', 1, 0, 'Scene2_Slide10');
}

function Script54()
{
  var seconds=4;
//setTimeout(display,1000);
display();
 
function display(){
seconds=seconds-1;
var player = GetPlayer();
player.SetVar("hmcready",seconds);
var cready = player.GetVar("hmcready");
if ( cready == 0) {
player.SetVar("hmcready", "Go!");
setTimeout(display,1000);
}
else if ( cready == -1) {
player.SetVar("hmcready", "next");
}
else {
setTimeout(display,1000);
}
}
}

function Script55()
{
  var player = GetPlayer();
var name= player.GetVar('achievementName');
var desc = player.GetVar('achievementDesc');

console.log("name:" + name);
console.log("description" + desc);
}

function Script56()
{
  window.hangman.setupQuestions(1);
var seconds=4;
//setTimeout(display,1000);
display();
 
function display(){
seconds=seconds-1;
var player = GetPlayer();
player.SetVar("hmcready",seconds);
var cready = player.GetVar("hmcready");
if ( cready == 0) {
player.SetVar("hmcready", "Go!");
setTimeout(display,1000);
}
else if ( cready == -1) {
player.SetVar("hmcready", "next");
setTimeout(display,1000);
}
else {
setTimeout(display,1000);
}
}
}

function Script57()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script58()
{
  var player = GetPlayer();  
var answer = player.GetVar('answer');
window.summary.question.push('Welk meetniveau in de studie was geschikt voor de mate van zwaarlijvigheid ');
window.summary.answer.push(answer);
window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('4', answer, true, '', 'Welk meetniveau in de studie was geschikt voor de mate van zwaarlijvigheid ', 1, 0, 'Scene2_Slide11_1');
}

function Script59()
{
  var player = GetPlayer();  
var answer = player.GetVar('answer');
window.summary.question.push('Welk meetniveau in de studie was geschikt voor de mate van zwaarlijvigheid');
window.summary.answer.push(answer);
window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('4', answer, false, '', 'Welk meetniveau in de studie was geschikt voor de mate van zwaarlijvigheid ', 1, 0, 'Scene2_Slide11_1');
}

function Script60()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script61()
{
    window.summary.question.push('Welk soort ontwerp suggereert deze studie?');
  window.summary.answer.push('een verband tussen variabelen.');
  window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('5', 'een verband tussen variabelen', true, '', 'Welk soort ontwerp suggereert deze studie? ', 1, 0, 'Scene2_Slide11_2');
}

function Script62()
{
    window.summary.question.push('Welk soort ontwerp suggereert deze studie?');
  window.summary.answer.push('verschillen tussen groepen');
  window.summary.correct.push('Incorrect');


lmsAPI.RecordFillInInteraction('5', 'verschillen tussen groepen', false, '', 'Welk soort ontwerp suggereert deze studie? ', 1, 0, 'Scene2_Slide11_2');
}

function Script63()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script64()
{
    window.summary.question.push('Welke van onderstaande ruwe datasets is de juiste om te testen?');
  window.summary.answer.push('Dataset1');
  window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('9', 'Dataset1', true, '', 'Welke van onderstaande ruwe datasets is de juiste om te testen? ', 1, 0, 'Scene2_Slide12');
}

function Script65()
{
    window.summary.question.push('Welke van onderstaande ruwe datasets is de juiste om te testen?');
  window.summary.answer.push('Dataset2');
  window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('9', 'Dataset2', false, '', 'Welke van onderstaande ruwe datasets is de juiste om te testen? ', 1, 0, 'Scene2_Slide12');
}

function Script66()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script67()
{
  player = GetPlayer();  
var answer = player.GetVar('answer');

window.summary.question.push('Welke grafische afbeelding van de data zou je willen zien?');
window.summary.answer.push(answer);
window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('10', answer, true, '', 'Welke grafische afbeelding van de data zou je willen zien? ', 1, 0, 'Scene2_Slide13');

}

function Script68()
{
  player = GetPlayer();  
var answer = player.GetVar('answer');

window.summary.question.push('Welke grafische afbeelding van de data zou je willen zien?');
window.summary.answer.push(answer);
window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('10', answer, false, '', 'Welke grafische afbeelding van de data zou je willen zien? ', 1, 0, 'Scene2_Slide13');
}

function Script69()
{
  player = GetPlayer();  
var answer = player.GetVar('answer');

window.summary.question.push('Welke grafische afbeelding van de data zou je willen zien?');
window.summary.answer.push(answer);
window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('10', answer, false, '', 'Welke grafische afbeelding van de data zou je willen zien? ', 1, 0, 'Scene2_Slide13');
}

function Script70()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


}

function Script71()
{
  window.summary.question.push('Welke teststatistiek zou jij willen zien?');
window.summary.answer.push('Chi squared value');
window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('12', 'Chi squared value', true, '', 'Welke teststatistiek zou jij willen zien? ', 1, 0, 'Scene2_Slide14');
}

function Script72()
{
  window.summary.question.push('Welke teststatistiek zou jij willen zien?');
window.summary.answer.push('Spearmans rho');
window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('12', 'Spearmans rho', false, '', 'Welke teststatistiek zou jij willen zien? ', 1, 0, 'Scene2_Slide14');
}

function Script73()
{
  window.summary.question.push('Welke teststatistiek zou jij willen zien?');
window.summary.answer.push('t-waarde');
window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('12', 't-waarde', false, '', 'Welke teststatistiek zou jij willen zien? ', 1, 0, 'Scene2_Slide14');
}

function Script74()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}
}

function Script75()
{
  window.summary.question.push('Which test statistic would you like to see?');
window.summary.answer.push('Chi squared value');
window.summary.correct.push('Correct');
}

function Script76()
{
  player = GetPlayer();  
var ne = player.GetVar('NumericEntry');
var ne1 = player.GetVar('NumericEntry1');

window.summary.question.push('Wat was de chi-kwadraat-waarde ');
window.summary.answer.push(ne+','+ne1);
window.summary.correct.push('Correct');

var answer = ne+','+ne1;

lmsAPI.RecordFillInInteraction('13', answer, true, '', 'Wat was de chi-kwadraat-waarde? ', 1, 0, 'Scene2_Slide14_2');
}

function Script77()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}

var time = player.GetVar('time');
//Bronze Gold Silver
if( time <= 15000 && time > 1200 ) {
player.SetVar("achQuestionBronze",1);
}
if( time>= 10000 &&  time <= 12000) {
player.SetVar("achQuestionBronze",0);
player.SetVar("achQuestionSilver",1);
}
if( time < 10000 ) {
player.SetVar("achQuestionSilver",0);
player.SetVar("achQuestionGold",1);
}
}

function Script78()
{
  window.achievements.advanceAchievement(3);
window.achievements.doEverythingAtOnce();

window.achievements.advanceAchievement(4);
window.achievements.doEverythingAtOnce();




}

function Script79()
{
  window.summary.question.push('De berekende waarde was= 30.295,p<0.000 Was dit significant?');
window.summary.answer.push('Ja');
window.summary.correct.push('Correct');

lmsAPI.RecordFillInInteraction('14', 'Ja', true, '', 'De berekende waarde was= 30.295,p<0.000 Was dit significant? ', 1, 0, 'Scene2_Slide14_3');
}

function Script80()
{
  var player = GetPlayer();
var time = player.GetVar('time');
//Bronze Gold Silver
if( time <= 15000 && time > 1200 ) {
player.SetVar("achQuestionBronze",1);
}
if( time>= 10000 &&  time <= 12000) {
player.SetVar("achQuestionBronze",0);
player.SetVar("achQuestionSilver",1);
}
if( time < 10000 ) {
player.SetVar("achQuestionSilver",0);
player.SetVar("achQuestionGold",1);
}

window.achievements.advanceAchievement(4);
window.achievements.doEverythingAtOnce();
}

function Script81()
{
  window.summary.question.push('De berekende waarde was= 30.295,p<0.000 Was dit significant?');
window.summary.answer.push('Nee');
window.summary.correct.push('Incorrect');

lmsAPI.RecordFillInInteraction('14', 'Nee', false, '', 'De berekende waarde was= 30.295,p<0.000 Was dit significant? ', 1, 0, 'Scene2_Slide14_3');
}

function Script82()
{
  player = GetPlayer();  
var ne = player.GetVar('NumericEntry');
var ne1 = player.GetVar('NumericEntry1');

window.summary.question.push('What was the chi square value? ');
window.summary.answer.push(ne+','+ne1);
window.summary.correct.push('Incorrect');

var answer = ne+','+ne1;

lmsAPI.RecordFillInInteraction('13', answer, false, '', 'What was the chi square value ', 1, 0, 'Scene2_Slide14_2');
}

function Script83()
{
  
/*
 *
 * TIC-TAC-TOE GAME
 *
 */

/*global GetPlayer:false */
var player = GetPlayer();
(function() {
	'use strict';
	var state = {
		READY: 0,
		RIGHT: 1,
		WRONG: 2
	};
	var validValues = [
                               // Rows
		1  | 2   | 4,
		8  | 16  | 32,
		64 | 128 | 256,
		// Columns
		1  | 8   | 64,
		2  | 16  | 128,
		4  | 32  | 256,
		// Diagonals
		1 | 16 | 256,
		4 | 16 | 64
	];
	window.ttt = {
		questions: [
			{
				text: "Meer kinderen zijn zwaarlijvig dan niet.",
				wrong: "Niet correct.",
				answer: true
			},
			{
				text: "Van de zwaarlijvigen zijn er meer die een hoge mate van mediaconsumptie hadden dan een lage. ",
				wrong: "Niet correct.",
				answer: true
			},
			{
				text: "Van degenen die niet zwaarlijvig zijn, zijn er meer die een hoge mate van mediaconsumptie hadden dan een lage. ",
				wrong: "Niet correct.",
				answer: false
			},
			{
				text: "In totaal waren er meer kinderen met een lage mate van mediaconsumptie dan een hoge mate van mediaconsumptie.",
				wrong: "Niet correct.",
				answer: false
			},
			{
				text: "Meer kinderen hadden een normaal gewicht dan zwaarlijvig.",
				wrong: "Niet correct.",
				answer: false
			},
			{
				text: "Van de zwaarlijvigen zijn er minder die een hoge mate van mediaconsumptie hadden dan een lage. ",
				wrong: "Niet correct.",
				answer: false
			},
			{
				text: "Van degenen die niet zwaarlijvig zijn, zijn er meer die een lage mate van mediaconsumptie hadden dan een hoge. ",
				wrong: "Niet correct.",
				answer: true
			},
			{
				text: "De minst voorkomende categorie was niet zwaarlijvig en een lage mate van mediaconsumptie.",
				wrong: "Niet correct.",
				answer: false
			},
			{
				text: "De meest voorkomende categorie was zwaarlijvig en een hoge mate van mediaconsumptie. ",
				wrong: "Niet correct.",
				answer: true
			}
		],
		activeQuestion: -1,
		totalValue: 0,
		init: function()
		{
			if (this.questions.length !== 9) {
				alert("Question count missmatch! Got " + this.questions.length + " expected 9");
				return;
			}
			var value = 1;
			// Setup the Qs with redundant info

var length = this.questions.length,
element = null;
for (var i = 0; i < length; i++) {
element = this.questions[i];
element .id = i;
element .value = value;
element .state = state.READY;
value *= 2;
}
		},
		updateQState: function(question, state)
		{
			question.state = state;
			player.SetVar('tttQuestionState' + question.id, state);
		},
		/*
		 * Functions to be called from Storyline
		 */
		// Resets all the question vars to ready
		setupQuestions: function()
		{
			this.activeQuestion = null;
			this.totalValue = 0;
			player.SetVar('tttQuestionText', '');
			player.SetVar('tttSlideSolved', 0);
var length = this.questions.length,
element = null;
for (var i = 0; i < length; i++) {
element = this.questions[i];
this.updateQState(element , state.READY);
}

		},
		// For when the user picks a question
		chooseQuestion: function(quid)
		{
			var question = this.questions[quid];
			if (question.state !== state.READY)
				return;
			this.activeQuestion = question;
			player.SetVar('tttQuestionText', question.text);
		},
		// Check if the answer is correctus
		checkAnswer: function(choice)
		{
			// Get what we're talkin about
			var question = this.activeQuestion;
			// Hide the question window
var questionText = player.GetVar('tttQuestionText');
			player.SetVar('tttQuestionText', '');
			// Reset the wrong var so we can trigger it if necessary
			player.SetVar('tttQuestionWrong', '');
			// Determine failure
			var choice_ = (choice == 'true') ? true : false;
			// If you pass you're wrong and stupid
			if (choice === 'pass' || choice_ !== question.answer) {
				this.updateQState(question, state.WRONG);
				// Pop up the "no u stupid" box
				player.SetVar('tttQuestionWrong', question.wrong);

window.summary.question.push(questionText);
window.summary.answer.push(choice_);
window.summary.correct.push('Incorrect');

				return;
			}
			// success!
window.summary.question.push(questionText);
window.summary.answer.push(question.answer);
window.summary.correct.push('Correct');
			this.updateQState(question, state.RIGHT);
			this.totalValue |= question.value;
			// Check if we've won
var length = validValues.length,
value = null;
for (var i = 0; i < length; i++) {
value = validValues[i];
if  ( (this.totalValue & value) === value )
player.SetVar('tttSlideSolved', 1);
}
		}
	};
	window.ttt.init();
})();

/*
 *
 * END OF TIC-TAC-TOE GAME
 *
 */


}

function Script84()
{
  window.ttt.setupQuestions();
}

function Script85()
{
  window.ttt.setupQuestions();
}

function Script86()
{
  window.ttt.chooseQuestion(0);
}

function Script87()
{
  window.ttt.chooseQuestion(1);
}

function Script88()
{
  window.ttt.chooseQuestion(2);
}

function Script89()
{
  window.ttt.chooseQuestion(3);
}

function Script90()
{
  window.ttt.chooseQuestion(4);
}

function Script91()
{
  window.ttt.chooseQuestion(5);
}

function Script92()
{
  window.ttt.chooseQuestion(6);
}

function Script93()
{
  window.ttt.chooseQuestion(7);
}

function Script94()
{
  window.ttt.chooseQuestion(8);
}

function Script95()
{
  var player = GetPlayer();
var isUnlockedOne = player.GetVar('achievementUnlocked1');


if( isUnlockedOne != 1 ) {

window.achievements.advanceAchievement(1);
window.achievements.doEverythingAtOnce();

var isUnlockedOne = player.GetVar('achievementUnlocked1');

if( isUnlockedOne == 1 ) 
player.SetVar('showReward', 1);

}


lmsAPI.RecordFillInInteraction('11', 'Completed', true, '', 'Microscope Game ', 1, 0, 'Scene2_Slide15');


}

function Script96()
{
  lmsAPI.RecordFillInInteraction('11', '', false, '', 'Microscope Game ', 1, 0, 'Scene2_Slide15');
}

function Script97()
{
  var eyesshut = 100, eyesopen = 10000, inblink = false;
var player = GetPlayer();
function blink(){
  inblink = !inblink;
  if (inblink) {
    player.SetVar('blinkState', 'hide');
    setTimeout(blink, eyesshut + Math.random() * 40);
  } else {
    player.SetVar('blinkState', 'show');
    setTimeout(blink, eyesopen + Math.random() * 500);
  }
}

blink(); 
}

function Script98()
{
  window.ttt.checkAnswer('true');
}

function Script99()
{
  window.ttt.checkAnswer('false');
}

